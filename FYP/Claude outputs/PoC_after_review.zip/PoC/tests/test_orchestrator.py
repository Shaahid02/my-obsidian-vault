"""The normalisation, the coupling, and the fairness rule the arms rest on."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc.arms import discounted_inverse_mse, equal_weight, stock_watson   # noqa: E402
from poc.evaluate import margin_rule, matthews                           # noqa: E402
from poc.orchestrator import (Orchestrator, liquidity_reliability,       # noqa: E402
                              softmax_floor, weight_entropy)


# ------------------------------------------------------- the normalisation

def test_weights_sum_to_one_and_respect_the_simplex():
    rng = np.random.default_rng(0)
    s = rng.normal(0, 2, (200, 3))
    live = rng.random((200, 3)) > 0.3
    live[~live.any(axis=1), 0] = True            # keep at least one voter per row
    w = softmax_floor(s, live, phi=0.05)
    assert np.allclose(w.sum(axis=1), 1.0)
    assert (w[~live] == 0.0).all(), "an agent outside the simplex must get a hard zero"
    assert (w[live] > 0.0).all()


def test_the_floor_is_honoured_and_capped_at_one_over_k():
    """§6.3: w = (1 - K phi) w~ + phi needs 1 - K phi >= 0, so phi is capped at 1/K.

    K varies by row because agents leave the simplex, so the cap has to be applied
    against the live K rather than a fixed agent count.
    """
    s = np.array([[10.0, -10.0, -10.0], [10.0, -10.0, -10.0]])
    live = np.array([[True, True, True], [True, True, False]])
    w = softmax_floor(s, live, phi=0.10)
    assert w[0, 1] >= 0.10 - 1e-9 and w[0, 2] >= 0.10 - 1e-9
    assert w[1, 1] >= 0.10 - 1e-9 and w[1, 2] == 0.0
    # phi above 1/K must not produce negative weights
    w2 = softmax_floor(s, live, phi=0.9)
    assert (w2 >= 0).all() and np.allclose(w2.sum(axis=1), 1.0)


def test_abstain_shrinks_toward_the_floor_rather_than_to_zero():
    """The change Geweke and Amisano force: individually poor forecasts can still help
    in combination, so an abstaining agent is shrunk to the floor, not zeroed. The hard
    zero is reserved for output that does not parse, which is a different case.

    Regression for FIXES.md fix 2. Before it, the abstain flag never reached the
    normalisation, so this test is built so that it could only pass if it does: the
    abstaining agent has by far the HIGHEST score, and must still get exactly phi.
    """
    s = np.array([[20.0, 0.0, 0.0]])
    live = np.array([[True, True, True]])
    abstain = np.array([[True, False, False]])
    w = softmax_floor(s, live, phi=0.05, abstain=abstain)
    assert np.isclose(w[0, 0], 0.05), "an abstaining agent must get exactly the floor"
    assert np.isclose(w.sum(), 1.0)
    assert np.isclose(w[0, 1], w[0, 2])
    # ...and without the flag the same agent takes almost everything
    w_ok = softmax_floor(s, live, phi=0.05)
    assert w_ok[0, 0] > 0.85


def test_abstain_differs_from_unparseable():
    """Abstain keeps the floor and is counted in K; unparseable gets a hard zero."""
    s = np.zeros((1, 3))
    abst = softmax_floor(s, np.array([[True, True, True]]), 0.05,
                         abstain=np.array([[True, False, False]]))
    unp = softmax_floor(s, np.array([[False, True, True]]), 0.05)
    assert np.isclose(abst[0, 0], 0.05) and unp[0, 0] == 0.0
    assert np.allclose(unp[0, 1:], 0.5)


def test_everyone_abstaining_falls_back_to_the_live_set():
    s = np.array([[3.0, 0.0, -3.0]])
    live = np.ones((1, 3), bool)
    w = softmax_floor(s, live, 0.05, abstain=np.ones((1, 3), bool))
    assert np.isclose(w.sum(), 1.0) and (w > 0).all()


def test_non_finite_scores_raise_instead_of_becoming_equal_weights():
    with pytest.raises(ValueError):
        softmax_floor(np.array([[np.nan, 0.0, 0.0]]), np.ones((1, 3), bool), 0.05)


def test_entropy_bounds():
    w_equal = np.full((1, 3), 1 / 3)
    w_point = np.array([[1.0, 0.0, 0.0]])
    assert np.isclose(weight_entropy(w_equal)[0], np.log(3))
    assert np.isclose(weight_entropy(w_point)[0], 0.0)


# ---------------------------------------------------------- the coupling

def test_coupling_is_decreasing_in_illiquidity_and_only_touches_its_targets():
    c = np.full((5, 3), 0.6)
    L = np.array([-2.0, -1.0, 0.0, 1.0, 2.0])
    out = liquidity_reliability(c, L, which=(0,), kappa=0.5)
    assert np.all(np.diff(out[:, 0]) < 0), "g(L) must fall as illiquidity rises"
    assert np.allclose(out[:, 1], 0.6) and np.allclose(out[:, 2], 0.6)
    assert out[0, 0] == pytest.approx(0.6, abs=0.1), "near-normal liquidity leaves c alone"


def test_coupling_off_is_the_identity():
    c = np.full((4, 3), 0.5)
    L = np.array([-1.0, 0.0, 1.0, 2.0])
    assert np.allclose(liquidity_reliability(c, L, which=(0,), kappa=0.0), c)


# ------------------------------------------------------------- the arms

def test_equal_weight_is_uniform_over_live_agents():
    live = np.array([[True, True, True], [True, False, True]])
    w = equal_weight(live)
    assert np.allclose(w[0], 1 / 3)
    assert np.allclose(w[1], [0.5, 0.0, 0.5])


def test_b3_weight_at_t_cannot_see_the_loss_at_t():
    """B3 reacts to recent agent performance, so it must use losses strictly before t."""
    loss = np.tile(np.array([0.2, 0.5, 0.8]), (300, 1))
    live = np.ones((300, 3), bool)
    base = discounted_inverse_mse(loss, live, phi=0.0)
    bumped = loss.copy()
    bumped[200] = [9.0, 0.01, 0.01]
    moved = discounted_inverse_mse(bumped, live, phi=0.0)
    assert np.allclose(base[200], moved[200]), "the weight at t used the loss at t"
    assert not np.allclose(base[205], moved[205]), "the loss at t never propagated forward"


def test_stock_watson_k_zero_is_equal_weight():
    rng = np.random.default_rng(3)
    loss = rng.random((300, 3)) + 0.1
    live = np.ones((300, 3), bool)
    w = stock_watson(loss, live, k=0.0)
    assert np.allclose(w[-1], 1 / 3)


def test_large_k_approaches_winner_take_all():
    loss = np.tile(np.array([0.1, 0.9, 0.9]), (300, 1))
    live = np.ones((300, 3), bool)
    w = stock_watson(loss, live, k=8.0)
    assert w[-1, 0] > 0.9


# -------------------------------------------------- A5, the fairness rule

def test_every_arm_consumes_the_same_signals():
    """The CSE Graph-RAG paper's fatal flaw was that its proposed system got both the
    graph and the agent scaffolding while its baseline got neither. A5 exists so that is
    not reproduced: the arms differ in the weighting function and in nothing else."""
    from poc.arms import run_arms
    rng = np.random.default_rng(11)
    n, K = 600, 3
    tr = {"X": np.column_stack([np.ones(n), rng.normal(size=n), rng.random(n),
                                rng.random(n)]),
          "c": rng.random((n, K)), "live": np.ones((n, K), bool),
          "loss": rng.random((n, K)), "L": rng.normal(size=n),
          "signals": rng.uniform(-1, 1, (n, K)), "n": n}
    te = dict(tr)
    before = te["signals"].copy()
    res = run_arms(tr, te, seed=0)
    assert set(res) == {"B1", "B2", "B3", "P", "O"}
    assert np.array_equal(te["signals"], before), "an arm mutated the shared signals"
    for r in res.values():
        assert r.weights.shape == (n, K)
        assert np.allclose(r.weights.sum(axis=1), 1.0)


def test_ablation_drops_exactly_one_input():
    from poc.arms import ABLATIONS
    assert set(ABLATIONS) == {"P-L", "P-V", "P-P", "P-C", "P-Coupling"}
    assert ABLATIONS["P-L"]["state_names"] == ("V", "P")
    # Removing L_t necessarily removes the coupling too, since g(L_t) has no argument
    # without it. P-Coupling is what separates the two uses of the one measurement.
    assert ABLATIONS["P-L"]["coupling"] is False
    assert ABLATIONS["P-Coupling"]["state_names"] == ("L", "V", "P")


# --------------------------------------------------------- the decision rule

def test_margin_rule_needs_more_than_a_positive_median():
    noisy = np.array([-1.0, 1.0, -1.0, 1.0, -1.0, 1.0])       # IQR 2.0
    p = noisy + 0.1
    m = margin_rule(p, noisy)
    assert m["median_delta"] == pytest.approx(0.1)
    assert not m["iqr_passed"], "a win smaller than the baseline's own noise is not a win"
    assert margin_rule(noisy + 5.0, noisy)["iqr_passed"]


def test_mcc_separates_accuracy_from_skill():
    """Why Part 9 requires MCC on the same row as accuracy, class balance and
    cost-adjusted return: the local example of the gap is an accuracy of 0.5837 at an
    MCC of 0.1493.

    A predictor that always says "up" scores 58% on an unbalanced sample while having no
    skill at all, and MCC is what shows that.
    """
    always_up = np.ones(100)
    true = np.concatenate([np.ones(58), -np.ones(42)])
    accuracy = float((always_up == true).mean())
    assert accuracy == pytest.approx(0.58)
    assert np.isnan(matthews(always_up, true)), (
        "a constant predictor has an undefined MCC, which is the point: accuracy alone "
        "would have reported 0.58 as though it were skill"
    )

    # A predictor with genuine skill on the same sample scores a positive MCC.
    skilled = true.copy()
    skilled[:10] *= -1
    assert matthews(skilled, true) > 0.5


def test_orchestrator_refuses_to_predict_before_it_is_fitted():
    o = Orchestrator(3)
    with pytest.raises(RuntimeError):
        o.weights(np.ones((2, 4)), np.full((2, 3), 0.5), np.ones((2, 3), bool),
                  np.zeros(2))


# --------------------------------------------------- B3, one ticker at a time

def _two_ticker_panel(n_days=200, seed=5):
    rng = np.random.default_rng(seed)
    dates = np.repeat(np.arange(n_days), 2)               # date-major, like the real panel
    tickers = np.tile(np.array(["AAA", "BBB"]), n_days)
    loss = rng.random((2 * n_days, 3)) + 0.05
    live = np.ones((2 * n_days, 3), bool)
    return loss, live, tickers, dates


def test_b3_cannot_see_another_tickers_same_day_outcome():
    """FIXES.md fix 5. With one global accumulator over a date-major panel, BBB's weight
    on day d absorbed AAA's day-d loss, which is the d -> d+1 return: a one-day leak."""
    loss, live, tickers, dates = _two_ticker_panel()
    base = discounted_inverse_mse(loss, live, phi=0.0, tickers=tickers, dates=dates)
    bumped = loss.copy()
    row_aaa = int(np.where((tickers == "AAA") & (dates == 150))[0][0])
    row_bbb = int(np.where((tickers == "BBB") & (dates == 150))[0][0])
    bumped[row_aaa] = [9.0, 0.01, 0.01]
    moved = discounted_inverse_mse(bumped, live, phi=0.0, tickers=tickers, dates=dates)
    bbb = tickers == "BBB"
    assert np.allclose(base[bbb], moved[bbb]), "BBB's weights moved when AAA's loss changed"
    assert not np.allclose(base[row_aaa + 2], moved[row_aaa + 2]), \
        "AAA's own later weights should respond to its own loss"
    assert row_bbb > row_aaa


def test_b3_weights_do_not_depend_on_row_order():
    loss, live, tickers, dates = _two_ticker_panel()
    w = discounted_inverse_mse(loss, live, phi=0.0, tickers=tickers, dates=dates)
    perm = np.random.default_rng(1).permutation(len(loss))
    wp = discounted_inverse_mse(loss[perm], live[perm], phi=0.0,
                                tickers=tickers[perm], dates=dates[perm])
    assert np.allclose(w[perm], wp)


def test_b3_does_not_credit_a_silent_agent():
    """An agent outside the simplex carries the loss of a zero forecast. It must not be
    absorbed, or the agent returns to the simplex with a track record it never earned."""
    loss, live, tickers, dates = _two_ticker_panel()
    live2 = live.copy()
    live2[: 200, 2] = False                       # agent 3 silent for the first 100 days
    a = discounted_inverse_mse(loss, live2, phi=0.0, tickers=tickers, dates=dates)
    loss2 = loss.copy()
    loss2[: 200, 2] = 50.0                        # what it 'scored' while silent
    b = discounted_inverse_mse(loss2, live2, phi=0.0, tickers=tickers, dates=dates)
    assert np.allclose(a, b)


# ------------------------------------------------ one definition of the outcome

def test_forward_return_spans_non_trading_days():
    """FIXES.md fix 6. A position taken at a traded close earns the return to the next
    traded close. The calendar-adjacent definition returned NaN across every gap, which
    silently removed 29.5% of a thin counter's return episodes from the evaluation."""
    from poc.calibration import forward_return_traded
    close = np.array([100.0, np.nan, np.nan, 110.0, 121.0, np.nan, 121.0])
    r, gap = forward_return_traded(close)
    assert np.isclose(r[0], np.log(1.1)) and gap[0] == 3
    assert np.isclose(r[3], np.log(1.1)) and gap[3] == 1
    assert r[4] == 0.0 and gap[4] == 2
    assert np.isnan(r[1]) and np.isnan(r[6])


def test_agents_and_panel_share_the_outcome_definition():
    import inspect
    import poc.panel as panel
    import poc.agents.liquidity as liq
    src = inspect.getsource(panel.load_panel)
    assert "forward_return_traded" in src
    # A_L scores itself on its compact traded-day series, where consecutive elements are
    # consecutive traded days: the same quantity.
    assert "compact(" in inspect.getsource(liq.LiquidityAgent._series)


def test_conviction_scales_ignore_rows_where_the_agent_was_silent():
    """FIXES.md fix 7a. A silent row carries a hard zero by contract; it is not a vote of
    zero conviction and must not lower the agent's measured typical conviction."""
    from poc.panel import conviction_scales
    rng = np.random.default_rng(2)
    s = rng.uniform(-0.2, 0.2, (1000, 3))
    fwd = rng.normal(0, 0.02, 1000)
    live = np.ones((1000, 3), bool)
    k_all = conviction_scales(s, fwd, live=live)
    s2, live2 = s.copy(), live.copy()
    s2[:400, 0], live2[:400, 0] = 0.0, False      # agent 0 silent 40% of the time
    k_masked = conviction_scales(s2, fwd, live=live2)
    assert np.isclose(k_masked[0], conviction_scales(s[400:], fwd[400:])[0], rtol=0.1)
    assert conviction_scales(s2, fwd)[0] > 1.5 * k_masked[0], \
        "without the mask the silent agent should look inflated; the mask is what fixes it"


def test_missing_confidence_is_filled_from_the_training_window():
    """FIXES.md fix 9: a missing c is the agent's typical competence, not 0.5."""
    rng = np.random.default_rng(4)
    n = 400
    X = np.column_stack([np.ones(n), rng.normal(size=(n, 3))])
    c = np.column_stack([np.full(n, 0.70), np.full(n, 0.45), np.full(n, 0.52)])
    c[::7, 2] = np.nan
    o = Orchestrator(3)
    o.fit(X, c, np.ones((n, 3), bool), rng.random((n, 3)), rng.normal(size=n), seed=0)
    assert np.allclose(o._c_fill, [0.70, 0.45, 0.52])
    # At L = 0 the coupling g(L) = exp(-kappa * ln 2) touches A_T only.
    eff = o._effective_c(np.array([[np.nan, np.nan, np.nan]]), np.zeros(1))
    g0 = np.exp(-o.kappa * np.log(2.0))
    assert np.allclose(eff[0], [0.70 * g0, 0.45, 0.52])


# ------------------------------------------------- housekeeping regressions (fix 13)

def test_knee_returns_index_into_callers_list():
    from poc.evaluate import knee
    xs = [0.0, 0.01, 0.02, np.nan, 0.05, 0.1, 0.2, 1 / 3]
    ys = [0.0, 0.50, 0.80, 0.90, 0.90, 0.92, 0.93, 0.94]
    i = knee(xs, ys)
    # Furthest from the chord on normalised axes is x = 0.05, which is position 4 in the
    # caller's list. The old filtered index would have been 3, which points at the NaN.
    assert i == 4 and xs[i] == 0.05
    assert knee([0, 1], [0, 1]) == -1


def test_identified_parameter_count():
    from poc.orchestrator import OrchestratorFit
    f = OrchestratorFit(np.zeros((3, 4)), np.zeros(3), ("L", "V", "P"), 1e-3, 0.05,
                        True, True, 100, 0.0, 0)
    assert f.n_params == 2 * 4 + 3
    b2 = OrchestratorFit(np.zeros((3, 1)), np.zeros(3), (), 1e-3, 0.05,
                         False, False, 100, 0.0, 0)
    assert b2.n_params == 2


def test_in_simplex_is_positive():
    import pandas as pd
    from poc.panel import Panel
    f = pd.DataFrame({"state_A_T": ["ok", "abstain", "banana", "no_data"],
                      "state_A_V": ["ok"] * 4, "state_A_L": ["ok"] * 4})
    assert Panel(f).in_simplex()[:, 0].tolist() == [True, True, False, False]

"""Agent arithmetic that the causality tests cannot see.

The truncation tests in test_causality.py prove an agent never uses data after the
cursor. They cannot prove its arithmetic is right: a forecast that double-counts
yesterday's return is perfectly causal. These tests check the numbers against an
independent implementation.
"""
from __future__ import annotations

import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc import features                                       # noqa: E402
from poc.agents import VolatilityAgent                         # noqa: E402
from poc.agents.base import compact                            # noqa: E402
from poc.datalayer import DataLayer                            # noqa: E402
from poc.state import build_state                              # noqa: E402

DATASET = Path(os.environ.get("FYP_DATASET", r"D:\FYP Dataset"))
needs_data = pytest.mark.skipif(not (DATASET / "extracted").exists(),
                                reason="FYP Dataset not reachable")


@pytest.fixture(scope="module")
def vone_returns():
    dl = DataLayer(DATASET)
    st = build_state(dl, "VONE.N0000")
    _, (close,) = compact(st, "adj_close")
    return features.log_return(close)


@needs_data
def test_garch_matches_arch_across_a_refit_interval(vone_returns):
    """FIXES.md fix 3. On a refit day the emitted sigma must be arch's own one-step
    forecast, and on the following days the GJR recursion must reproduce arch's
    conditional variance with the same parameters held fixed. Before the fix the refit
    day advanced the forecast a second time and the recursion ignored the fitted mean."""
    from arch import arch_model

    r = vone_returns
    agent = VolatilityAgent()
    sigma = agent._garch_forecast(r)

    t0 = 2000                      # a refit day: t0 % refit_every == 0
    assert t0 % agent.refit_every == 0
    lo = t0 - agent.fit_window
    hist = r[lo:t0]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        res = arch_model(hist * 100.0, mean="Constant", vol="GARCH", p=1, o=1, q=1,
                         dist="t", rescale=False).fit(disp="off", show_warning=False)
        ext = r[lo:t0 + agent.refit_every]
        fixed = arch_model(ext * 100.0, mean="Constant", vol="GARCH", p=1, o=1, q=1,
                           dist="t", rescale=False).fix(res.params)
    arch_sigma = np.asarray(fixed.conditional_volatility) / 100.0

    for k in range(agent.refit_every):
        mine = sigma[t0 + k]
        theirs = arch_sigma[t0 - lo + k]
        assert np.isclose(mine, theirs, rtol=1e-6), (
            f"day t0+{k}: emitted sigma {mine:.8e}, arch {theirs:.8e}")


@needs_data
def test_ewma_fallback_conditions_on_the_same_information_as_garch(vone_returns):
    """The fallback must not use r[t] when the model it stands in for uses r[t-1]."""
    r = vone_returns.copy()
    agent = VolatilityAgent()
    import poc.agents.volatility as v
    base = np.sqrt(features.ewma_var(r))
    shifted = np.concatenate([[np.nan], base[:-1]])
    r2 = r.copy()
    r2[100] = r2[100] * 10
    base2 = np.concatenate([[np.nan], np.sqrt(features.ewma_var(r2))[:-1]])
    assert np.isclose(shifted[100], base2[100]), "the value at t moved when r[t] changed"
    assert not np.isclose(shifted[101], base2[101])


def test_zero_range_bars_carry_no_variance_information():
    """FIXES.md fix 11: high == low is missing, not zero variance."""
    v = features.parkinson(np.array([10.0, 10.0, 11.0]), np.array([10.0, 9.0, 11.0]))
    assert np.isnan(v[0]) and v[1] > 0 and np.isnan(v[2])


def test_non_trading_days_cannot_change_persistence():
    """FIXES.md fix 11. P_t is estimated on the traded-day series, so inserting
    non-trading days into the calendar must leave every estimate unchanged; on the old
    calendar construction it did not, because each gap removed two returns and gph()
    compacted the survivors as though they were contiguous."""
    rng = np.random.default_rng(3)
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, 1400)))
    d1, _ = features.gph_on_traded(close, window=750, refit_every=25)
    spine = np.full(2100, np.nan)
    where = np.sort(rng.choice(2100, 1400, replace=False))
    spine[where] = close
    d2, _ = features.gph_on_traded(spine, window=750, refit_every=25)
    ok = np.isfinite(d1)
    assert ok.sum() > 100
    assert np.allclose(d1[ok], d2[where][ok])


def test_a_t_predictions_do_not_depend_on_feature_units():
    """FIXES.md fix 12. With standardisation inside the fit, rescaling a feature column
    (say, a volatility measured in percent rather than as a fraction) cannot change A_T's
    forecast. Without it, the ridge penalty fell almost entirely on small-scale columns."""
    from sklearn.linear_model import Ridge
    rng = np.random.default_rng(8)
    X = np.column_stack([rng.normal(0, 0.005, 800), rng.normal(0, 1.0, 800)])
    y = 0.8 * X[:, 0] / 0.005 * 0.01 + 0.2 * X[:, 1] * 0.01 + rng.normal(0, 0.01, 800)
    def fit_predict(Xm):
        mu, sd = Xm[:700].mean(0), Xm[:700].std(0)
        m = Ridge(alpha=1.0).fit((Xm[:700] - mu) / sd, y[:700])
        return m.predict((Xm[700:] - mu) / sd)
    X2 = X.copy(); X2[:, 0] *= 100.0
    assert np.allclose(fit_predict(X), fit_predict(X2))

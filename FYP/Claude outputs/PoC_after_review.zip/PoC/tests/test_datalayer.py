"""The cursor, and the contract it is there to protect.

`11 Architecture` gives the data layer's interface three properties and calls each a
requirement rather than a convenience. These tests hold it to all three.
"""
from __future__ import annotations

import datetime as dt
import os
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc.contract import AgentOutput, AgentState, ContractViolation    # noqa: E402
from poc.datalayer import (AsOfView, CursorViolation, DataLayer,       # noqa: E402
                           Rows, UnknownField)

DATASET = Path(os.environ.get("FYP_DATASET", r"D:\FYP Dataset"))
TICKER = os.environ.get("POC_TEST_TICKER", "VONE.N0000")
needs_data = pytest.mark.skipif(
    not (DATASET / "extracted").exists(), reason="FYP Dataset not reachable")


@pytest.fixture(scope="module")
def dl():
    return DataLayer(DATASET)


# ----------------------------------------------------- property 1: no frames

@needs_data
def test_query_returns_rows_not_a_dataframe(dl):
    import pandas as pd
    rows = dl.query(TICKER, ["adj_close"], dt.date(2020, 6, 30))
    assert isinstance(rows, Rows)
    assert not isinstance(rows, pd.DataFrame)
    assert isinstance(rows["adj_close"], np.ndarray)


# ------------------------------------------------- property 2: raises, not warns

@needs_data
def test_no_row_exceeds_the_cursor(dl):
    for as_of in (dt.date(2015, 3, 31), dt.date(2020, 6, 30), dt.date(2024, 12, 31)):
        rows = dl.query(TICKER, ["adj_close", "adj_high"], as_of)
        assert len(rows) > 0
        assert max(rows.dates) <= as_of


@needs_data
def test_cursor_beyond_the_window_raises(dl):
    with pytest.raises(CursorViolation):
        dl.query(TICKER, ["adj_close"], dt.date(2027, 1, 4))
    with pytest.raises(CursorViolation):
        dl.at(dt.date(2030, 1, 1))


@needs_data
def test_non_date_cursor_raises(dl):
    with pytest.raises(CursorViolation):
        dl.query(TICKER, ["adj_close"], "2020-06-30")


@needs_data
def test_unknown_field_raises_rather_than_returning_nothing(dl):
    with pytest.raises(UnknownField):
        dl.query(TICKER, ["adj_clsoe"], dt.date(2020, 6, 30))
    with pytest.raises(UnknownField):
        dl.query(TICKER, ["nonsense.close"], dt.date(2020, 6, 30))


# --------------------------------- property 3: an agent cannot name a date

@needs_data
def test_asofview_exposes_no_way_to_choose_a_date(dl):
    view = dl.at(dt.date(2020, 6, 30))
    assert isinstance(view, AsOfView)
    rows = view.query(TICKER, ["adj_close"])
    assert max(rows.dates) <= dt.date(2020, 6, 30)
    # query takes no date, and the bound date is not writable
    import inspect
    assert "as_of" not in inspect.signature(view.query).parameters
    with pytest.raises(AttributeError):
        view.as_of = dt.date(2026, 1, 1)


@needs_data
def test_strata_are_not_reachable_through_the_data_layer(dl):
    """DC-36: the strata are whole-sample medians, so they are a design input, not a
    model input. Keeping them out of the layer is what stops the distinction eroding."""
    from poc.datalayer import FIELD_SOURCE
    for forbidden in ("quintile_float_adjusted", "quintile_raw", "stale_close_rate",
                      "median_turnover_ex_cross"):
        assert forbidden not in FIELD_SOURCE
        with pytest.raises(UnknownField):
            dl.query(TICKER, [forbidden], dt.date(2020, 6, 30))


@needs_data
def test_liquidity_panel_is_calendar_aligned_and_adjusted_is_not(dl):
    as_of = dt.date(2024, 12, 31)
    liq = dl.query(TICKER, ["traded"], as_of)
    adj = dl.query(TICKER, ["adj_close"], as_of)
    assert len(liq) >= len(adj), "the liquidity panel should carry non-traded days too"


# ------------------------------------------------------------- the contract

def test_signal_outside_the_range_is_refused():
    with pytest.raises(ContractViolation):
        AgentOutput(agent="A_T", ticker="X.N0000", as_of=dt.date(2020, 1, 2),
                    signal=1.4, confidence_raw=0.5, state=AgentState.OK)


def test_calibrated_confidence_outside_zero_one_is_refused():
    with pytest.raises(ContractViolation):
        AgentOutput(agent="A_T", ticker="X.N0000", as_of=dt.date(2020, 1, 2),
                    signal=0.1, confidence_raw=0.5, state=AgentState.OK,
                    confidence_calibrated=1.2)


def test_abstain_and_unparseable_are_distinct_states():
    """§6.3 routes them differently: a hard zero against a shrink toward the floor."""
    assert AgentState.ABSTAIN is not AgentState.UNPARSEABLE
    assert AgentState.ABSTAIN.value != AgentState.UNPARSEABLE.value


def test_no_data_carries_no_vote():
    o = AgentOutput.no_data("A_F", "X.N0000", dt.date(2020, 1, 2), "corpus not built")
    assert o.state is AgentState.NO_DATA
    assert o.signal == 0.0
    assert o.confidence_raw is None


# ------------------------------------------------- housekeeping regressions (fix 13)

@needs_data
def test_multi_source_query_is_order_independent(dl):
    """The first-listed source used to fix the index, so field order changed the rows."""
    d = dt.date(2021, 12, 31)
    a = dl.query(TICKER, ["adj_close", "traded"], d)
    b = dl.query(TICKER, ["traded", "adj_close"], d)
    assert list(a.dates) == list(b.dates)
    np.testing.assert_array_equal(a["adj_close"], b["adj_close"])
    np.testing.assert_array_equal(a["traded"], b["traded"])
    # the union contains every date either source has on its own
    only_liq = dl.query(TICKER, ["traded"], d)
    assert set(only_liq.dates) <= set(a.dates)


@needs_data
def test_timestamp_cursor_is_normalised(dl):
    """A datetime used to pass at() and then fail inside pandas, not as CursorViolation."""
    import pandas as pd
    view = dl.at(pd.Timestamp("2020-06-30"))
    rows = view.query(TICKER, ["adj_close"])
    assert rows.dates[-1] <= dt.date(2020, 6, 30)


@needs_data
def test_cursor_before_window_raises(dl):
    with pytest.raises(CursorViolation):
        dl.at(dl.window_start - dt.timedelta(days=1))


@needs_data
def test_volume_fields_resolve_to_the_calendar_panel(dl):
    """Zero-volume days must survive as zeros rather than vanish as absent rows."""
    d = dt.date(2021, 12, 31)
    v = dl.query(TICKER, ["share_volume", "traded"], d)
    t = np.asarray(v["traded"], float)
    assert (t == 0).any(), "non-trading days must be present as rows"
    assert np.all(np.asarray(v["share_volume"], float)[t == 0] == 0)


def test_rows_last_skips_trailing_missing():
    r = Rows("X", dt.date(2020, 1, 3),
             np.array([dt.date(2020, 1, 1), dt.date(2020, 1, 2), dt.date(2020, 1, 3)], object),
             {"f": np.array([1.0, 2.0, np.nan])})
    assert r.last("f") == 2.0
    empty = Rows("X", dt.date(2020, 1, 3), np.array([], object), {"f": np.array([])})
    assert np.isnan(empty.last("f"))


def test_contract_rejects_non_enum_state():
    for bad in ("OK", "banana"):
        with pytest.raises(ContractViolation):
            AgentOutput("A_T", "X", dt.date(2020, 1, 1), 99.0, None, bad)


def test_contract_rejects_non_finite_confidence_raw():
    with pytest.raises(ContractViolation):
        AgentOutput("A_T", "X", dt.date(2020, 1, 1), 0.1, float("nan"), AgentState.OK)

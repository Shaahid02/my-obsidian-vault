"""The as-of guarantee, checked rather than claimed.

Two levels:

  * every helper in `poc.features` is recomputed on truncated prefixes and compared at
    the prefix end. A function whose value at t depends on anything after t fails here;
  * each agent is rebuilt against a data layer whose window ends at a sampled date, and
    its output on that date is compared with the output the full run produced for the
    same date. This is the one that would catch a leak in the fitted components, where
    a refit schedule or a rolling window quietly reaches forward.

If these pass, computing a whole series once and indexing into it is equivalent to
recomputing it at every cursor, which is what makes the batch path legitimate.
"""
from __future__ import annotations

import datetime as dt
import os
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc import features                                      # noqa: E402
from poc.agents import LiquidityAgent, TechnicalAgent, VolatilityAgent   # noqa: E402
from poc.datalayer import DataLayer                           # noqa: E402
from poc.state import build_state                             # noqa: E402

DATASET = Path(os.environ.get("FYP_DATASET", r"D:\FYP Dataset"))
TICKER = os.environ.get("POC_TEST_TICKER", "VONE.N0000")
pytestmark = pytest.mark.skipif(
    not (DATASET / "extracted").exists(), reason="FYP Dataset not reachable")


# --------------------------------------------------------------- primitives

@pytest.fixture(scope="module")
def series():
    rng = np.random.default_rng(20261122)
    n = 600
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.02, n)))
    spread = np.abs(rng.normal(0, 0.01, n))
    return {
        "close": close,
        "high": close * (1 + spread),
        "low": close * (1 - spread),
        "vol": rng.lognormal(10, 1, n),
        "flag": (rng.random(n) < 0.2).astype(float),
    }


@pytest.mark.parametrize("cut", [300, 450, 599])
def test_feature_helpers_are_causal(series, cut):
    s = series
    cases = {
        "log_return": lambda d: features.log_return(d["close"]),
        "rolling_std": lambda d: features.rolling_std(features.log_return(d["close"]), 20, 10),
        "rolling_sum": lambda d: features.rolling_sum(features.log_return(d["close"]), 5, 5),
        "rolling_frac": lambda d: features.rolling_frac(d["flag"], 60, 20),
        "zscore_rolling": lambda d: features.zscore_rolling(d["close"], 120, 60),
        "zscore_expanding": lambda d: features.zscore_expanding(d["close"], 60),
        "ewma_var": lambda d: features.ewma_var(features.log_return(d["close"])),
        "parkinson_vol": lambda d: features.parkinson_vol(d["high"], d["low"], 20),
        "rolling_gph": lambda d: features.rolling_gph(
            np.abs(features.log_return(d["close"])), 250, 25)[0],
        "technical_features": lambda d: features.technical_features(
            d["close"], d["high"], d["low"], d["vol"])[0][:, 3],
    }
    trunc = {k: v[: cut + 1] for k, v in s.items()}
    for name, fn in cases.items():
        full = fn(s)[cut]
        part = fn(trunc)[cut]
        if np.isnan(full) and np.isnan(part):
            continue
        assert np.isclose(full, part, rtol=1e-9, atol=1e-12), (
            f"{name} at {cut}: full={full!r} truncated={part!r}; the value depends on "
            "data after the cursor"
        )


# ------------------------------------------------------------------- state

def test_state_series_is_causal():
    """L_t, V_t and P_t must not change when future rows are removed."""
    dl_full = DataLayer(DATASET)
    st_full = build_state(dl_full, TICKER)
    cut = st_full.dates[int(len(st_full.dates) * 0.8)]

    dl_cut = DataLayer(DATASET, window_end=cut.isoformat())
    st_cut = build_state(dl_cut, TICKER)

    i = st_full.index_of(cut)
    j = st_cut.index_of(cut)
    assert st_cut.dates[j] == cut
    for name in ("L", "V", "P"):
        a, b = getattr(st_full, name)[i], getattr(st_cut, name)[j]
        if np.isnan(a) and np.isnan(b):
            continue
        assert np.isclose(a, b, rtol=1e-9, atol=1e-12), f"{name} at {cut}: {a} vs {b}"


def test_full_sample_composite_is_not_causal():
    """The control: L_full *should* fail the same test, or it is not measuring lookahead.

    §6.1 asks for the full-sample PCA to be run alongside the rolling one as direct
    evidence of how much lookahead a naive construction injects. If the two agreed under
    truncation the comparison would be vacuous.
    """
    dl_full = DataLayer(DATASET)
    st_full = build_state(dl_full, TICKER)
    cut = st_full.dates[int(len(st_full.dates) * 0.8)]
    st_cut = build_state(DataLayer(DATASET, window_end=cut.isoformat()), TICKER)
    a = st_full.L_full[st_full.index_of(cut)]
    b = st_cut.L_full[st_cut.index_of(cut)]
    assert not (np.isfinite(a) and np.isfinite(b) and np.isclose(a, b, rtol=1e-6)), (
        "the full-sample composite is unchanged by truncation, so it is not the "
        "lookahead control it is meant to be"
    )


# ------------------------------------------------------------------ agents

@pytest.mark.parametrize("agent_cls", [TechnicalAgent, VolatilityAgent, LiquidityAgent])
def test_agent_output_is_unchanged_by_truncation(agent_cls):
    """An agent's output on date t is identical whether or not the panel extends past t."""
    dl = DataLayer(DATASET)
    st = build_state(dl, TICKER)
    agent = agent_cls()
    full = {o.as_of: o for o in agent.run(dl, TICKER, st)}

    dates = [d for d in st.dates if d >= st.dates[int(len(st.dates) * 0.6)]]
    for cut in (dates[0], dates[len(dates) // 2]):
        got = agent.emit_at(DATASET, TICKER, cut)
        want = full[cut]
        assert got.state == want.state, f"{agent.name} state at {cut}"
        assert np.isclose(got.signal, want.signal, rtol=1e-9, atol=1e-12), (
            f"{agent.name} signal at {cut}: {got.signal} vs {want.signal}")
        if want.confidence_raw is None or got.confidence_raw is None:
            assert got.confidence_raw == want.confidence_raw, f"{agent.name} conf at {cut}"
        else:
            assert np.isclose(got.confidence_raw, want.confidence_raw, rtol=1e-9), (
                f"{agent.name} confidence_raw at {cut}")


# ------------------------------------------------------------- calibration

def test_calibration_cannot_see_its_own_outcome():
    """c_i,t must not move when the outcome of the prediction made at t is changed.

    The outcome at t is realised at t+1, so a transform that used it would be reading one
    day into the future on every confidence number in the study.
    """
    from poc.calibration import accuracy_at_threshold

    rng = np.random.default_rng(7)
    n = 900
    raw = rng.random(n)
    correct = (rng.random(n) < raw).astype(float)

    base = accuracy_at_threshold(raw, correct)
    flipped = correct.copy()
    t = 700
    flipped[t] = 1.0 - flipped[t]
    moved = accuracy_at_threshold(raw, flipped)

    assert np.isclose(base[t], moved[t], equal_nan=True), (
        "the calibrated confidence at t changed when the outcome at t changed"
    )
    later = np.where(np.isfinite(base[t + 2:]) & np.isfinite(moved[t + 2:])
                     & ~np.isclose(base[t + 2:], moved[t + 2:]))[0]
    assert len(later) > 0, "flipping an outcome changed nothing later; the window is not used"


# ------------------------------------------------- depth rules, applied as-of

@pytest.mark.parametrize("ticker", ["HUNT.N0000", "VONE.N0000"])
def test_depth_rules_are_decided_on_the_history_available_at_the_row(ticker):
    """FIXES.md fix 4. Two thresholds pick a mechanism by history depth: conformal versus
    QLIKE confidence for A_V (1,250 days) and per-counter versus index persistence for
    P_t (1,250 days). Both used to count the WHOLE series, so a counter that eventually
    crossed the threshold was treated as having crossed it from day one.

    The oracle is the truncation rebuild: on a date before the counter has 1,250 traded
    days, a panel that ends on that date cannot know the counter will get there."""
    dl = DataLayer(DATASET)
    st = build_state(dl, ticker)
    traded = np.cumsum(np.nan_to_num(st.aligned["traded"], nan=0.0))
    early = st.dates[int(np.searchsorted(traded, 1100))]          # ~1,100 traded days in

    st_cut = build_state(DataLayer(DATASET, window_end=early.isoformat()), ticker)
    i, j = st.index_of(early), st_cut.index_of(early)
    def src(series, k):            # tolerate the pre-fix shape, a single string per ticker
        return series.P_source if isinstance(series.P_source, str) else series.P_source[k]
    assert src(st, i) == src(st_cut, j) != "counter", (
        f"full run says {src(st, i)!r}, a panel ending on {early} says {src(st_cut, j)!r}")
    if np.isfinite(st.P[i]) or np.isfinite(st_cut.P[j]):
        assert np.isclose(st.P[i], st_cut.P[j], equal_nan=True)

    agent = VolatilityAgent()
    full = {o.as_of: o for o in agent.run(dl, ticker, st)}[early]
    cut = agent.emit_at(DATASET, ticker, early)
    assert full.diagnostics["conf_mechanism"] == cut.diagnostics["conf_mechanism"] == "qlike_fallback"
    assert (full.confidence_raw is None and cut.confidence_raw is None) or \
        np.isclose(full.confidence_raw, cut.confidence_raw, rtol=1e-9)

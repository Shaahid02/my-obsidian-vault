"""The five-arm harness, the ablations, the sweeps and the acceptance report.

    python scripts/run_arms.py                 # everything, on the cached agent output
    python scripts/run_arms.py --quick         # one seed, no parameter sweeps

Reads out/agents/ and out/state/. Writes under out/arms/:

    fold_results.csv    per arm, per fold, per seed: coverage, hit rate, MCC, net return
    ablations.csv       the proposal with one input removed at a time
    sensitivity_L.csv    A3: dw/dL on frozen rows
    phi_sweep.csv       the abstention-floor frontier and its knee
    l2_sweep.csv        the regularisation stability sweep
    sw_sweep.csv        Stock and Watson inverse-k
    weight_trace.csv    w_i,t and H_t over the pooled test windows
    acceptance.txt      A1 to A6, with the evidence for each
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc import config                                          # noqa: E402
from poc.arms import ABLATIONS, ARMS, run_arms, stock_watson, with_history    # noqa: E402
from poc.datalayer import DataLayer                             # noqa: E402
from poc.evaluate import (arm_returns, collinearity, daily_difference,   # noqa: E402
                          hac_paired_test,
                          knee, margin_rule, quiet_vs_stressed,
                          stationary_bootstrap, summarise, system_abstains)
from poc.folds import make_folds, slice_fold                    # noqa: E402
from poc.orchestrator import (Orchestrator, sensitivity_to_state,   # noqa: E402
                              weight_entropy)
from poc.panel import load_panel                                # noqa: E402


def _score(res, te, cost_bps, exposure="hold"):
    abst = system_abstains(te["live"], te["abstain"])
    ret = arm_returns(res.decision, te["fwd_ret"], te["tickers"], te["dates"],
                      abst, cost_bps=cost_bps, exposure=exposure)
    row = summarise(res.decision, te["fwd_ret"], ret, abst, res.weights)
    return row, ret, abst


#: The parameter sweeps refit P once per setting, so they run on the most recent folds only
#: to keep the full run tractable. Every sweep table says so and prints B1 and P on the
#: same folds, because a sweep row is not comparable with the 16-fold arm table.
SWEEP_FOLDS = 8


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--quick", action="store_true", help="one seed, no parameter sweeps")
    ap.add_argument("--cost-bps", type=float, default=config.COST_BPS_PRIMARY)
    ap.add_argument("--l-column", default="L", choices=("L", "L_pca", "L_full_sample"),
                    help="which L_t series conditions the orchestrator. L is the primary "
                         "(equal-weighted signed z-scores, FIXES.md fix 1); L_pca is the "
                         "rolling PC1 kept as a robustness check. L_full_sample uses the "
                         "whole sample and is look-ahead by construction: diagnostic only.")
    args = ap.parse_args()

    out = Path(args.out) if args.out else config.OUT
    arms_dir = out / ("arms" if args.l_column == "L" else f"arms_{args.l_column}")
    arms_dir.mkdir(parents=True, exist_ok=True)
    seeds = (0,) if args.quick else config.SEEDS

    dl = DataLayer(args.dataset)
    panel = load_panel(out, args.dataset, l_column=args.l_column)
    if args.l_column != "L":
        print(f"L_t       : using {args.l_column} in place of L (robustness run)")
    usable = panel.usable()
    print(f"panel     : {len(panel):,} rows, {usable.sum():,} usable, "
          f"{panel.frame['ticker'].nunique()} securities")

    folds = make_folds(dl.calendar)
    print(f"protocol  : {config.FOLD_TRAIN} train / {config.FOLD_TEST} test / "
          f"step {config.FOLD_STEP}, {len(folds)} folds, {len(seeds)} seed(s)")
    print(f"            {folds[0].train_start} .. {folds[-1].test_end}")
    print(f"cost      : {args.cost_bps:.0f} bps on turnover\n")

    sliced = []
    for f in folds:
        tr = slice_fold(panel, f.train_start, f.train_end)
        te = slice_fold(panel, f.test_start, f.test_end,
                        signal_scales=tr["signal_scales"])     # train scales only
        sliced.append((f, tr, te))

    # ------------------------------------------------------------ five arms
    rows, per_fold = [], defaultdict(lambda: defaultdict(list))
    trace, net_series, kept, dec_series = [], defaultdict(list), [], defaultdict(list)
    date_series = defaultdict(list)
    t0 = time.time()
    for f, tr, te in sliced:
        if tr["n"] < 200 or te["n"] < 20:
            print(f"  {f}  SKIPPED (train {tr['n']}, test {te['n']})")
            continue
        for seed in seeds:
            res = run_arms(tr, te, seed=seed, fold=f.index)
            for arm, r in res.items():
                row, ret, abst = _score(r, te, args.cost_bps)
                rows.append({"arm": arm, "fold": f.index, "seed": seed,
                             "n_train": tr["n"], "converged": int(r.converged),
                             "n_params": r.n_params, **row})
                per_fold[arm][f.index].append(row["net_return"])
                if seed == seeds[0]:
                    net_series[arm].append(ret["net"])
                    dec_series[arm].append(r.decision)
                    date_series[arm].append(te["dates"])
                    kept.append((arm, f.index, r, te))
            if seed == seeds[0]:
                H = weight_entropy(res["P"].weights)
                for i in range(0, te["n"], max(1, te["n"] // 40)):
                    trace.append({"fold": f.index, "date": te["dates"][i],
                                  "ticker": te["tickers"][i],
                                  **{f"w_{a}": res["P"].weights[i, j]
                                     for j, a in enumerate(panel.agents)},
                                  "H": H[i], "L": te["L"][i]})
        print(f"  {f}  train={tr['n']:>6} test={te['n']:>5}  "
              + "  ".join(f"{a}:{np.mean(per_fold[a][f.index]):+.4f}" for a in ARMS))

    _write(arms_dir / "fold_results.csv", rows)
    _write(arms_dir / "weight_trace.csv", trace)
    print(f"\narms done in {time.time() - t0:.0f}s")

    # ----------------------------------------------------------- ablations
    abl_rows = []
    for name, cfg in ABLATIONS.items():
        for f, tr, te in sliced:
            if tr["n"] < 200 or te["n"] < 20:
                continue
            tr_a = slice_fold(panel, f.train_start, f.train_end, cfg["state_names"])
            te_a = slice_fold(panel, f.test_start, f.test_end, cfg["state_names"],
                              signal_scales=tr_a["signal_scales"])
            for seed in seeds:
                res = run_arms(tr_a, te_a, seed=seed, fold=f.index, arms=("P",), **cfg)
                row, _, _ = _score(res["P"], te_a, args.cost_bps)
                abl_rows.append({"ablation": name, "fold": f.index, "seed": seed, **row})
    _write(arms_dir / "ablations.csv", abl_rows)

    # ----------------------------------------------- A3: sensitivity to L_t
    sens = []
    f, tr, te = sliced[-1]
    orch = Orchestrator(len(panel.agents))
    orch.fit(tr["X"], tr["c"], tr["live"], tr["loss"], tr["L"], seed=0, abstain=tr["abstain"])
    grid = np.linspace(np.nanpercentile(panel.frame["L"], 5),
                       np.nanpercentile(panel.frame["L"], 95), 25)
    picks = np.linspace(0, te["n"] - 1, min(20, te["n"]), dtype=int)
    for i in picks:
        W = sensitivity_to_state(orch, te["X"][i], te["c"][i], te["live"][i], 1, grid,
                                     te["abstain"][i])
        for g, w in zip(grid, W):
            sens.append({"row": int(i), "ticker": te["tickers"][i], "date": te["dates"][i],
                         "L": g, **{f"w_{a}": w[j] for j, a in enumerate(panel.agents)},
                         "H": weight_entropy(w[None, :])[0]})
    _write(arms_dir / "sensitivity_L.csv", sens)

    dW = []
    for i in picks:
        W = sensitivity_to_state(orch, te["X"][i], te["c"][i], te["live"][i], 1, grid,
                                     te["abstain"][i])
        dW.append((W.max(axis=0) - W.min(axis=0)))
    dW = np.array(dW)

    # ------------------------------------------------------------- sweeps
    phi_rows, l2_rows, sw_rows = [], [], []
    if not args.quick:
        for phi in config.ORCH_PHI_SWEEP:
            acc = []
            for f, tr, te in sliced[-SWEEP_FOLDS:]:
                if tr["n"] < 200 or te["n"] < 20:
                    continue
                res = run_arms(tr, te, phi=phi, seed=0, fold=f.index, arms=("P",))
                row, _, _ = _score(res["P"], te, args.cost_bps)
                acc.append(row)
            if acc:
                phi_rows.append({"phi": phi,
                                 **{k: float(np.nanmean([a[k] for a in acc]))
                                    for k in ("coverage", "hit_rate", "mcc",
                                              "net_return", "entropy_mean")}})
        for lam in config.ORCH_L2_SWEEP:
            acc = []
            for f, tr, te in sliced[-SWEEP_FOLDS:]:
                if tr["n"] < 200 or te["n"] < 20:
                    continue
                res = run_arms(tr, te, lam=lam, seed=0, fold=f.index, arms=("P",))
                row, _, _ = _score(res["P"], te, args.cost_bps)
                acc.append(row)
            if acc:
                l2_rows.append({"l2": lam,
                                **{k: float(np.nanmean([a[k] for a in acc]))
                                   for k in ("hit_rate", "mcc", "net_return",
                                             "entropy_mean")}})
        for k in config.SW_K_SWEEP:
            acc = []
            for f, tr, te in sliced[-SWEEP_FOLDS:]:
                if te["n"] < 20:
                    continue
                w = with_history(tr, te, stock_watson, k=k)
                dec = np.clip(np.nansum(w * np.nan_to_num(te["vote"], nan=0.0), axis=1),
                              -1, 1)
                abst = system_abstains(te["live"], te["abstain"])
                ret = arm_returns(dec, te["fwd_ret"], te["tickers"], te["dates"], abst,
                                  cost_bps=args.cost_bps)
                acc.append(summarise(dec, te["fwd_ret"], ret, abst, w))
            if acc:
                sw_rows.append({"k": k, **{m: float(np.nanmean([a[m] for a in acc]))
                                           for m in ("hit_rate", "mcc", "net_return",
                                                     "entropy_mean")}})
    sweep_fold_ids = {f.index for f, _, _ in sliced[-SWEEP_FOLDS:]}
    args.sweep_ref = {a: float(np.nanmean([r["net_return"] for r in rows
                                           if r["arm"] == a and r["seed"] == 0
                                           and r["fold"] in sweep_fold_ids]))
                      for a in ("B1", "P")}
    _write(arms_dir / "phi_sweep.csv", phi_rows)
    _write(arms_dir / "l2_sweep.csv", l2_rows)
    _write(arms_dir / "sw_sweep.csv", sw_rows)

    # --------------------------------------------- cost and exposure sweeps
    cost_rows = []
    for cb in config.COST_BPS_SWEEP:
        for pol in ("hold", "flat"):
            agg = defaultdict(float)
            for arm, _k, r, te in kept:
                _, ret, _ = _score(r, te, cb, exposure=pol)
                agg[arm] += float(np.nansum(ret["net"]))
            cost_rows.append({"cost_bps": cb, "exposure": pol,
                              **{a: agg[a] for a in ARMS}})
    _write(arms_dir / "cost_sweep.csv", cost_rows)

    # -------------------------------------------------------- acceptance
    report = _acceptance(panel, rows, per_fold, trace, dW, grid, net_series,
                         abl_rows, phi_rows, l2_rows, sliced, args, cost_rows, dec_series,
                         date_series)
    (arms_dir / "acceptance.txt").write_text(report, encoding="utf-8")
    print("\n" + report)
    print(f"-> {arms_dir}")
    return 0


def _acceptance(panel, rows, per_fold, trace, dW, grid, net_series, abl_rows,
                phi_rows, l2_rows, sliced, args, cost_rows=(), dec_series=None,
                date_series=None) -> str:
    L = []
    add = L.append
    add("=" * 78)
    add("ACCEPTANCE CRITERIA (PoC Specification Part 0)")
    add("=" * 78)

    add("\nA1  one ticker-date end to end, no manual step")
    add(f"    PASS  {len(rows)} arm-fold-seed results from cached agent output; "
        f"{len(panel):,} panel rows assembled by scripts/run_agents.py -> run_arms.py")

    H = np.array([t["H"] for t in trace], float)
    # ---- seed dispersion. Surfaced before A2 because on this panel it is large
    # enough to swamp the arm differences, which changes how everything below reads.
    add("\n" + "-" * 78)
    add("SEED DISPERSION  (the objective is non-convex; initialisation matters)")
    add("-" * 78)
    for arm in ARMS:
        sel = [r for r in rows if r["arm"] == arm]
        if not sel or sel[0]["n_params"] == 0:
            add(f"    {arm:<4} no fitted parameters, so no seed dependence")
            continue
        by_fold = defaultdict(list)
        for r in sel:
            by_fold[r["fold"]].append(r["net_return"])
        spreads = [max(v) - min(v) for v in by_fold.values() if len(v) > 1]
        nconv = sum(r["converged"] for r in sel)
        if not spreads:
            add(f"    {arm:<4} one seed only (--quick), so no spread to report   "
                f"converged {nconv}/{len(sel)}")
            continue
        add(f"    {arm:<4} per-fold spread across seeds: median {np.median(spreads):.4f}, "
            f"max {max(spreads):.4f}   converged {nconv}/{len(sel)}")
    worst = 0.0
    for arm in ARMS:
        sel = [r for r in rows if r["arm"] == arm and r["n_params"]]
        if sel:
            bf = defaultdict(list)
            for r in sel:
                bf[r["fold"]].append(r["net_return"])
            worst = max([worst] + [max(v) - min(v) for v in bf.values() if len(v) > 1])
    if worst < 1e-3:
        add(f"    Dispersion is negligible (worst spread {worst:.2e}), so the fit is not")
        add("    initialisation-dependent and single-seed results would have been safe.")
        add("    Reported anyway: it is cheap, and absence of instability is a result.")
    else:
        add(f"    Worst per-fold spread {worst:.4f}. A spread of this size means a")
        add("    single-seed result is not a result, and every figure below is a mean")
        add("    over seeds that carries this dispersion with it.")

    add("\nA2  the weight vector is not constant over time")
    if len(H):
        add(f"    {'PASS' if np.nanstd(H) > 1e-6 else 'FAIL'}  "
            f"entropy H_t mean {np.nanmean(H):.4f}, sd {np.nanstd(H):.4f}, "
            f"range {np.nanmin(H):.4f}..{np.nanmax(H):.4f}  (ln 3 = {np.log(3):.4f})")
        add("          NOTE A2 can be satisfied by noise. A3 is the mechanism.")

    add("\nA3  the weight vector responds to L_t specifically, holding the rest fixed")
    if dW.size:
        per_agent = dW.mean(axis=0)
        add(f"    L_t swept {grid[0]:+.2f}..{grid[-1]:+.2f} on {dW.shape[0]} frozen rows")
        for a, v in zip(panel.agents, per_agent):
            add(f"        max|dw| for {a}: {v:.4f}")
        add(f"    {'PASS' if per_agent.max() > 0.01 else 'FAIL'}  "
            f"largest weight swing {per_agent.max():.4f} "
            f"({'above' if per_agent.max() > 0.01 else 'below'} the 0.01 threshold)")

    add("\nA4  at least one decision flips sign between B1 and P")
    if "B1" in dec_series and "P" in dec_series:
        # FIXES.md fix 8: this used to compare realised net returns, which flip sign
        # whenever cost crosses a small gross return even with identical decisions.
        b1 = np.concatenate(dec_series["B1"]); p = np.concatenate(dec_series["P"])
        flips = int(((np.sign(b1) * np.sign(p)) < 0).sum())
        add(f"    {'PASS' if flips else 'FAIL'}  {flips:,} of {len(b1):,} test rows where "
            f"the DECISION has opposite sign in the equal-weight and state-conditioned arms")

    add("\nA5  five arms on identical data, agents and everything but the weighting")
    arms_seen = sorted({r['arm'] for r in rows})
    add(f"    PASS  arms {arms_seen} all read the same cached signals array per fold; "
        "slice_fold applies one usability mask before any arm sees a row")

    add(f"\nA6  {len(ABLATIONS)} ablations, each producing an attributable delta")
    if abl_rows:
        base = float(np.nanmean([r["net_return"] for r in rows if r["arm"] == "P"]))
        add(f"    P net return (mean over folds and seeds): {base:+.4f}")
        for name in ABLATIONS:
            vals = [r["net_return"] for r in abl_rows if r["ablation"] == name]
            if vals:
                add(f"        {name:<12} {np.nanmean(vals):+.4f}   "
                    f"delta {np.nanmean(vals) - base:+.4f}")
        add(f"    PASS  {len(ABLATIONS)} ablations ran")
        add("          A_F on/off NOT run: the agent is not built, so a zero delta from a")
        add("          stub would not be a finding. Reported as absent, per the spec.")

    # ---- the pre-registered decision rule
    add("\n" + "=" * 78)
    add("PRE-REGISTERED DECISION RULE")
    add("=" * 78)
    pf_P = np.array([np.mean(per_fold["P"][k]) for k in sorted(per_fold["P"])])
    pf_B1 = np.array([np.mean(per_fold["B1"][k]) for k in sorted(per_fold["B1"])])
    if len(pf_P) and len(pf_B1):
        m = margin_rule(pf_P, pf_B1)
        add(f"  median per-fold delta (P - B1) : {m['median_delta']:+.5f}")
        add(f"  baseline per-fold IQR          : {m['baseline_iqr']:.5f}")
        add(f"  IQR half of the rule           : {'PASS' if m['iqr_passed'] else 'FAIL'}")
        if "B1" in net_series and "P" in net_series:
            d = daily_difference(np.concatenate(net_series["P"]),
                                 np.concatenate(net_series["B1"]),
                                 np.concatenate(date_series["P"]))
            h = hac_paired_test(d)
            b = stationary_bootstrap(d)
            add(f"  test series                    : daily portfolio P&L difference, "
                f"{len(d):,} trading days")
            add(f"  HAC paired test (t, n-1 df)    : mean {h['mean']:+.3e}  "
                f"t {h['t']:+.3f}  p {h['p']:.4f}  (lag {h['lag']})")
            add(f"  stationary bootstrap           : p {b['p']:.4f}  "
                f"95% CI [{b['ci_low']:+.3e}, {b['ci_high']:+.3e}]")
            from scipy import stats as _st
            tf = _st.ttest_rel(pf_P, pf_B1)
            add(f"  per-fold paired t (n={len(pf_P)})       : t {tf.statistic:+.3f}  p {tf.pvalue:.4f}"
                "   (robustness: folds as the unit)")
            passed = m["iqr_passed"] and h["p"] < 0.05 and b["p"] < 0.05
            add(f"  BOTH HALVES REQUIRED           : {'PASS' if passed else 'FAIL'}")
            if h["mean"] < 0:
                agree = sum(x < 0.05 for x in (h["p"], b["p"], tf.pvalue))
                add(f"  DIRECTION: the proposal is BELOW equal weight. Significant at 0.05 on "
                    f"{agree} of 3 tests" + ("; not robustly significant." if agree < 3 else "."))
        add("  CAUTION, as standing: standard errors for a combined forecast are")
        add("  nontrivial because the weights are random and correlated with the")
        add("  forecasts, so these p-values are approximations.")

    # ---- arm table
    add("\n" + "=" * 78)
    add("ARMS (mean over folds and seeds)")
    add("=" * 78)
    add(f"  {'arm':<5}{'net':>10}{'gross':>10}{'cost':>9}{'hit':>8}{'MCC':>8}"
        f"{'cover':>8}{'H':>8}{'params':>8}")
    for arm in ARMS:
        sel = [r for r in rows if r["arm"] == arm]
        if not sel:
            continue
        g = lambda k: float(np.nanmean([r[k] for r in sel]))   # noqa: E731
        add(f"  {arm:<5}{g('net_return'):>+10.4f}{g('gross_return'):>+10.4f}"
            f"{g('cost_paid'):>9.4f}{g('hit_rate'):>8.4f}{g('mcc'):>+8.4f}"
            f"{g('coverage'):>8.3f}{g('entropy_mean'):>8.4f}"
            f"{int(np.nanmean([r['n_params'] for r in sel])) if 'n_params' in sel[0] else 0:>8}")
    if "O" in per_fold and "P" in per_fold:
        pf_O = np.array([np.mean(per_fold["O"][k]) for k in sorted(per_fold["O"])])
        add(f"\n  oracle gap O - P: {np.nanmean(pf_O - pf_P):+.5f}  "
            "(the estimation cost, in this project's own data and units)")
        add("  Reading: gain in O and none in P is an ESTIMATION problem with a number")
        add("  attached, not a conceptual failure. No gain in O means the conditioning")
        add("  hypothesis is wrong and should be reported as such.")

    if cost_rows:
        add("\n" + "=" * 78)
        add("COST AND EXPOSURE SWEEP  (Part 9: a sweep, not a single assumption)")
        add("=" * 78)
        add("  Both exposure policies are shown because 'abstained days held flat' does")
        add("  not distinguish holding the position from going to zero, and that is an")
        add("  OPEN pre-registration item rather than something to inherit.")
        add("  Cells are SUMS over the 16 test folds, seed 0, unlike the arm table above,")
        add("  which reports MEANS per fold over all seeds. Compare within this table only.")
        add(f"  {'bps':>5}{'policy':>8}" + "".join(f"{a:>10}" for a in ARMS))
        for r in cost_rows:
            add(f"  {r['cost_bps']:>5.0f}{r['exposure']:>8}"
                + "".join(f"{r[a]:>+10.4f}" for a in ARMS))
        same = all(abs(h[a] - f[a]) < 1e-12 for a in ARMS
                   for h, f in zip([r for r in cost_rows if r["exposure"] == "hold"],
                                   [r for r in cost_rows if r["exposure"] == "flat"]))
        if same:
            add("  hold and flat are identical: the system abstained on no test row, because")
            add("  at least one agent was in state ok on every usable row. On this panel the")
            add("  OPEN exposure item has no effect; it will once A_V and A_L can abstain.")

    # ---- sweeps
    ref = getattr(args, "sweep_ref", None)
    sweep_note = (f"  Last {SWEEP_FOLDS} folds, seed 0, mean per fold. NOT comparable with the arm\n"
                  f"  table. On these folds B1 = {ref['B1']:+.4f} and P = {ref['P']:+.4f}."
                  if ref else "")
    if phi_rows:
        add("\n" + "=" * 78)
        add("ABSTENTION FLOOR phi  (OPEN in the pre-registration: swept, not picked)")
        add("=" * 78)
        add(sweep_note)
        add(f"  {'phi':>7}{'hit':>9}{'MCC':>9}{'net':>10}{'H':>9}{'coverage':>10}")
        for r in phi_rows:
            add(f"  {r['phi']:>7.3f}{r['hit_rate']:>9.4f}{r['mcc']:>+9.4f}"
                f"{r['net_return']:>+10.4f}{r['entropy_mean']:>9.4f}{r['coverage']:>10.3f}")
        add("  The last point, phi = 1/3 with K = 3, is equal weighting by construction.")
        i = knee([r["phi"] for r in phi_rows], [r["net_return"] for r in phi_rows])
        if i >= 0:
            add(f"  knee at phi = {phi_rows[i]['phi']:.3f} (furthest point from the chord)")
        nets = np.array([r["net_return"] for r in phi_rows])
        if np.all(np.diff(nets) >= 0):
            add("  Net return rises monotonically toward equal weighting, so the knee marks")
            add("  where the curve bends, not an optimum inside the sweep.")
    if l2_rows:
        add("\n" + "=" * 78)
        add("REGULARISATION STABILITY  (swept and reported, never tuned once)")
        add("=" * 78)
        add(sweep_note)
        add(f"  {'L2':>9}{'hit':>9}{'MCC':>9}{'net':>10}{'H':>9}")
        for r in l2_rows:
            add(f"  {r['l2']:>9.4g}{r['hit_rate']:>9.4f}{r['mcc']:>+9.4f}"
                f"{r['net_return']:>+10.4f}{r['entropy_mean']:>9.4f}")
        nets = [r["net_return"] for r in l2_rows]
        signs = {np.sign(x) for x in nets if np.isfinite(x) and x != 0}
        add(f"  sign flips across the sweep: {'YES' if len(signs) > 1 else 'no'}"
            + ("  <- the failure mode the low-capacity choice exists to expose"
               if len(signs) > 1 else ""))
    return "\n".join(L)


def _write(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    keys = list({k: None for r in rows for k in r})
    with open(path, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())

"""Build the state vector and the cached agent output for a universe.

    python scripts/run_agents.py                 # the 15-counter dev universe
    python scripts/run_agents.py --all           # every candidate security
    python scripts/run_agents.py SYM1 SYM2 ...

Writes, under out/:
    state/{SYMBOL}.csv          L_t (and the full-sample comparison), V_t, P_t
    agents/{SYMBOL}.csv         one row per agent per trading day, the contract
    run_summary.csv             per-ticker coverage, state and abstention counts
    run_log.txt                 the same, as text

Agents run once here and every arm consumes this cache. That is what acceptance check
A5 requires: outputs must be byte-identical across the five arms, which is only
achievable if they are produced once and read, never recomputed per arm.
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc import config                                        # noqa: E402
from poc.agents import AGENTS                                 # noqa: E402
from poc.calibration import (accuracy_at_threshold,           # noqa: E402
                             directional_correct, forward_return_traded)
from poc.contract import ROW_FIELDS, AgentState               # noqa: E402
from poc.datalayer import DataLayer                           # noqa: E402
from poc.state import build_index_persistence, build_state    # noqa: E402
from poc.universe import dev_universe                         # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("symbols", nargs="*", help="tickers; default is the dev universe")
    ap.add_argument("--all", action="store_true", help="every candidate security")
    ap.add_argument("--dataset", default=None, help="FYP Dataset root")
    ap.add_argument("--out", default=None, help="output directory")
    ap.add_argument("--with-tau", action="store_true",
                    help="include tau in the L_t composite (OPEN in the pre-registration)")
    ap.add_argument("--no-garch", action="store_true", help="EWMA instead of GJR-GARCH in A_V")
    args = ap.parse_args()

    root = Path(args.dataset) if args.dataset else config.DATASET_ROOT
    out = Path(args.out) if args.out else config.OUT
    (out / "state").mkdir(parents=True, exist_ok=True)
    (out / "agents").mkdir(parents=True, exist_ok=True)

    dl = DataLayer(root)
    if args.symbols:
        symbols = args.symbols
    elif args.all:
        import csv as _csv
        with open(root / "extracted" / "reference" / "security_master.csv", newline="") as fh:
            symbols = [r["symbol"] for r in _csv.DictReader(fh)
                       if r["candidate_universe"] == "True"]
    else:
        symbols = dev_universe(root)

    lt_inputs = config.LT_INPUTS_WITH_TAU if args.with_tau else config.LT_INPUTS
    agents = [A(use_garch=not args.no_garch) if A.__name__ == "VolatilityAgent" else A()
              for A in AGENTS]

    print(f"dataset   : {root}")
    print(f"universe  : {len(symbols)} securities")
    print(f"L_t inputs: {', '.join(lt_inputs)}")
    print(f"A_V model : {'EWMA' if args.no_garch else 'GJR-GARCH(1,1), EWMA fallback'}")
    print(f"estimator : {config.VOL_ESTIMATOR} (frozen); returns {config.RETURN_BASIS}, "
          f"benchmark {config.BENCHMARK}")
    print()

    idx_d, idx_dates = build_index_persistence(dl)
    summary: list[dict] = []
    t0 = time.time()

    for s, sym in enumerate(symbols, 1):
        try:
            st = build_state(dl, sym, lt_inputs=lt_inputs,
                             index_persistence=idx_d, index_dates=idx_dates)
        except FileNotFoundError as exc:
            print(f"  [{s:>3}/{len(symbols)}] {sym:<14} SKIPPED: {exc}")
            continue

        # ---- state
        with open(out / "state" / f"{sym}.csv", "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["date", "L", "L_full_sample", "L_pca", "V", "P", "P_se", "P_source",
                        "traded"])
            traded = np.nan_to_num(st.aligned["traded"], nan=0.0)
            for i, d in enumerate(st.dates):
                w.writerow([d.isoformat(), _f(st.L[i]), _f(st.L_full[i]), _f(st.L_pca[i]),
                            _f(st.V[i]),
                            _f(st.P[i]), _f(st.P_se[i]), st.P_source[i], int(traded[i])])

        # ---- agents, then calibration
        close = np.asarray(st.aligned["adj_close"], dtype=float)
        fwd, _ = forward_return_traded(close)

        rows: list[dict] = []
        per_agent: dict[str, dict] = {}
        for agent in agents:
            outputs = agent.run(dl, sym, st)
            sig = np.array([o.signal if o.state in (AgentState.OK, AgentState.ABSTAIN)
                            else np.nan for o in outputs])
            raw = np.array([o.confidence_raw if o.confidence_raw is not None else np.nan
                            for o in outputs])
            correct = directional_correct(sig, fwd)
            mech = [o.diagnostics.get("conf_mechanism") if o.diagnostics else None
                    for o in outputs]
            group = np.array(mech, dtype=object) if any(m is not None for m in mech) else None
            cal = accuracy_at_threshold(raw, correct, group=group)
            for o, c in zip(outputs, cal):
                rows.append(o.with_calibrated(None if not np.isfinite(c) else float(c)).as_row())
            per_agent[agent.name] = {
                "n": len(outputs),
                "ok": sum(o.state is AgentState.OK for o in outputs),
                "abstain": sum(o.state is AgentState.ABSTAIN for o in outputs),
                "no_data": sum(o.state is AgentState.NO_DATA for o in outputs),
                "cal": int(np.isfinite(cal).sum()),
                "hit": float(np.nanmean(correct)) if np.isfinite(correct).any() else np.nan,
            }

        extra = sorted({k for r in rows for k in r if k.startswith("diag_")})
        with open(out / "agents" / f"{sym}.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(ROW_FIELDS) + extra, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)

        rec = {"symbol": sym, "days": len(st.dates),
               "traded": int(np.nansum(st.aligned["traded"])),
               "L_obs": int(np.isfinite(st.L).sum()),
               "V_obs": int(np.isfinite(st.V).sum()),
               "P_obs": int(np.isfinite(st.P).sum()),
               "P_counter_rows": int((st.P_source == "counter").sum()),
               "P_index_rows": int((st.P_source == "index").sum())}
        for name, a in per_agent.items():
            rec |= {f"{name}_ok": a["ok"], f"{name}_abstain": a["abstain"],
                    f"{name}_no_data": a["no_data"], f"{name}_calibrated": a["cal"],
                    f"{name}_hit": round(a["hit"], 4) if np.isfinite(a["hit"]) else ""}
        summary.append(rec)

        print(f"  [{s:>3}/{len(symbols)}] {sym:<14} days={rec['days']:>5} "
              f"traded={rec['traded']:>5}  L={rec['L_obs']:>5} V={rec['V_obs']:>5} "
              f"P={rec['P_obs']:>5}(counter {rec['P_counter_rows']})  "
              + "  ".join(f"{n}:{a['ok']}/{a['abstain']}/{a['no_data']}"
                          for n, a in per_agent.items()))

    if summary:
        with open(out / "run_summary.csv", "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(summary[0]))
            w.writeheader()
            w.writerows(summary)

    print(f"\n{len(summary)} securities in {time.time() - t0:.1f}s -> {out}")
    print("agent columns are ok/abstain/no_data")
    return 0


def _f(x) -> str:
    return "" if x is None or not np.isfinite(x) else f"{x:.10g}"


if __name__ == "__main__":
    raise SystemExit(main())

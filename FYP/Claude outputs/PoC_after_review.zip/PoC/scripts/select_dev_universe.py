"""Print the dev universe and why each security is in it.

    python scripts/select_dev_universe.py

Three per float-adjusted liquidity quintile, sampled at evenly spaced ranks within each
quintile so the selection is deterministic and has no seed. The point is to exercise
every code path, including the thin counters where the agents are most likely to break
and where the contribution is supposed to matter most.
"""
from __future__ import annotations

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from poc import config          # noqa: E402
from poc.universe import dev_universe   # noqa: E402


def main() -> int:
    root = Path(sys.argv[1]) if len(sys.argv) > 1 else config.DATASET_ROOT
    syms = dev_universe(root)
    with open(root / "extracted" / "liquidity" / "strata.csv", newline="") as fh:
        strata = {r["security"]: r for r in csv.DictReader(fh)}
    with open(root / "extracted" / "reference" / "security_master.csv", newline="") as fh:
        master = {r["symbol"]: r for r in csv.DictReader(fh)}

    print(f"{'symbol':<14}{'Q':>2}{'float-adj turnover':>20}{'traded':>8}{'freq':>7}{'stale':>8}")
    for s in syms:
        st, m = strata[s], master[s]
        print(f"{s:<14}{st['quintile_float_adjusted']:>2}"
              f"{float(st['float_adjusted_turnover']):>20,.0f}"
              f"{int(m['window_traded_days']):>8}"
              f"{float(m['window_trading_frequency']):>7.3f}"
              f"{float(st['stale_close_rate'] or 0):>8.3f}")
    print(f"\n{len(syms)} securities. strata.csv is whole-sample (DC-36): fine for")
    print("choosing a universe, which is a design choice made once, and not a model input.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

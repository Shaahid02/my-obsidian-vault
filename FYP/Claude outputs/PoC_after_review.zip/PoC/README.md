# PoC: market-state-conditioned orchestration of heterogeneous agents

The proof of concept for the CSE multi-agent orchestrator: three of the four agents, the
state vector they are weighted against, the weighting function itself, and the five-arm
harness that tests whether the weighting earns its place.

**Headline result: all six acceptance criteria pass and the pre-registered decision rule
fails.** Those are different questions. The mechanism demonstrably exists and responds to
measured market state; it does not beat its own baselines. See *What the arms show*.

```
A_T technical ┐
A_V volatility ├──► contract ──► calibration ──► c_i,t ─┐
A_L liquidity ┘                                          ├──► orchestrator ──► decision
L_t composite · V_t volatility · P_t persistence ────────┘          │
                                                                     └──► B1 B2 B3 P O
                                                                          ablations
```

It reads the `FYP Dataset` repository and never writes to it.

## Running it

```bash
pip install -r requirements.txt
export FYP_DATASET="D:/FYP Dataset"        # or edit poc/config.py

python scripts/run_agents.py               # the 15-counter dev universe
python scripts/run_agents.py --all         # all 233 candidates, about 25 minutes
python scripts/run_arms.py                 # five arms, ablations, sweeps, acceptance
python scripts/run_arms.py --quick         # one seed, no parameter sweeps
python scripts/run_arms.py --l-column L_pca  # robustness: rolling PC1 as L_t, to out/arms_L_pca
python -m pytest tests/ -q
```

Outputs land in `out/`: `state/` (L_t, V_t, P_t and the full-sample comparison),
`agents/` (one contract row per agent per trading day), and `arms/` (fold results,
ablations, the sweeps, the weight trace, and `acceptance.txt`).

Agents run once here and the arms consume this cache. That is what acceptance check A5
requires: outputs must be byte-identical across the five arms, which is only achievable
if they are produced once and read rather than recomputed per arm.

## The as-of cursor

`11 Architecture and Indicative Solution` specifies one interface and calls each of its
three properties a requirement rather than a convenience. All three are enforced here:

| Property | How |
|---|---|
| No component receives a dataframe | `query` returns `Rows`, a column-oriented read-only view. `frame()` exists for tests and returns a copy |
| Data beyond the cursor raises, it does not warn | `CursorViolation`, including for a cursor past the analysis window end |
| An agent cannot widen its own window | Agents receive an `AsOfView`, which is the layer bound to one date. Its `query` takes no date, so an agent has no way to name one. Only the runner holds the `DataLayer` |

The agents build their series in one pass rather than being called date by date, which
would otherwise weaken the second property into an honour system. So the guarantee is
tested rather than asserted: `tests/test_causality.py` rebuilds each agent against a data
layer truncated to a sampled date and requires the output on that date to be identical to
what the full run produced. `test_full_sample_composite_is_not_causal` is the control. If
it ever passes, the lookahead comparison below has stopped measuring anything.

## What is frozen here, and where it came from

| Decision | Value | Source |
|---|---|---|
| Return basis and benchmark | price-only `adj_close`, ASPI | DC-41, 6 November. **Supersedes** the 1 November line in `11 Architecture` making `tr_close`/ASTRI primary |
| Volatility estimator | Parkinson | `11 Architecture` Part 5. Garman-Klass needs the open, and the official opens are blank or degenerate across 2017, 2018, 2021 Q1 and 2025 |
| Panel end | 2026-06-30 | DC-27 |
| Conformal depth rule | 1250 days; below it A_V falls back to rolling QLIKE and is **not** excluded | Pre-registration, fixed 1 November |
| L_t inputs | Amihud, turnover ratio, zero-return frequency, high-low range. tau excluded | Pre-registration: tau is a candidate, not a member. `--with-tau` to include it |
| Fold protocol | 1250 train / 125 test / step 125, 16 folds, indexed on trading days | Settled 1 November, `Dataset Reconciliation` §5 |
| Primary metric | cost-adjusted return over the window, abstained days held flat | Fixed 24 October, confirmed 29 October |
| Margin rule | median per-fold delta must exceed the baseline's per-fold IQR, **and** the paired test must clear alpha. Both halves | Fixed 24 October, defined 1 November |
| Significance | HAC paired test plus stationary bootstrap, alpha 0.05 | Fixed |
| Orchestrator fit | FFORMA weighted loss: sum over t,i of w_i(x_t) times agent i's own loss, plus L2 | Chosen in this build. `Research Matrices Status` names FFORMA as the nearest ancestor of w_i,t |
| Orchestrator pooling | one set of (beta, gamma) fitted across securities, not per security | Chosen in this build. The gap statement is about one mechanism conditioned on state |

Two values in `poc/config.py` stay `None` on purpose, because no value for either exists
in the vault. Rather than assert one, both are computed both ways and reported: the
abstention floor phi through `ORCH_PHI_SWEEP` (knee at 0.02), and the abstained-day
exposure policy through both `hold` and `flat` in the cost sweep (identical here, since
coverage is 1.000).

## Design decisions made in this build

Three choices the vault does not settle. Each is recorded because it changes how an
ablation should be read.

**A_V's signal is a defensive vote.** The contract asks every channel for a direction and
a risk model does not naturally produce one. A_V votes against exposure in proportion to
how elevated its one-step forecast is relative to that counter's own recent norm. So
removing A_V removes a volatility-scaled exposure brake, not a view on direction.

**A_L's evidence overlaps the state vector by design.** L_t is both this agent's input and
one of the variables the orchestrator conditions on, which is Sub-gap 1's claim that one
measurement should be used twice. It does mean the L_t ablation and an A_L on/off ablation
are not independent, and the ablation table has to say so.

**"Correct" has one definition across the pool**, so the calibrated numbers answer the
same question from different evidence: did the sign of the signal match the sign of the
next adjusted return. Exactly-zero returns are excluded rather than scored as misses,
because a zero return here usually means a single trade at the previous price and scoring
it as a miss would penalise thin counters for their thinness (DC-37: 6.42% of rows carry
a stale close).

**L_t's inputs are trailing-window statistics, not daily values.** Found during the first
run. The dataset's `amihud` column is defined on one-day returns only (DC-34), so on a
thin counter it is missing most days; requiring the raw column on the same day as the
other three left the composite undefined for 82% of a 61%-traded counter's life, which is
exactly the regime the contribution is about. Amihud and turnover ratio are now trailing
20-day means with a minimum count, matching the other two inputs, which are already
frequencies. Coverage on the thinnest dev counter went from 18% to 41% of its span.

## What the first run shows

Recorded on the pre-review build. L_t has since changed (FIXES.md fix 1): the coverage and
lookahead figures below describe the PCA composite, which is now kept as `L_pca` for
robustness, not the primary L_t.

Fifteen counters, three per float-adjusted liquidity quintile, 2012-01 to 2026-06.

**A_T abstains more on liquid counters than thin ones.** Theil U2 crosses 1 on 66% of
VONE's days (the most liquid in the set) against 39% of YORK's. The random walk is harder
to beat where prices actually move every day. A_T is deliberately plain, so this is the
channel behaving as specified rather than failing.

**Calibrated confidence sits near one half.** c_i,t means are 0.537 (A_T), 0.499 (A_V),
0.508 (A_L), spanning 0.21 to 0.86. The accuracy-at-threshold transform is reporting that
directional prediction on this market is close to a coin flip, which is the honest answer
and the reason the transform exists.

**The lookahead a naive composite would inject is measurable and uneven.** Correlation
between the as-of-correct L_t and the full-sample PCA version runs 0.756 to 0.997 with a
median of 0.919. The counters where the two diverge most are not the thinnest, which is
worth following up before the composite is used in anger.

**L_t coverage is the binding constraint on A_L**, at 41% to 71% of each counter's span.
About 1,000 days of that is structural warm-up: a 750-day minimum block before the first
principal component plus a 250-day z-score window. The rest is thin trading. A_L has no
signal for much of a thin counter's life and that has to be reported by stratum rather
than averaged away.

## Layout

```
poc/
  config.py        paths, frozen parameters with their sources, and the OPEN ones
  contract.py      AgentOutput, AgentState; the invariants are enforced, not trusted
  datalayer.py     DataLayer, AsOfView, Rows, CursorViolation
  features.py      causal helpers; every one is checked by truncation in the tests
  state.py         L_t (signed z-score composite; L_pca kept), V_t (Parkinson), P_t (GPH d)
  calibration.py   the accuracy-at-threshold transform and the shared "correct"
  universe.py      dev universe selection
  agents/          base, technical, volatility, liquidity
  panel.py         cached agent output assembled for fitting; conviction scales
  orchestrator.py  s_i,t, the softmax floor, the liquidity coupling, FFORMA fit
  arms.py          B1, B2, B3, P, O and the Stock and Watson sweep
  folds.py         the walk-forward protocol
  evaluate.py      metrics, the pre-registered rule, HAC and bootstrap, diagnostics
scripts/run_agents.py, scripts/run_arms.py
tests/
```

`poc/state.py` does not read `strata.csv` and `datalayer.py` does not expose it. Those
strata are whole-sample medians (DC-36 records them as descriptive rather than
walk-forward), which makes them fine for choosing a universe and not fine as a model
input. `test_strata_are_not_reachable_through_the_data_layer` holds that line.

## What the arms show

Fifteen counters, 16 walk-forward folds of 1250 train / 125 test / step 125 indexed on
trading days, five seeds, 50 bps on turnover, after every fix in `FIXES.md`. Mean per fold
over folds and seeds. `out/arms/acceptance.txt` is the full report.

| arm | net | gross | cost | turnover | hit | MCC | entropy | params |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| B1 equal weight | **+0.1752** | +1.3952 | 1.220 | 244 | 0.5333 | +0.0672 | 1.098 | 0 |
| B2 static learned | -0.1198 | +1.6462 | 1.766 | 353 | 0.5309 | +0.0679 | 0.696 | 2 |
| B3 discounted inverse-MSE | +0.0921 | +1.1417 | 1.050 | 210 | 0.5263 | +0.0502 | 0.956 | 0 |
| P state-conditioned | -0.2308 | +1.4990 | 1.730 | 346 | 0.5357 | +0.0686 | 0.645 | 11 |
| O oracle | -0.1087 | +1.4175 | 1.526 | 305 | 0.5342 | +0.0628 | 0.592 | 11 |

Parameter counts are identified parameters: the softmax ignores a common shift in scores,
so one agent's betas are not identified, giving (K - 1)p + K = 11 for P.

**The pre-registered rule fails on both halves.** The median per-fold delta of P against
B1 is -0.286 against a baseline IQR of 0.683. On the daily portfolio P&L difference (1,999
trading days), P is below B1 on all three tests: HAC p 0.016, stationary bootstrap p 0.030,
per-fold paired t p 0.048. P beats B1 in 3 of 16 folds. The standing caution applies to
these p-values: the weights are estimated and correlated with the forecasts, so the
standard errors are approximations.

**The deficit is cost, not direction.** P has the highest hit rate and MCC of the five arms,
and in the cost sweep (seed 0, summed over folds) it beats B1 at 0 bps, +23.98 against
+22.32. By 25 bps B1 is ahead and by 50 bps P is the worst arm. P concentrates weight
(entropy 0.645 against ln 3 = 1.099), so votes cancel less, positions are larger (mean
|position| 0.380 against 0.269) and turnover is 42% higher. My reading: on this agent set
the conditioning buys a small directional edge that does not pay for the trading it causes
at 50 bps. Cost inside the decision objective (§6.5) is the extension that would address
this, and it is not built here.

**The oracle beats P but not B1.** O - P is +0.122, so part of P's deficit is estimation.
O is still below B1 and above P in only 8 of 16 folds. Part 7's reading table says a gain
in O with none in P is an estimation problem; here O gains over P but not over the
baseline, so on these counters I read the evidence as weak support for estimation being
part of the problem and no support for the conditioning hypothesis beating equal weights.

**Removing L_t helps P.** The P-L ablation improves P by +0.053; V_t, P_t and confidence
each move it by less than 0.005; removing the liquidity coupling costs 0.026. A3 passes
(largest weight swing 0.54 as L_t moves from its 5th to 95th percentile), so the weights
respond to L_t. Responding is not the same as helping, and on this panel the response to
L_t lowers net return. The L_pca robustness run agrees in direction (P -0.260, B1 +0.159,
P-L delta +0.203) on 27,720 rather than 30,960 usable rows.

**The abstention criterion removes the most accurate channel.** A_T abstains on 53% of
usable rows under U2 >= 1. On those rows its hit rate is 0.5345, above A_V (0.4992) and
A_L (0.5109) over all their rows. Routing that abstention correctly (fix 2) was the
largest single movement in the result. The criterion is pre-registered and unchanged.

**Both sweeps point toward equal weighting.** Raising phi or L2 moves P's weights toward
equal and improves net return monotonically on the last 8 folds; phi = 1/3 reproduces B1
exactly. No sign flip across eight L2 values. Worst per-fold seed spread is 0.0024, all
fits converged.

The pre-registration anticipated an outcome of this kind: an answer on a thin frontier
market is a contribution even if the answer is that equal weights win, provided the margin
and the test were written down before the run. They were. What this run supports is
bounded: 15 dev counters, three agents without A_F, one cost assumption as primary, and an
agent set and conditioning set that are themselves provisional.

### What the abstention machinery is not doing

Coverage is 1.000 in every arm, so the system never abstains and the hold-against-flat
exposure question has no effect here (the two rows of the cost sweep are identical). Only
A_T has an abstention rule; A_V and A_L have none, so there is always an agent in state
`ok`. The abstention routing is exercised for one agent out of three. That is a gap in the
agent set rather than in the orchestrator.

## Not built here

A_F, the fundamental agent. Its corpus exists (22,893 documents, 2012-01 to 2026-10,
roughly 340 counters, each filename carrying the announcement date) but the agent is not
built. It is absent from `poc.agents.AGENTS` rather than stubbed, so that an on/off
ablation cannot report a zero delta from a stub as though it were a finding.

Cost inside the decision objective (§6.5) is out of scope for this pass, but the design
does not foreclose it: `Orchestrator.propose` returns the allocation before it is
committed, which is what the extension needs.

## Language

No absolutes. The permitted form is "I have not found that evaluation in the literature I
have covered". Every figure above is a measurement on this dataset over this window and
is scoped to it. The agent set and the conditioning set remain provisional.

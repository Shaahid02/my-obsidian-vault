"""A_T, the technical agent.

Deliberately plain, and that is a design decision rather than laziness (§5.2). The
contribution under test is the orchestration, not the technical channel. A strong A_T
would make any improvement harder to attribute to the weighting function, which is the
thing the five arms and four ablations exist to isolate.

Confidence is Theil's U2 against the random walk:

    U2 = sqrt( sum (y_hat - y)^2 ) / sqrt( sum (y_naive - y)^2 )

On returns the random walk forecast is zero, so the denominator is the realised return
itself. U2 >= 1 means the channel does not beat "tomorrow is like today", and it then
abstains. Abstention shrinks it toward the floor phi rather than zeroing it (§6.3),
because individually poor forecasts can still help in combination.
"""
from __future__ import annotations

import numpy as np
from sklearn.linear_model import Ridge

from .. import config, features
from ..datalayer import DataLayer
from ..state import StateSeries
from .base import Agent, compact, scatter, traded_mask


class TechnicalAgent(Agent):
    name = "A_T"

    def __init__(self, fit_window: int = config.AT_FIT_WINDOW,
                 refit_every: int = config.AT_REFIT_EVERY,
                 ridge_alpha: float = config.AT_RIDGE_ALPHA,
                 u2_window: int = config.AT_U2_WINDOW,
                 u2_abstain: float = config.AT_U2_ABSTAIN,
                 signal_sigma: float = config.AT_SIGNAL_SIGMA) -> None:
        self.fit_window = fit_window
        self.refit_every = refit_every
        self.ridge_alpha = ridge_alpha
        self.u2_window = u2_window
        self.u2_abstain = u2_abstain
        self.signal_sigma = signal_sigma

    # ------------------------------------------------------------------ core

    def _series(self, dl: DataLayer, ticker: str, state: StateSeries) -> dict[str, np.ndarray]:
        n = len(state.dates)
        idx, (close, high, low, vol, low_price) = compact(
            state, "adj_close", "adj_high", "adj_low", "adj_share_volume", "low_price")
        m = len(close)

        X, _names = features.technical_features(close, high, low, vol)
        r = features.log_return(close)
        # y[i] is the return realised at i+1, so it is not observable until i+1.
        y = np.full(m, np.nan)
        y[:-1] = r[1:]
        sigma = features.rolling_std(r, 60, min_periods=30)

        pred = np.full(m, np.nan)
        model = None
        self._refits = self._refit_skipped = 0
        cols = np.arange(X.shape[1])

        for t in range(m):
            # Refit from a trailing window whose targets have all resolved by t.
            # The newest usable pair is (X[t-2], y[t-2]), realised at t-1.
            if t >= 60 and (t % self.refit_every == 0):
                hi = t - 1                                  # exclusive
                lo = max(0, hi - self.fit_window)
                Xtr, ytr = X[lo:hi], y[lo:hi]
                good = np.isfinite(Xtr).all(axis=1) & np.isfinite(ytr)
                if good.sum() >= 120:
                    Xg = Xtr[good]
                    keep = cols[np.nanstd(Xg, axis=0) > 0]
                    if len(keep) >= 2:
                        # Standardise with the TRAINING window's moments before the ridge
                        # penalty. FIXES.md fix 12: the raw columns span a 220:1 range of
                        # scales, so a single alpha shrank the range and volatility features
                        # almost to nothing while leaving the z-scored ones untouched. The
                        # penalty had no scale-free meaning.
                        mu = Xg[:, keep].mean(axis=0)
                        sd = Xg[:, keep].std(axis=0)
                        mdl = Ridge(alpha=self.ridge_alpha)
                        mdl.fit((Xg[:, keep] - mu) / sd, ytr[good])
                        model = (mdl, keep, mu, sd)
                        self._refits += 1
                    else:
                        self._refit_skipped += 1
                else:
                    self._refit_skipped += 1
            if model is not None and np.isfinite(X[t][model[1]]).all():
                mdl, keep, mu, sd = model
                pred[t] = float(mdl.predict(((X[t][keep] - mu) / sd).reshape(1, -1))[0])

        # Theil U2 over a trailing window of resolved forecasts.
        u2 = np.full(m, np.nan)
        err2 = np.where(np.isfinite(pred) & np.isfinite(y), (pred - y) ** 2, np.nan)
        base2 = np.where(np.isfinite(pred) & np.isfinite(y), y ** 2, np.nan)
        for t in range(m):
            hi = t - 1
            lo = max(0, hi - self.u2_window)
            if hi - lo < 30:
                continue
            e, b = err2[lo:hi], base2[lo:hi]
            ok = np.isfinite(e) & np.isfinite(b)
            if ok.sum() < 30:
                continue
            denom = np.sqrt(np.nansum(b[ok]))
            if denom <= 0:
                continue
            u2[t] = float(np.sqrt(np.nansum(e[ok])) / denom)

        scale = self.signal_sigma * sigma
        with np.errstate(divide="ignore", invalid="ignore"):
            sig = np.clip(pred / np.where(scale > 0, scale, np.nan), -1.0, 1.0)

        ok_c = np.isfinite(sig)
        abstain_c = ok_c & np.isfinite(u2) & (u2 >= self.u2_abstain)

        return {
            "signal": scatter(idx, sig, n),
            "confidence_raw": scatter(idx, u2, n),
            "ok": scatter(idx, ok_c.astype(float), n) == 1.0,
            "abstain": scatter(idx, abstain_c.astype(float), n) == 1.0,
            "pred_return": scatter(idx, pred, n),
            "sigma_60": scatter(idx, sigma, n),
            "low_price": scatter(idx, low_price, n),
            # A_T keeps predicting from its last model if later refits cannot run; these
            # make that visible rather than silent (review finding).
            "ridge_refits": np.full(n, float(self._refits)),
            "ridge_refits_skipped": np.full(n, float(self._refit_skipped)),
        }


__all__ = ["TechnicalAgent"]

"""The agent base class.

Each agent produces its whole series for a ticker in one pass. That is not a shortcut
around the cursor, it is what acceptance check A5 requires: agent outputs must be
byte-identical across all five arms, which is only achievable if the agents run once and
every arm consumes the same cache.

The as-of guarantee is kept in two ways rather than asserted:

  * every series an agent builds is causal by construction, and anything fitted is refit
    on a schedule from a trailing window that ends at the fit date;
  * `emit_at` rebuilds the agent against a data layer truncated to one date and returns
    that date's output, so the single-date path is the *same code* as the batch path.
    `tests/test_causality.py` compares the two across sampled dates, which is what makes
    the guarantee checkable instead of claimed.
"""
from __future__ import annotations

import datetime as dt
from abc import ABC, abstractmethod

import numpy as np

from ..contract import AgentOutput, AgentState
from ..datalayer import DataLayer
from ..state import StateSeries, build_state


class Agent(ABC):
    """One evidence channel, emitting the common output contract."""

    #: Short name used in cached output and in the ablation tables.
    name: str = "A_?"

    # ------------------------------------------------------------- interface

    @abstractmethod
    def _series(self, dl: DataLayer, ticker: str, state: StateSeries) -> dict[str, np.ndarray]:
        """Compute signal, confidence_raw and any diagnostics, aligned to state.dates.

        Must return at least {"signal": ..., "confidence_raw": ..., "ok": ...} where
        `ok` is a boolean array marking the rows on which the channel has something to
        say. Everything else in the dict is carried into diagnostics.
        """

    # ----------------------------------------------------------------- batch

    def run(self, dl: DataLayer, ticker: str, state: StateSeries) -> list[AgentOutput]:
        """Every output for one ticker, one row per official trading day in its span."""
        s = self._series(dl, ticker, state)
        signal = s["signal"]
        conf = s["confidence_raw"]
        ok = s["ok"]
        abstain = s.get("abstain", np.zeros(len(signal), dtype=bool))
        diag_keys = [k for k in s if k not in ("signal", "confidence_raw", "ok", "abstain",
                                               "why")]
        why = s.get("why")

        out: list[AgentOutput] = []
        for i, d in enumerate(state.dates):
            if not ok[i] or not np.isfinite(signal[i]):
                reason = (str(why[i]) if why is not None and i < len(why)
                          else "no usable evidence at this date")
                out.append(AgentOutput.no_data(self.name, ticker, d, reason))
                continue
            diagnostics = {}
            for k in diag_keys:
                v = s[k][i]
                diagnostics[k] = None if isinstance(v, float) and not np.isfinite(v) else v
            out.append(AgentOutput(
                agent=self.name,
                ticker=ticker,
                as_of=d,
                signal=float(np.clip(signal[i], -1.0, 1.0)),
                confidence_raw=float(conf[i]) if np.isfinite(conf[i]) else None,
                state=AgentState.ABSTAIN if abstain[i] else AgentState.OK,
                diagnostics=diagnostics,
            ))
        return out

    # ------------------------------------------------------------ single date

    def emit_at(self, dataset_root, ticker: str, as_of: dt.date,
                window_start: str | None = None, **state_kw) -> AgentOutput:
        """Rebuild against a data layer that ends at `as_of`, and return that date's output.

        Deliberately the same code path as `run`, so there is no second implementation
        that could drift from the first. Slow, and meant for tests and spot checks.
        """
        from .. import config as _cfg
        dl = DataLayer(dataset_root,
                       window_start=window_start or _cfg.WINDOW_START,
                       window_end=as_of.isoformat())
        state = build_state(dl, ticker, **state_kw)
        outputs = self.run(dl, ticker, state)
        if not outputs or outputs[-1].as_of != as_of:
            raise LookupError(f"{ticker}: no output at {as_of}")
        return outputs[-1]


# --------------------------------------------------------------- shared tools

def traded_mask(state: StateSeries) -> np.ndarray:
    # Cast to float first: nan_to_num passes object arrays through untouched, and
    # bool(nan) is True, so a column that arrived as strings would mark every day traded.
    return np.nan_to_num(np.asarray(state.aligned["traded"], dtype=float), nan=0.0) > 0


def compact(state: StateSeries, *fields: str) -> tuple[np.ndarray, list[np.ndarray]]:
    """The traded-day subseries, and the positions it occupies on the calendar spine.

    Features are computed on traded days because that is the economically meaningful
    series: a counter that did not trade produced no new price information. A return on
    this series runs from one traded close to the next, however many calendar days apart,
    which is the same definition the evaluation uses for outcomes
    (calibration.forward_return_traded). Treating that as a one-day move does overstate a
    thin counter's daily volatility; the alternative, a forward-filled calendar series,
    understates it with runs of zero returns. Neither is free, and the choice is recorded
    rather than hidden.
    """
    m = traded_mask(state)
    idx = np.flatnonzero(m)
    return idx, [np.asarray(state.aligned[f], dtype=float)[idx] for f in fields]


def scatter(idx: np.ndarray, values: np.ndarray, n: int) -> np.ndarray:
    """Put a traded-day series back on the calendar spine, NaN elsewhere."""
    out = np.full(n, np.nan)
    out[idx] = values
    return out

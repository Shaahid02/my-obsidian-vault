"""A_L, the liquidity agent.

Signal from the L_t composite (§5.2: "computed from the composite, emitting a directional
view"). Higher L_t means worse liquidity by construction, so A_L votes against exposure as
liquidity deteriorates relative to the counter's own recent norm.

**The overlap with the state vector is real and is recorded rather than hidden.** L_t is
both this agent's evidence and one of the variables the orchestrator conditions on. That
is by design: Sub-gap 1's claim is that one measurement should be used twice, once for
what a trade costs and once for how far price-derived evidence can be trusted. It does
mean the L_t ablation and the A_L on/off ablation are not independent, and the diagnostics
below carry what is needed to say so when the ablation table is read.

Confidence is a rolling loss ratio against a fixed benchmark, which makes it unit-free:
the agent's directional error rate over a trailing window divided by the 0.5 a coin flip
would produce. Below 1 the channel is beating chance on its own calls; above 1 it is not.
"""
from __future__ import annotations

import numpy as np

from .. import config, features
from ..calibration import forward_return
from ..datalayer import DataLayer
from ..state import StateSeries
from .base import Agent, compact, scatter


class LiquidityAgent(Agent):
    name = "A_L"

    def __init__(self, state_window: int = config.AL_STATE_WINDOW,
                 signal_z: float = config.AL_SIGNAL_Z,
                 loss_window: int = config.AL_LOSS_WINDOW) -> None:
        self.state_window = state_window
        self.signal_z = signal_z
        self.loss_window = loss_window

    def _series(self, dl: DataLayer, ticker: str, state: StateSeries) -> dict[str, np.ndarray]:
        n = len(state.dates)
        idx, (close,) = compact(state, "adj_close")

        # L_t lives on the calendar spine; take its traded-day values so the signal is
        # scored against traded-day returns rather than across non-trading gaps.
        L_c = np.asarray(state.L, dtype=float)[idx]
        z = features.zscore_rolling(L_c, self.state_window,
                                    min_periods=max(60, self.state_window // 4))
        sig = -np.clip(z / self.signal_z, -1.0, 1.0)

        # Rolling loss ratio against a fixed benchmark. The outcome of a call made at i
        # is not resolved until i+1, so the window ends at t-1.
        fwd = forward_return(close)
        m = len(close)
        wrong = np.full(m, np.nan)
        usable = np.isfinite(sig) & np.isfinite(fwd) & (fwd != 0.0) & (sig != 0.0)
        wrong[usable] = (np.sign(sig[usable]) != np.sign(fwd[usable])).astype(float)

        loss_ratio = np.full(m, np.nan)
        for t in range(m):
            hi = t - 1
            lo = max(0, hi - self.loss_window)
            w = wrong[lo:hi] if hi > lo else np.array([])
            w = w[np.isfinite(w)]
            if len(w) < 40:
                continue
            loss_ratio[t] = float(np.mean(w) / 0.5)

        amihud = np.asarray(state.aligned["amihud"], dtype=float)[idx]
        stale = np.asarray(state.aligned["close_outside_range"], dtype=float)[idx]

        ok_c = np.isfinite(sig)
        return {
            "signal": scatter(idx, sig, n),
            "confidence_raw": scatter(idx, loss_ratio, n),
            "ok": scatter(idx, ok_c.astype(float), n) == 1.0,
            "L_z": scatter(idx, z, n),
            "amihud": scatter(idx, amihud, n),
            "stale_close": scatter(idx, stale, n),
        }


__all__ = ["LiquidityAgent"]

"""A_V, the volatility agent.

GJR-GARCH(1,1) on the adjusted return series, refit on a schedule, with an EWMA fallback
when the fit fails. V_t itself is Parkinson (frozen in config); the GARCH model is what
gives A_V a *forward* view rather than a trailing measurement.

**What a volatility agent's directional signal means.** The contract asks every channel
for a signal in [-1, 1], and a risk model does not naturally produce a direction. The
mapping chosen here is a defensive vote: A_V votes against exposure in proportion to how
elevated its one-step forecast is relative to that counter's own recent norm, and towards
exposure when the forecast is unusually quiet. This is a design decision, not a reading
of the literature, and it is recorded here because it affects how the A_V ablation should
be interpreted: removing A_V removes a volatility-scaled exposure brake, not a view on
direction.

Confidence is the realised width of an adaptive conformal interval at target coverage, so
a drifted model reports wider intervals and down-weights itself with nobody asking it
anything. Per the pre-registration (fixed 1 November), counters with fewer than
`CONFORMAL_MIN_DAYS` days of history are evaluated *without* the conformal input and fall
back to a rolling QLIKE loss. They are not excluded, and which mechanism was used is
recorded per row so the affected count can be reported by liquidity stratum.
"""
from __future__ import annotations

import warnings

import numpy as np

from .. import config, features
from ..datalayer import DataLayer
from ..state import StateSeries
from .base import Agent, compact, scatter

try:  # pragma: no cover - import guard
    from arch import arch_model
    _HAVE_ARCH = True
except Exception:  # pragma: no cover
    _HAVE_ARCH = False


def _scatter_obj(idx: np.ndarray, values: np.ndarray, n: int) -> np.ndarray:
    out = np.full(n, None, dtype=object)
    out[idx] = values
    return out


class VolatilityAgent(Agent):
    name = "A_V"

    def __init__(self, fit_window: int = config.AV_FIT_WINDOW,
                 refit_every: int = config.AV_REFIT_EVERY,
                 state_window: int = config.AV_STATE_WINDOW,
                 signal_z: float = config.AV_SIGNAL_Z,
                 conformal_min_days: int = config.CONFORMAL_MIN_DAYS,
                 alpha: float = config.CONFORMAL_ALPHA,
                 use_garch: bool = True) -> None:
        self.fit_window = fit_window
        self.refit_every = refit_every
        self.state_window = state_window
        self.signal_z = signal_z
        self.conformal_min_days = conformal_min_days
        self.alpha = alpha
        self.use_garch = use_garch and _HAVE_ARCH

    # ---------------------------------------------------------------- models

    def _garch_forecast(self, r: np.ndarray) -> np.ndarray:
        """One-step-ahead conditional sigma, refit every `refit_every` traded days.

        sigma_hat[t] is the forecast *for* t made from returns up to t-1, so it is
        usable at t.

        On a refit day the emitted value is arch's own one-step forecast, which already
        conditions on r[t-1]. Between refits the fitted GJR recursion is rolled forward:

            h_t = omega + (alpha + gamma * 1[e_{t-1} < 0]) * e_{t-1}^2 + beta * h_{t-1}

        with e = r - mu, because arch fits a constant mean by default and its omega,
        alpha, gamma and beta describe the centred residual, not the raw return.

        FIXES.md fix 3 corrected two defects here. A refit day used to store arch's
        forecast and then advance it once more on r[t-1], counting that return twice;
        the error then decayed over the following refit interval at rate beta. And the
        recursion used the raw return where the parameters require r - mu.

        A failed or rejected fit leaves the previous parameters in place. Both outcomes
        are counted and reported in diagnostics rather than written and never read.
        """
        m = len(r)
        out = np.full(m, np.nan)
        params = None            # (omega, alpha, gamma, beta, mu) in return units
        var = np.nan
        fails = stale = 0
        for t in range(m):
            refit_today = False
            if t >= 250 and (t % self.refit_every == 0):
                lo = max(0, t - self.fit_window)
                hist = r[lo:t]
                hist = hist[np.isfinite(hist)]
                if len(hist) >= 200 and np.std(hist) > 0:
                    try:
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore")
                            res = arch_model(hist * 100.0, mean="Constant", vol="GARCH",
                                             p=1, o=1, q=1, dist="t",
                                             rescale=False).fit(disp="off", show_warning=False)
                        v = float(res.forecast(horizon=1, reindex=False).variance.values[-1, 0])
                        v /= 10000.0
                        pp = res.params
                        cand = (float(pp["omega"]) / 10000.0, float(pp["alpha[1]"]),
                                float(pp["gamma[1]"]), float(pp["beta[1]"]),
                                float(pp["mu"]) / 100.0)
                        if np.isfinite(v) and v > 0 and all(np.isfinite(cand)):
                            params, var, refit_today = cand, v, True
                        else:
                            stale += 1
                    except Exception:
                        fails += 1
                else:
                    stale += 1
            if params is None:
                continue
            if not refit_today:
                omega, a, g, b, mu = params
                prev = r[t - 1] if t > 0 else np.nan
                if np.isfinite(prev):
                    e = prev - mu
                    var = omega + (a + (g if e < 0 else 0.0)) * e * e + b * var
                # A missing return leaves the variance where it was rather than
                # pretending a zero shock was observed.
            out[t] = np.sqrt(max(var, 1e-12))
        self._garch_fails = fails
        self._garch_stale = stale
        return out

    # ------------------------------------------------------------------ core

    def _series(self, dl: DataLayer, ticker: str, state: StateSeries) -> dict[str, np.ndarray]:
        n = len(state.dates)
        idx, (close, high, low) = compact(state, "adj_close", "adj_high", "adj_low")
        m = len(close)
        r = features.log_return(close)

        # EWMA shifted by one day, so that like the GARCH forecast the value used at t
        # conditions on returns up to t-1. FIXES.md fix 3: unshifted, the fallback rows
        # (the first 250 traded days of every counter) followed a different timing
        # convention from the GARCH rows, inside one series.
        ewma = np.sqrt(features.ewma_var(r))
        ewma = np.concatenate([[np.nan], ewma[:-1]]) if len(ewma) else ewma
        if self.use_garch:
            sigma_f = self._garch_forecast(r)
            model_used = "gjr_garch"
        else:
            sigma_f = ewma.copy()
            model_used = "ewma"
            self._garch_fails = self._garch_stale = 0
        # Wherever the model has nothing, fall back to EWMA rather than emitting nothing.
        used_fallback = ~np.isfinite(sigma_f) & np.isfinite(ewma)
        sigma_f = np.where(np.isfinite(sigma_f), sigma_f, ewma)

        # Signal: a defensive vote against exposure when the forecast is elevated
        # relative to this counter's own recent norm.
        with np.errstate(divide="ignore", invalid="ignore"):
            log_sigma = np.log(np.where(sigma_f > 0, sigma_f, np.nan))
        z = features.zscore_rolling(log_sigma, self.state_window,
                                    min_periods=max(60, self.state_window // 4))
        sig = -np.clip(z / self.signal_z, -1.0, 1.0)

        # Confidence: adaptive conformal interval width, or QLIKE below the depth rule.
        #
        # The depth rule is applied per row, on the traded days available AT that row.
        # FIXES.md fix 4: it used to count the whole series, so a counter that eventually
        # crossed the threshold was treated as having crossed it from its first day, which
        # is lookahead (46% of traded days on the dev universe were affected). Row t of the
        # compact series is the (t+1)-th traded day.
        depth = np.arange(1, m + 1)
        use_conformal = depth >= self.conformal_min_days
        conf = np.where(use_conformal, self._conformal_width(r, sigma_f),
                        self._qlike(r, sigma_f))
        mech = np.where(use_conformal, "conformal", "qlike_fallback").astype(object)

        ok_c = np.isfinite(sig)
        return {
            "signal": scatter(idx, sig, n),
            "confidence_raw": scatter(idx, conf, n),
            "ok": scatter(idx, ok_c.astype(float), n) == 1.0,
            "sigma_forecast": scatter(idx, sigma_f * np.sqrt(config.ANNUALISATION), n),
            "sigma_z": scatter(idx, z, n),
            "conf_mechanism": _scatter_obj(idx, mech, n),
            "model": np.array([model_used] * n, dtype=object),
            "ewma_fallback": scatter(idx, used_fallback.astype(float), n),
            "garch_fit_failures": np.full(n, float(self._garch_fails)),
            "garch_fits_rejected": np.full(n, float(self._garch_stale)),
        }

    # ----------------------------------------------------------- confidence

    def _conformal_width(self, r: np.ndarray, sigma: np.ndarray) -> np.ndarray:
        """Running (1 - alpha) quantile of |standardised residual|, times the forecast.

        A model that has drifted produces standardised residuals that are too large, the
        quantile rises, the interval widens, and the agent's confidence falls out of the
        arithmetic without anyone asking the model how sure it is.
        """
        m = len(r)
        out = np.full(m, np.nan)
        with np.errstate(divide="ignore", invalid="ignore"):
            z = np.abs(r) / np.where(sigma > 0, sigma, np.nan)
        for t in range(m):
            hi = t                               # residual at t-1 is resolved at t
            lo = max(0, hi - self.fit_window)
            w = z[lo:hi]
            w = w[np.isfinite(w)]
            if len(w) < 100 or not np.isfinite(sigma[t]):
                continue
            out[t] = float(np.quantile(w, 1.0 - self.alpha) * sigma[t])
        return out

    def _qlike(self, r: np.ndarray, sigma: np.ndarray) -> np.ndarray:
        """Rolling QLIKE loss of the variance forecast. Lower is better.

        The fallback for counters below the conformal depth threshold. It is a different
        quantity from an interval width, which does not matter: the accuracy-at-threshold
        transform only asks what accuracy followed scores near this one, so it is
        indifferent to the unit and to the direction of the raw score.
        """
        m = len(r)
        out = np.full(m, np.nan)
        with np.errstate(divide="ignore", invalid="ignore"):
            var = np.where(sigma > 0, sigma ** 2, np.nan)
            loss = np.log(var) + (r ** 2) / var
        for t in range(m):
            hi = t
            lo = max(0, hi - 250)
            w = loss[lo:hi]
            w = w[np.isfinite(w)]
            if len(w) < 60:
                continue
            out[t] = float(np.mean(w))
        return out


__all__ = ["VolatilityAgent"]

"""The data layer and the as-of cursor.

`11 Architecture and Indicative Solution` specifies one interface with a signature:

    DataLayer.query(ticker, fields, as_of) -> Rows

with three properties, each a requirement rather than a convenience:

  * No component ever receives a dataframe. Every component receives a query, which is
    what makes the cursor enforceable at one place instead of four.
  * Any row whose timestamp exceeds `as_of` raises `CursorViolation`. It raises rather
    than warns, because a warning in a long backtest is a silent failure.
  * `as_of` is supplied by the simulation clock, not by the caller's own state, so an
    agent cannot widen its own window.

The third property is the one that needs teeth. An agent handed a date could pass a
different one, so agents are handed an `AsOfView` instead: a binding of this layer to one
date, whose `query` takes no date at all. An agent has no way to name a date, which makes
point-in-time correctness a property of the system rather than a discipline.

This is the piece that cannot be retrofitted once agents have been built against raw
frames, which is why it is built before any agent (PoC Build Plan §4).
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
import pandas as pd

from . import config


class CursorViolation(RuntimeError):
    """A query would have returned, or was asked for, data beyond the as-of cursor."""


class UnknownField(KeyError):
    """A field name that no source provides. Raised rather than returning nothing."""


# --------------------------------------------------------------------- sources

#: Which file each field comes from. Six column names appear in both panels; each is
#: assigned one canonical owner here and the other is reachable as "liquidity.close"
#: and so on. A field absent from this map raises UnknownField rather than silently
#: yielding an empty column.
_ADJUSTED_FIELDS = (
    "open", "high", "low", "close",
    "open_source", "low_price", "adj_factor", "adj_open", "adj_high", "adj_low",
    "adj_close", "adj_share_volume", "tr_factor", "tr_close",
)
_LIQUIDITY_FIELDS = (
    # Volume fields resolve to the calendar-aligned panel, which carries an explicit zero
    # on days the counter did not trade. Routed to the adjusted panel, those informative
    # zeros became absent rows: 12% of calendar rows, in a study whose conditioning
    # variable is liquidity (review finding B6).
    "turnover", "share_volume", "trade_volume",
    "traded", "cross_volume", "cross_turnover", "cross_trades", "cross_flag",
    "volume_ex_cross", "turnover_ex_cross", "trades_ex_cross", "shares_outstanding",
    "shares_source", "turnover_ratio", "float", "float_quarter",
    "float_turnover_ratio", "close_outside_range", "ret", "ret_days", "amihud",
    "rel_volume_20",
)

FIELD_SOURCE: dict[str, str] = (
    {f: "adjusted" for f in _ADJUSTED_FIELDS} | {f: "liquidity" for f in _LIQUIDITY_FIELDS}
)

_SOURCE_DIR = {
    "adjusted": config.ADJUSTED_DIR,
    "liquidity": config.LIQUIDITY_DIR,
    "aligned": config.ALIGNED_DIR,
}

#: The adjusted panel carries traded days only; the liquidity panel is calendar-aligned.
#: Anything that needs a row on every trading day must come from the liquidity source.
CALENDAR_ALIGNED = {"liquidity", "aligned"}


# ----------------------------------------------------------------------- rows

class Rows:
    """An immutable, column-oriented result. Deliberately not a DataFrame.

    Handing back a frame would let a component re-index, merge or shift it, which is how
    a cursor stops being enforceable at one place. `frame()` exists for notebooks and
    tests and returns a copy.
    """

    __slots__ = ("_dates", "_cols", "_ticker", "_as_of")

    def __init__(self, ticker: str, as_of: dt.date, dates: np.ndarray,
                 cols: dict[str, np.ndarray]) -> None:
        self._ticker = ticker
        self._as_of = as_of
        self._dates = dates
        self._cols = cols

    # ------------------------------------------------------------- accessors

    @property
    def ticker(self) -> str:
        return self._ticker

    @property
    def as_of(self) -> dt.date:
        return self._as_of

    @property
    def dates(self) -> np.ndarray:
        return self._dates

    def __len__(self) -> int:
        return len(self._dates)

    def __contains__(self, field: str) -> bool:
        return field in self._cols

    def __getitem__(self, field: str) -> np.ndarray:
        try:
            return self._cols[field]
        except KeyError:
            raise UnknownField(
                f"{field!r} not in this query; asked for {sorted(self._cols)}"
            ) from None

    def last(self, field: str, default=np.nan):
        """The most recent OBSERVED value of `field` at or before the cursor.

        Skips trailing missing values, which a multi-source query introduces on dates the
        field's own panel lacks. Review finding: this used to return col[-1], which could
        be NaN from alignment and was then indistinguishable from "no data".
        """
        col = self[field]
        if not len(col):
            return default
        try:
            ok = np.flatnonzero(pd.notna(col))
        except TypeError:
            return col[-1]
        return col[ok[-1]] if len(ok) else default

    def frame(self) -> pd.DataFrame:
        """A copy, for tests and exploration. Not what components receive."""
        return pd.DataFrame(dict(self._cols), index=pd.DatetimeIndex(self._dates, name="date"))

    def __repr__(self) -> str:
        return (f"Rows({self._ticker}, as_of={self._as_of}, n={len(self)}, "
                f"fields={sorted(self._cols)})")


# ------------------------------------------------------------------ as-of view

class AsOfView:
    """The data layer bound to one date. This is what an agent receives.

    There is no method here that takes a date, so an agent cannot widen its own window
    through this interface. Only the runner holds the `DataLayer` and only the runner
    advances the clock.

    Stated precisely, since the review found the earlier wording too strong: this makes
    widening the window impossible by accident, not by intent. Python cannot stop code
    that deliberately reaches `view._dl`. That is why the as-of guarantee is also tested
    by truncation (tests/test_causality.py), which catches a leak however it arises.
    """

    __slots__ = ("_dl", "_as_of")

    def __init__(self, dl: "DataLayer", as_of: dt.date) -> None:
        self._dl = dl
        self._as_of = as_of

    @property
    def as_of(self) -> dt.date:
        return self._as_of

    def query(self, ticker: str, fields: Sequence[str], source: str | None = None) -> Rows:
        return self._dl.query(ticker, fields, self._as_of, source=source)

    def index(self, fields: Sequence[str]) -> Rows:
        return self._dl.index(fields, self._as_of)

    def __repr__(self) -> str:
        return f"AsOfView({self._as_of})"


# ------------------------------------------------------------------ data layer

class DataLayer:
    """Per-security panels, the market indices and the trading calendar, behind one cursor."""

    def __init__(self, dataset_root: Path | str | None = None,
                 window_start: str = config.WINDOW_START,
                 window_end: str = config.WINDOW_END) -> None:
        root = Path(dataset_root) if dataset_root is not None else config.DATASET_ROOT
        self.root = root
        self._dirs = {
            "adjusted": root / "extracted" / "adjusted" / "adjusted_daily_prices",
            "liquidity": root / "extracted" / "liquidity" / "daily",
            "aligned": root / "extracted" / "aligned_daily_prices",
        }
        self._indices_csv = root / "extracted" / "indices" / "market_indices.csv"
        self._calendar_csv = root / "extracted" / "trading_days" / "trading_days_all.csv"
        self.window_start = pd.Timestamp(window_start).date()
        self.window_end = pd.Timestamp(window_end).date()
        self._cache: dict[tuple[str, str], pd.DataFrame] = {}
        self._indices: pd.DataFrame | None = None
        self._calendar: list[dt.date] | None = None

    # ------------------------------------------------------------- calendar

    @property
    def calendar(self) -> list[dt.date]:
        """Official trading days inside the window (DC-17, DC-19)."""
        if self._calendar is None:
            raw = pd.read_csv(self._calendar_csv)
            days = pd.to_datetime(raw["Traded Date"].str.strip(), format="%m/%d/%Y")
            d = sorted({x.date() for x in days})
            self._calendar = [x for x in d if self.window_start <= x <= self.window_end]
        return self._calendar

    def at(self, as_of: dt.date) -> AsOfView:
        """Bind the layer to one date. The result is what agents receive."""
        return AsOfView(self, self._check_cursor(as_of))

    def _check_cursor(self, as_of) -> dt.date:
        """Validate and NORMALISE the cursor, and return it.

        Review finding: the datetime case used to be normalised into a local variable and
        then discarded, so a Timestamp passed `at()` and every query from that view raised
        a TypeError from inside pandas instead of CursorViolation.
        """
        if isinstance(as_of, dt.datetime):
            as_of = as_of.date()
        if not isinstance(as_of, dt.date):
            raise CursorViolation(f"as_of must be a date, got {type(as_of)!r}")
        if as_of > self.window_end:
            raise CursorViolation(
                f"as_of {as_of} is beyond the analysis window end {self.window_end} (DC-27)"
            )
        if as_of < self.window_start:
            raise CursorViolation(
                f"as_of {as_of} is before the analysis window start {self.window_start}; "
                "a clock wired up wrongly would otherwise return empty queries silently"
            )
        return as_of

    # ---------------------------------------------------------------- loading

    def _load(self, ticker: str, source: str) -> pd.DataFrame:
        key = (ticker, source)
        if key in self._cache:
            return self._cache[key]
        path = self._dirs[source] / f"{ticker}.csv"
        if not path.exists():
            raise FileNotFoundError(f"no {source} panel for {ticker}: {path}")
        df = pd.read_csv(path, parse_dates=["date"])
        df = df.set_index("date").sort_index()
        df = df.loc[str(self.window_start):str(self.window_end)]
        self._cache[key] = df
        return df

    @staticmethod
    def _resolve(fields: Sequence[str], source: str | None) -> dict[str, list[str]]:
        """Group requested fields by the source that owns them."""
        by_source: dict[str, list[str]] = {}
        for f in fields:
            if "." in f:                       # explicit escape hatch, e.g. "liquidity.close"
                src, name = f.split(".", 1)
                if src not in _SOURCE_DIR:
                    raise UnknownField(f"unknown source {src!r} in {f!r}")
            elif source is not None:
                src, name = source, f
            else:
                try:
                    src, name = FIELD_SOURCE[f], f
                except KeyError:
                    raise UnknownField(
                        f"{f!r} is not a field of any panel. Use 'source.field' to be explicit."
                    ) from None
            by_source.setdefault(src, []).append(name)
        return by_source

    # ------------------------------------------------------------------ query

    def query(self, ticker: str, fields: Sequence[str], as_of: dt.date,
              source: str | None = None) -> Rows:
        """Rows for `ticker` at or before `as_of`. The documented interface.

        Raises CursorViolation if anything beyond the cursor survives the filter, which
        would mean the panel or the slice is wrong rather than the caller.
        """
        as_of = self._check_cursor(as_of)
        if isinstance(fields, str):
            fields = [fields]
        by_source = self._resolve(fields, source)

        # Slice every source first, then align all of them on the UNION of their dates,
        # in date order. Review finding: the first-listed source used to fix the index, so
        # the same two fields in a different order returned a different number of rows
        # (89% of probe queries), and the second source's rows outside it were dropped.
        slices = []
        seen: dict[str, str] = {}
        for src, names in by_source.items():
            for n in names:
                if n in seen and seen[n] != src:
                    raise UnknownField(
                        f"{n!r} requested from both {seen[n]!r} and {src!r}; the result "
                        "has one column per name, so query them separately")
                seen[n] = src
            df = self._load(ticker, src)
            missing = [n for n in names if n not in df.columns]
            if missing:
                raise UnknownField(f"{ticker}: {missing} not in the {src} panel")
            sliced = df.loc[df.index.date <= as_of, names]
            if len(sliced) and sliced.index.max().date() > as_of:
                raise CursorViolation(
                    f"{ticker}/{src}: row at {sliced.index.max().date()} exceeds cursor {as_of}"
                )
            slices.append((names, sliced))

        index = pd.DatetimeIndex([])
        for _, sl in slices:
            index = index.union(sl.index)
        cols: dict[str, np.ndarray] = {}
        for names, sl in slices:
            joined = sl.reindex(index) if len(slices) > 1 else sl
            for n in names:
                cols[n] = joined[n].to_numpy()

        dates = np.array([x.date() for x in index], dtype=object)
        if len(dates) and dates[-1] > as_of:
            raise CursorViolation(f"{ticker}: assembled rows exceed cursor {as_of}")
        return Rows(ticker, as_of, dates, cols)

    # ---------------------------------------------------------------- indices

    def index(self, fields: Sequence[str], as_of: dt.date) -> Rows:
        """Cleaned market index series (DC-39, DC-40), under the same cursor."""
        as_of = self._check_cursor(as_of)
        if isinstance(fields, str):
            fields = [fields]
        if self._indices is None:
            df = pd.read_csv(self._indices_csv, parse_dates=["date"]).set_index("date").sort_index()
            self._indices = df.loc[str(self.window_start):str(self.window_end)]
        df = self._indices
        missing = [f for f in fields if f not in df.columns]
        if missing:
            raise UnknownField(f"{missing} not in market_indices.csv")
        sliced = df.loc[df.index.date <= as_of, list(fields)]
        if len(sliced) and sliced.index.max().date() > as_of:
            raise CursorViolation(f"index rows exceed cursor {as_of}")
        dates = np.array([x.date() for x in sliced.index], dtype=object)
        return Rows("__index__", as_of, dates, {f: sliced[f].to_numpy() for f in fields})

    # ------------------------------------------------------------- inventory

    def available(self, source: str = "adjusted") -> list[str]:
        d = self._dirs[source]
        return sorted(p.stem for p in d.glob("*.csv"))



__all__ = [
    "DataLayer", "AsOfView", "Rows", "CursorViolation", "UnknownField", "FIELD_SOURCE",
]

"""Market-state-conditioned orchestration of heterogeneous agents: the PoC build.

This package stops at the state vector. The orchestrator, the five arms and the
ablations consume what it produces and are built on top of it.
"""
__version__ = "0.1.0"

"""The state vector: L_t, V_t, P_t.

These are the measured market-state inputs the weighting function conditions on,

    s_i,t = beta_i' x_t + gamma_i c_i,t,   x_t = [1, L_t, V_t, P_t]'

so every one of them has to be as-of correct or the mechanism is measuring its own
lookahead. The orchestrator is not built here; this module produces the series it reads.

One thing this module deliberately does not read: `extracted/liquidity/strata.csv`.
Those strata are whole-sample medians (DC-36 records them as descriptive rather than
walk-forward). They are fine for choosing a universe, which is a declared design choice
made once, and they are not fine as a model input. Keeping them out of the data layer is
what stops the distinction eroding.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from . import config, features
from .datalayer import AsOfView, DataLayer

#: Columns pulled per source. Liquidity is calendar-aligned and is the spine.
_LIQ_FIELDS = ("traded", "amihud", "turnover_ratio", "float_turnover_ratio",
               "rel_volume_20", "ret", "ret_days", "close_outside_range",
               "volume_ex_cross", "turnover_ex_cross")
_ADJ_FIELDS = ("adj_high", "adj_low", "adj_close", "adj_share_volume", "low_price")


@dataclass
class StateSeries:
    """Per-ticker state, one row per official trading day in the ticker's span."""

    ticker: str
    dates: np.ndarray
    L: np.ndarray            # liquidity composite, equal-weighted signed z-scores (as-of)
    L_full: np.ndarray       # full-sample construction. Diagnostic only, never an input
    V: np.ndarray            # Parkinson volatility, annualised
    P: np.ndarray            # GPH d on |returns|
    P_se: np.ndarray
    P_source: np.ndarray     # per row: "counter", "index" or "none"
    L_pca: np.ndarray | None = None   # the pre-registered PCA composite, for robustness
    inputs: dict[str, np.ndarray] = field(default_factory=dict)
    aligned: dict[str, np.ndarray] = field(default_factory=dict)
    loadings: list = field(default_factory=list)   # (row, PC1 loadings, ambiguous) per refit

    def index_of(self, as_of: dt.date) -> int:
        """Position of the last row at or before the cursor, or -1 if none."""
        pos = np.searchsorted(self.dates, as_of, side="right") - 1
        return int(pos)

    def at(self, as_of: dt.date) -> dict[str, float]:
        i = self.index_of(as_of)
        if i < 0:
            return {"L": np.nan, "V": np.nan, "P": np.nan}
        return {"L": float(self.L[i]), "V": float(self.V[i]), "P": float(self.P[i])}


# ------------------------------------------------------------- L_t composite

def _signed_inputs(liq: dict[str, np.ndarray], adj: dict[str, np.ndarray],
                   names: tuple[str, ...]) -> dict[str, np.ndarray]:
    """Step 1 of the BIS recipe: sign every input so that higher means worse.

    "Worse" is less liquid throughout, so a measure that rises with liquidity is negated
    and a measure that rises with illiquidity is left alone.
    """
    traded = np.nan_to_num(np.asarray(liq["traded"], dtype=float), nan=0.0) > 0
    ret = liq["ret"].astype(float)

    out: dict[str, np.ndarray] = {}
    if "amihud" in names:
        # Price impact per unit turnover. Rises with illiquidity. De-skewed because it is
        # heavily right-skewed (to 10,365 on EMER) and the next step is a z-score.
        # FIXES.md 1b: the earlier log1p was a near-identity at these magnitudes
        # (turnover_ratio has medians of 1e-6 to 1e-4), so it did nothing.
        #
        # Taken as a trailing mean rather than the day's value. L_t is a state variable,
        # and the dataset's `amihud` column is defined on one-day returns only (DC-34),
        # so on a thin counter it is missing on most days. Requiring the raw column left
        # the composite undefined for 82% of a 61%-traded counter's life, which is
        # precisely the regime the contribution is about. A trailing window with a
        # minimum count keeps it defined wherever there is any evidence, and honestly
        # undefined where there is none.
        a = liq["amihud"].astype(float)
        a = features.asinh_scaled(np.where(a >= 0, a, np.nan))
        out["amihud"] = features.rolling_mean(a, 20, min_periods=5)
    if "turnover_ratio" in names:
        tr = liq["turnover_ratio"].astype(float)
        tr = -features.asinh_scaled(np.where(tr >= 0, tr, np.nan))   # higher turnover is better
        out["turnover_ratio"] = features.rolling_mean(tr, 20, min_periods=5)
    if "zero_return_freq" in names:
        # A zero return on a day the counter actually traded. Non-traded days are a
        # different thing and are excluded rather than counted as zeros (DC-26).
        zero = np.where(traded, (ret == 0).astype(float), np.nan)
        out["zero_return_freq"] = features.rolling_frac(zero, 60, min_periods=20)
    if "hl_range" in names:
        # Parkinson range on the adjusted bar, not annualised: a wide range on little
        # volume is the thin-book signature.
        out["hl_range"] = features.parkinson_vol(adj["adj_high"], adj["adj_low"],
                                                 20, annualise=None)
    if "tau_zero_freq" in names:
        # OPEN in the pre-registration block: tau is a candidate rather than a member of
        # the composite, so it is off by default (config.LT_INPUTS).
        hi, lo = adj["adj_high"].astype(float), adj["adj_low"].astype(float)
        prev_close = np.concatenate([[np.nan], adj["adj_close"].astype(float)[:-1]])
        tau_zero = np.where(traded & np.isfinite(hi) & np.isfinite(lo),
                            ((hi == lo) & (lo == prev_close)).astype(float), np.nan)
        out["tau_zero_freq"] = features.rolling_frac(tau_zero, 60, min_periods=20)
    return out


def _pc1_scores(Z: np.ndarray, min_block: int, refit_every: int):
    """First principal component over an expanding window, and the full-sample version.

    The expanding series is the one the orchestrator may read: at t the loadings come
    from the most recent refit using rows at or before t. The full-sample series uses
    every row including future ones and exists only so the two can be plotted together,
    which is direct evidence of how much lookahead a naive construction would inject
    (PoC Specification §6.1).

    PC1's sign is arbitrary, so it is fixed by requiring a positive correlation with the
    mean of the signed inputs, which keeps "higher means worse" true of the output too.
    """
    n, k = Z.shape
    rolling = np.full(n, np.nan)
    loadings = None
    history: list[tuple[int, np.ndarray, bool]] = []

    def fit(block: np.ndarray, prev: np.ndarray | None) -> tuple[np.ndarray, bool] | None:
        ok = np.isfinite(block).all(axis=1)
        if ok.sum() < max(30, 3 * k):
            return None
        B = block[ok]
        B = B - B.mean(axis=0)
        try:
            _, _, vt = np.linalg.svd(B, full_matrices=False)
        except np.linalg.LinAlgError:
            return None
        w = vt[0]
        # For the leading eigenvector, sign(sum of loadings) is the same test as a positive
        # correlation between the score and the row mean of the signed inputs, so this is
        # the "higher means worse" anchor. It is ill-determined when the loadings nearly
        # cancel, and then orientation is carried forward from the previous refit instead,
        # so that L_t cannot change sign between refits for no reason in the data.
        ambiguous = abs(w.sum()) < 0.2 * np.abs(w).sum()
        if ambiguous and prev is not None:
            if np.dot(w, prev) < 0:
                w = -w
        elif w.sum() < 0:
            w = -w
        return w, bool(ambiguous)

    for t in range(n):
        if t + 1 >= min_block and (t + 1 - min_block) % refit_every == 0:
            res = fit(Z[: t + 1], loadings)
            if res is not None:
                loadings = res[0]
                history.append((t, loadings.copy(), res[1]))
        if loadings is not None and np.isfinite(Z[t]).all():
            rolling[t] = float(Z[t] @ loadings)

    full = np.full(n, np.nan)
    res = fit(Z, None)
    if res is not None:
        ok = np.isfinite(Z).all(axis=1)
        full[ok] = Z[ok] @ res[0]
    return rolling, full, history


# ------------------------------------------------------------------- builder

def build_state(dl: DataLayer, ticker: str,
                lt_inputs: tuple[str, ...] = config.LT_INPUTS,
                index_persistence: np.ndarray | None = None,
                index_dates: np.ndarray | None = None) -> StateSeries:
    """Build L_t, V_t and P_t for one ticker over its whole span.

    Every component is causal, so computing the series once and indexing into it at each
    cursor is equivalent to recomputing it at every step. `tests/test_causality.py`
    checks that rather than assuming it.
    """
    end = dl.window_end
    liq_rows = dl.query(ticker, list(_LIQ_FIELDS), end, source="liquidity")
    adj_rows = dl.query(ticker, list(_ADJ_FIELDS), end, source="adjusted")

    dates = liq_rows.dates
    liq = {f: liq_rows[f] for f in _LIQ_FIELDS}

    # The adjusted panel carries traded days only; project it onto the calendar spine.
    pos = {d: i for i, d in enumerate(adj_rows.dates)}
    take = np.array([pos.get(d, -1) for d in dates], dtype=int)
    adj = {}
    for f in _ADJ_FIELDS:
        col = adj_rows[f].astype(float)
        out = np.full(len(dates), np.nan)
        hit = take >= 0
        out[hit] = col[take[hit]]
        adj[f] = out

    # --- L_t
    signed = _signed_inputs(liq, adj, lt_inputs)
    Z = np.column_stack([
        features.zscore_expanding(signed[n], min_periods=config.LT_ZSCORE_MIN)
        for n in lt_inputs if n in signed
    ])
    # Primary composite: the equal-weighted mean of the signed, expanding-z-scored inputs.
    #
    # DEVIATION FROM THE PRE-REGISTRATION, recorded 24 November 2026 (FIXES.md, fix 1a).
    # The recipe takes the first principal component. On this panel PC1 is frequently not
    # a common illiquidity factor: 389 of 1,495 refits across the dev universe (26%, and
    # 100% of HUNT's) load at least one "higher means worse" input negatively, so L_t was
    # a contrast between inputs rather than a measure of illiquidity, and it reversed sign
    # whenever that contrast rotated (VONE 2016-04-05, YORK 2021-06-30 and 2021-08-06).
    # An equal-weighted mean is monotone in every input on every counter by construction,
    # means the same thing across counters, which matters because the orchestrator is
    # fitted pooled across them, and has no orientation to get wrong. The PCA version is
    # still computed and kept as `L_pca` for robustness rather than discarded.
    complete = np.isfinite(Z).all(axis=1)
    L_raw = np.where(complete, Z.mean(axis=1), np.nan)
    L = features.zscore_expanding(L_raw, min_periods=config.LT_ZSCORE_MIN)

    # Full-sample comparison (§6.1): the same construction with full-sample z-scores,
    # which is what a naive build would use. Diagnostic only, never an input.
    Zf = np.column_stack([
        (signed[n] - np.nanmean(signed[n])) / np.nanstd(signed[n])
        for n in lt_inputs if n in signed
    ])
    Lf_raw = np.where(np.isfinite(Zf).all(axis=1), Zf.mean(axis=1), np.nan)
    L_full = (Lf_raw - np.nanmean(Lf_raw)) / np.nanstd(Lf_raw)

    # The pre-registered PCA composite, kept for robustness.
    Lp_raw, _, loading_history = _pc1_scores(Z, config.LT_MIN_BLOCK, config.LT_REFIT_EVERY)
    L_pca = features.zscore_expanding(Lp_raw, min_periods=config.LT_ZSCORE_MIN)

    # --- V_t  (Parkinson, frozen by config.VOL_ESTIMATOR)
    V = features.parkinson_vol(adj["adj_high"], adj["adj_low"], config.VT_WINDOW)

    # Guard against the defect fixed on 24 November: a composite input that is V_t under
    # another name makes liquidity and volatility unidentifiable in x_t. A check on the
    # whole span, not an input, so using all rows here is not lookahead.
    for name, series in signed.items():
        ok = np.isfinite(series) & np.isfinite(V)
        if ok.sum() > 100:
            r = abs(float(np.corrcoef(series[ok], V[ok])[0, 1]))
            if r > config.LT_COLLINEARITY_LIMIT:
                raise ValueError(
                    f"{ticker}: L_t input {name!r} correlates {r:.4f} with V_t; it is a "
                    "volatility measure and cannot enter the liquidity composite")

    # --- P_t
    #
    # Per-counter persistence where the counter has enough history AT THAT ROW, the
    # market-level ASPI estimate below it. FIXES.md fix 4: the choice used to be made once
    # per ticker from the whole series' traded-day count, which is lookahead for every
    # row before the counter actually reached the threshold.
    traded_so_far = np.cumsum(np.nan_to_num(np.asarray(liq["traded"], dtype=float), nan=0.0))
    # GPH runs on the traded-day series, which is genuinely contiguous (fix 11; see
    # features.gph_on_traded). On VONE thinned to HUNT's missingness the calendar version
    # moved mean P_t from 0.283 to 0.253, so it was not comparable across strata.
    P_counter, P_se_counter = features.gph_on_traded(adj["adj_close"], config.PT_WINDOW,
                                                     config.PT_REFIT_EVERY)
    P_index = np.full(len(dates), np.nan)
    if index_persistence is not None and index_dates is not None:
        ipos = {d: i for i, d in enumerate(index_dates)}
        ix = np.array([ipos.get(d, -1) for d in dates], dtype=int)
        hit = ix >= 0
        P_index[hit] = index_persistence[ix[hit]]
    deep = (traded_so_far >= config.PT_MIN_DAYS) & np.isfinite(P_counter)
    P = np.where(deep, P_counter, P_index)
    P_se = np.where(deep, P_se_counter, np.nan)
    p_source = np.where(deep, "counter",
                        np.where(np.isfinite(P_index), "index", "none")).astype(object)

    return StateSeries(
        ticker=ticker, dates=dates, L=L, L_full=L_full, L_pca=L_pca, V=V, P=P, P_se=P_se,
        P_source=p_source,
        loadings=loading_history,
        inputs={n: signed[n] for n in signed},
        aligned={**liq, **adj, "ret_adj": r},
    )


def build_index_persistence(dl: DataLayer) -> tuple[np.ndarray, np.ndarray]:
    """Market-level P_t from the ASPI, used as the fallback below the depth threshold.

    The ASPI is clean across the window (DC-39) and carries roughly 3,500 observations,
    which is what makes d estimable at all where a thin counter's own history is not.
    """
    rows = dl.index([config.BENCHMARK], dl.window_end)
    r = features.log_return(rows[config.BENCHMARK].astype(float))
    d, _ = features.rolling_gph(np.abs(r), config.PT_WINDOW, config.PT_REFIT_EVERY)
    return d, rows.dates


__all__ = ["StateSeries", "build_state", "build_index_persistence"]

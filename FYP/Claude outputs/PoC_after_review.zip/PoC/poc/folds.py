"""The walk-forward fold protocol.

Settled 1 November and recorded in `Dataset Reconciliation 2026-11-01` §5: 1250-day
train, 125-day test, step 125, 16 folds, **indexed on trading days rather than calendar
dates**. That indexing is what keeps the non-contiguous open-price periods from breaking
the protocol: the official opens are blank or degenerate across 2017, 2018, 2021 Q1 and
2025, so a protocol anchored on calendar dates would silently train across those gaps.

Folds are cut on the trading calendar and the panel is sliced by date, so every security
contributes whatever rows it has inside each window. The orchestrator is fitted **pooled
across securities**, which is a design decision: the gap statement is about one mechanism
conditioned on measured state, so one set of (beta, gamma) applied to any counter is the
claim being tested. Fitting per security would be fifteen orchestrators and would put the
parameter count back in the territory the low-capacity choice exists to avoid.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass

import numpy as np

from . import config
from .panel import Panel, agent_loss, conviction_scales


@dataclass
class Fold:
    index: int
    train_start: dt.date
    train_end: dt.date
    test_start: dt.date
    test_end: dt.date

    def __str__(self) -> str:
        return (f"fold {self.index:>2}: train {self.train_start}..{self.train_end}  "
                f"test {self.test_start}..{self.test_end}")


def make_folds(calendar: list[dt.date],
               train: int = config.FOLD_TRAIN,
               test: int = config.FOLD_TEST,
               step: int = config.FOLD_STEP,
               count: int = config.FOLD_COUNT) -> list[Fold]:
    """Cut `count` folds anchored so the final test window ends on the last trading day.

    Anchoring at the end rather than the start means the most recent data is always
    tested, and it makes the protocol stable when the panel is extended.
    """
    need = train + count * step
    if len(calendar) < need:
        raise ValueError(
            f"calendar has {len(calendar)} trading days, protocol needs {need} "
            f"({train} train + {count} x {step})")
    offset = len(calendar) - need
    folds = []
    for k in range(count):
        a = offset + k * step
        folds.append(Fold(
            index=k,
            train_start=calendar[a],
            train_end=calendar[a + train - 1],
            test_start=calendar[a + train],
            test_end=calendar[a + train + test - 1],
        ))
    return folds


def slice_fold(panel: Panel, start: dt.date, end: dt.date,
               state_names: tuple[str, ...] = ("L", "V", "P"),
               loss_scale: float = config.LOSS_SCALE,
               signal_scales: np.ndarray | None = None) -> dict:
    """Everything an arm needs for one window, with unusable rows removed.

    A row is usable when at least one agent votes, the state vector is complete and the
    outcome has resolved. Dropping them here rather than inside each arm is what keeps
    every arm on exactly the same rows, which A5 requires.

    `signal_scales` equalises conviction across agents in the loss. Pass the TRAIN
    window's scales when slicing the test window, or the loss is standardised with
    information from the period being tested.
    """
    f = panel.frame
    in_window = (f["date"].to_numpy() >= start) & (f["date"].to_numpy() <= end)
    keep = in_window & panel.usable()

    sub = Panel(f.loc[keep].reset_index(drop=True), panel.agents)
    signals = sub.matrix("signal")
    fwd = sub.frame["fwd_ret"].to_numpy(dtype=float)
    scales = (conviction_scales(signals, fwd, loss_scale, sub.in_simplex())
              if signal_scales is None else np.asarray(signal_scales, dtype=float))
    return {
        "signal_scales": scales,
        "X": sub.state_vector(state_names),
        "c": sub.matrix("c"),
        "live": sub.in_simplex(),
        "abstain": sub.abstaining(),
        "signals": signals,
        # The signal in the common conviction unit, with the TRAIN window's scales. Both
        # the loss and the position are built from this (FIXES.md fix 7b): the weights are
        # learned against rescaled signals, so applying them to raw signals would size
        # positions by a quantity the orchestrator never saw.
        "vote": np.clip(np.nan_to_num(signals, nan=0.0) * scales[None, :], -1.0, 1.0),
        "loss": agent_loss(signals, fwd, loss_scale, scales),
        "L": sub.frame["L"].to_numpy(dtype=float),
        "fwd_ret": fwd,
        "dates": sub.frame["date"].to_numpy(),
        "tickers": sub.frame["ticker"].to_numpy(),
        "n": len(sub.frame),
    }


__all__ = ["Fold", "make_folds", "slice_fold"]

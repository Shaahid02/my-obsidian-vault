"""The orchestrator: the mechanism the whole project is about.

    s_i,t = beta_i' x_t + gamma_i c_i,t,          x_t = [1, L_t, V_t, P_t]'

    w~_i,t = exp(s_i,t) / sum_{j not in U_t} exp(s_j,t)
    w_i,t  = (1 - K phi) w~_i,t + phi

    Decision_t = sum_i w_i,t A_i,t

Three properties are design decisions on the record, not simplifications.

**Low capacity.** A gated linear form, not a network. The reason is the regularisation
sign-flip observed in the source portfolio work, where the Sharpe ratio reverses sign as
L2 moves from 0.001 to 0.002, on a universe larger and a history longer than the CSE
offers. So the orchestrator's own stability is swept and reported rather than tuned once
(`sweep_regularisation`).

**No pairwise interaction term.** A cited choice: Bates and Granger, Newbold and Granger,
and Winkler and Makridakis all find that ignoring error covariances is the better
practical choice because covariance estimates are unstable. With three agents the full
matrix would cost six parameters against a few hundred effective days.

**Abstention shrinks to a floor rather than to zero**, which is the change Geweke and
Amisano force: individually poor forecasts can still help in combination. The hard zero
is reserved for output that does not parse, which is a different case.

Fitted by the FFORMA objective: minimise the weighted sum of each agent's *own* loss,

    L(theta) = sum_t sum_i w_i(x_t, c_t; theta) * loss_i(t)  +  lambda ||theta||^2

so the orchestrator learns where to put influence conditioned on measured state, rather
than learning to blend. `Research Matrices Status` already names FFORMA as the nearest
named ancestor of w_i,t, which puts the lineage on the record rather than inventing one.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import minimize

from . import config


def softmax_floor(s: np.ndarray, in_simplex: np.ndarray, phi: float,
                  abstain: np.ndarray | None = None) -> np.ndarray:
    """Normalisation with the abstention floor (§6.3).

        w~_i = exp(s_i) / sum over contributing j of exp(s_j)
        w_i  = (1 - K phi) w~_i + phi

    Three cases, and they route differently, which is the point of the contract keeping
    `abstain` and `unparseable` as separate states:

      * outside the simplex (`unparseable`, `no_data`): a hard zero, removed before
        anything else, and not counted in K;
      * abstaining: counted in K and given exactly the floor phi, with w~ = 0. This is
        what "shrink an abstaining agent toward a floor rather than to exactly zero"
        means in the spec, and the change Geweke and Amisano force: individually poor
        forecasts can still help in combination;
      * contributing: shares the remainder by softmax, plus its own floor.

    FIXES.md fix 2: before 24 November the abstain flag never reached this function, so
    an abstaining agent was weighted exactly as though it were in state `ok`.

    If every live agent abstains there is nobody to prefer, so the live set is treated
    as contributing and the row is effectively equal-weighted. phi is capped at 1/K
    against the live K, since 1 - K phi must stay non-negative.
    """
    s = np.asarray(s, dtype=float)
    live = np.asarray(in_simplex, dtype=bool)
    if not np.isfinite(np.where(live, s, 0.0)).all():
        raise ValueError("non-finite score for a live agent; refusing to fall back to "
                         "equal weights silently")
    ab = (np.zeros_like(live) if abstain is None
          else np.asarray(abstain, dtype=bool) & live)
    contributing = live & ~ab
    nobody = ~contributing.any(axis=1, keepdims=True)
    contributing = np.where(nobody, live, contributing)

    K = live.sum(axis=1, keepdims=True).astype(float)
    eff = np.where(K > 0, np.minimum(phi, 1.0 / np.maximum(K, 1.0)), 0.0)

    top = np.max(np.where(contributing, s, -np.inf), axis=1, keepdims=True)
    top = np.where(np.isfinite(top), top, 0.0)
    e = np.where(contributing, np.exp(np.where(contributing, s - top, 0.0)), 0.0)
    total = e.sum(axis=1, keepdims=True)
    w_tilde = np.divide(e, total, out=np.zeros_like(e), where=total > 0)
    return np.where(live, (1.0 - K * eff) * w_tilde + eff, 0.0)


def liquidity_reliability(c: np.ndarray, L: np.ndarray, which: tuple[int, ...],
                          kappa: float = config.COUPLING_KAPPA) -> np.ndarray:
    """C'_i,t = C_i,t * g(L_t), g decreasing in illiquidity (§6.4).

    This is where Sub-gap 1 integrates with the main contribution rather than sitting
    beside it, and it is what acceptance check A3 tests. Poor liquidity does not only
    make a trade expensive, it makes the price-derived evidence supporting that trade
    less trustworthy, because the price series feeding the agent is itself noisier when
    the counter barely trades.

    L_t is z-scored with higher meaning worse, so g is 1 in normal conditions and decays
    as illiquidity rises: g(L) = exp(-kappa * softplus(L)).

    `which` names the price-derived agents by column index. The spec writes C'_{T,t}, so
    A_T alone is the literal reading and the default. A_V's range estimator is arguably
    just as price-derived, which is why extending it is a config flag rather than a
    silent choice.
    """
    out = np.array(c, dtype=float, copy=True)
    Lv = np.asarray(L, dtype=float)
    softplus = np.where(Lv > 30, Lv, np.log1p(np.exp(np.clip(Lv, -30, 30))))
    g = np.exp(-kappa * softplus)
    for j in which:
        out[:, j] = out[:, j] * g
    return out


@dataclass
class OrchestratorFit:
    """Fitted parameters and what they were fitted on."""

    beta: np.ndarray                 # (K, p) including the intercept column
    gamma: np.ndarray                # (K,)
    state_names: tuple[str, ...]
    lam: float
    phi: float
    use_confidence: bool
    coupling: bool
    n_train: int
    loss: float
    seed: int
    converged: bool = True
    history: dict = field(default_factory=dict)

    @property
    def n_params(self) -> int:
        """Identified parameters, not the raw length of theta.

        The softmax is unchanged by adding the same constant to every agent's score, so
        one agent's beta is not identified: (K - 1) * p of the K * p betas are. Review
        finding: reporting K * p overstated the proposal at 15 rather than 11 and the
        static arm at 3 rather than 2, which matters because the low-capacity argument is
        a parameter-count argument.
        """
        K, p = self.beta.shape
        return (K - 1) * p + (self.gamma.size if self.use_confidence else 0)


class Orchestrator:
    """The state-conditioned weighting function.

    Ablations are configuration rather than separate code paths: drop a member of
    `state_names` to ablate that state input, set `use_confidence=False` to ablate
    c_i,t, and set `coupling=False` to ablate the liquidity-to-reliability term. Running
    an ablation through the same object is what makes the deltas attributable.
    """

    def __init__(self, n_agents: int = 3,
                 state_names: tuple[str, ...] = ("L", "V", "P"),
                 lam: float = config.ORCH_L2,
                 phi: float = config.ORCH_PHI_DEFAULT,
                 use_confidence: bool = True,
                 coupling: bool = True,
                 coupled_agents: tuple[int, ...] = config.COUPLED_AGENTS,
                 kappa: float = config.COUPLING_KAPPA) -> None:
        self.n_agents = n_agents
        self.state_names = tuple(state_names)
        self.lam = lam
        self.phi = phi
        self.use_confidence = use_confidence
        self.coupling = coupling
        self.coupled_agents = coupled_agents
        self.kappa = kappa
        self.fit_: OrchestratorFit | None = None
        self._c_fill: np.ndarray | None = None

    # ------------------------------------------------------------- internals

    def _effective_c(self, c: np.ndarray, L: np.ndarray) -> np.ndarray:
        if not self.use_confidence:
            return np.zeros_like(c)
        # A missing calibrated confidence is filled with the agent's own mean over the
        # training window, which is what "uninformative" means for that agent.
        # FIXES.md fix 9: it used to be 0.5, which is not neutral when gamma can take
        # either sign, sat 0.7 sd below A_T's mean, and fired on 11% of A_L's rows,
        # concentrated on the high-illiquidity rows the coupling term is about.
        fill = self._c_fill if self._c_fill is not None else np.full(c.shape[1], 0.5)
        cc = np.where(np.isfinite(c), c, fill[None, :])
        if self.coupling:
            cc = liquidity_reliability(cc, L, self.coupled_agents, self.kappa)
        return cc

    def _scores(self, theta: np.ndarray, X: np.ndarray, c_eff: np.ndarray) -> np.ndarray:
        K, p = self.n_agents, X.shape[1]
        beta = theta[: K * p].reshape(K, p)
        s = X @ beta.T
        if self.use_confidence:
            gamma = theta[K * p: K * p + K]
            s = s + c_eff * gamma[None, :]
        return s

    def _objective(self, theta, X, c_eff, live, loss, abstain=None):
        s = self._scores(theta, X, c_eff)
        w = softmax_floor(s, live, self.phi, abstain)
        obj = float(np.nansum(w * loss) / max(1, len(X)))
        return obj + self.lam * float(theta @ theta)

    # ------------------------------------------------------------------ fit

    def fit(self, X: np.ndarray, c: np.ndarray, live: np.ndarray, loss: np.ndarray,
            L: np.ndarray, seed: int = 0, abstain: np.ndarray | None = None) -> OrchestratorFit:
        """Minimise the FFORMA weighted loss over (beta, gamma) with L2."""
        K, p = self.n_agents, X.shape[1]
        cl = np.where(np.asarray(live, dtype=bool), np.asarray(c, dtype=float), np.nan)
        with np.errstate(invalid="ignore"):
            fill = np.nanmean(cl, axis=0)
        self._c_fill = np.where(np.isfinite(fill), fill, 0.5)
        c_eff = self._effective_c(c, L)
        loss = np.nan_to_num(loss, nan=0.0)

        rng = np.random.default_rng(seed)
        n = K * p + (K if self.use_confidence else 0)
        theta0 = rng.normal(0.0, 0.01, n)

        res = minimize(self._objective, theta0, args=(X, c_eff, live, loss, abstain),
                       method="L-BFGS-B",
                       options={"maxiter": config.ORCH_MAXITER, "ftol": 1e-12})
        theta = res.x
        beta = theta[: K * p].reshape(K, p)
        gamma = theta[K * p: K * p + K] if self.use_confidence else np.zeros(K)

        self.fit_ = OrchestratorFit(
            beta=beta, gamma=gamma, state_names=self.state_names, lam=self.lam,
            phi=self.phi, use_confidence=self.use_confidence, coupling=self.coupling,
            n_train=len(X), loss=float(res.fun), seed=seed, converged=bool(res.success))
        return self.fit_

    # -------------------------------------------------------------- predict

    def weights(self, X: np.ndarray, c: np.ndarray, live: np.ndarray,
                L: np.ndarray, abstain: np.ndarray | None = None) -> np.ndarray:
        if self.fit_ is None:
            raise RuntimeError("orchestrator is not fitted")
        f = self.fit_
        theta = np.concatenate([f.beta.ravel()] + ([f.gamma] if f.use_confidence else []))
        s = self._scores(theta, X, self._effective_c(c, L))
        return softmax_floor(s, live, self.phi, abstain)

    def propose(self, X, c, live, L, signals, abstain=None):
        """Weights and the proposed allocation, *before* it is committed (§6.5).

        The cost-inside-the-objective extension needs the allocation before the decision
        is taken, so the orchestrator exposes both. Returning only a decision would close
        that door, and the spec is explicit that the design must not foreclose it.
        """
        w = self.weights(X, c, live, L, abstain)
        allocation = np.nansum(w * np.nan_to_num(signals, nan=0.0), axis=1)
        return w, np.clip(allocation, -1.0, 1.0)

    def decide(self, X, c, live, L, signals, abstain=None) -> np.ndarray:
        return self.propose(X, c, live, L, signals, abstain)[1]


# ------------------------------------------------------------- diagnostics

def weight_entropy(w: np.ndarray) -> np.ndarray:
    """H_t = -sum_i w_i ln w_i. The entropy-collapse diagnostic (§8.2).

    MacroHFT's own weight trace is near-binary with three of six curves barely off the
    floor, so collapse is observed behaviour in the nearest comparator rather than a
    hypothetical risk.
    """
    w = np.asarray(w, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        terms = np.where(w > 0, w * np.log(w), 0.0)
    return -terms.sum(axis=1)


def sensitivity_to_state(orch: Orchestrator, X_row: np.ndarray, c_row: np.ndarray,
                         live_row: np.ndarray, which: int, grid: np.ndarray,
                         abstain_row: np.ndarray | None = None) -> np.ndarray:
    """Sweep one state input across a grid on a frozen row, holding everything else fixed.

    This is acceptance check A3, and §0 calls it the one that matters: A2 can be
    satisfied by noise, A3 is the mechanism. `which` is the column of x_t to sweep, where
    column 0 is the intercept.
    """
    rows = np.repeat(X_row[None, :], len(grid), axis=0)
    rows[:, which] = grid
    c = np.repeat(np.asarray(c_row, dtype=float)[None, :], len(grid), axis=0)
    live = np.repeat(np.asarray(live_row, dtype=bool)[None, :], len(grid), axis=0)
    L = rows[:, 1] if orch.state_names and orch.state_names[0] == "L" else np.zeros(len(grid))
    ab = (None if abstain_row is None else
          np.repeat(np.asarray(abstain_row, dtype=bool)[None, :], len(grid), axis=0))
    return orch.weights(rows, c, live, L, ab)


__all__ = ["Orchestrator", "OrchestratorFit", "softmax_floor", "liquidity_reliability",
           "weight_entropy", "sensitivity_to_state"]

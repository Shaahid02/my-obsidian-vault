"""Dev universe selection.

Stratified across the float-adjusted liquidity quintiles so that every code path is
exercised, including the thin counters where the agents are most likely to break and
where the contribution is supposed to matter most.

This module reads `strata.csv`, which is built on whole-sample medians (DC-36). That is
acceptable *here* and nowhere else: choosing which securities to develop against is a
design choice made once and declared, not a model input. The data layer does not expose
strata, so an agent cannot reach them.
"""
from __future__ import annotations

import csv
from pathlib import Path

from . import config


def dev_universe(dataset_root: Path | str | None = None, per_quintile: int = 3) -> list[str]:
    """`per_quintile` counters from each float-adjusted quintile, deterministically.

    Within a quintile the members are ordered by float-adjusted turnover and sampled at
    evenly spaced ranks, so the selection has no seed and re-running it cannot drift.
    """
    root = Path(dataset_root) if dataset_root is not None else config.DATASET_ROOT
    strata_csv = root / "extracted" / "liquidity" / "strata.csv"
    master_csv = root / "extracted" / "reference" / "security_master.csv"

    with open(master_csv, newline="") as fh:
        master = {r["symbol"]: r for r in csv.DictReader(fh)}

    rows = []
    with open(strata_csv, newline="") as fh:
        for r in csv.DictReader(fh):
            m = master.get(r["security"])
            if not m or m["candidate_universe"] != "True" or not r["quintile_float_adjusted"]:
                continue
            rows.append((r["security"], int(r["quintile_float_adjusted"]),
                         float(r["float_adjusted_turnover"] or 0.0)))

    out: list[str] = []
    for q in range(1, 6):
        grp = sorted([x for x in rows if x[1] == q], key=lambda x: x[2])
        if not grp:
            continue
        n = len(grp)
        for k in range(per_quintile):
            frac = (k + 1) / (per_quintile + 1)
            out.append(grp[min(n - 1, int(round(frac * (n - 1))))][0])
    return out


__all__ = ["dev_universe"]

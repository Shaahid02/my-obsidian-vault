"""Paths and the frozen parameters.

Two kinds of constant live here and they are not the same thing.

**Frozen** values were decided in advance and are quoted with their source. Changing one
after a run invalidates the attributability argument, which is the whole point of the
pre-registration block in PoC Specification Part 10.

**Open** values are marked OPEN and carry no default that pretends to be a decision.
A run that needs one must be given it explicitly.
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------- paths

#: The FYP Dataset repository. Override with the FYP_DATASET env var.
DATASET_ROOT = Path(
    os.environ.get("FYP_DATASET", r"D:\FYP Dataset")
).expanduser()

EXTRACTED = DATASET_ROOT / "extracted"
ADJUSTED_DIR = EXTRACTED / "adjusted" / "adjusted_daily_prices"
LIQUIDITY_DIR = EXTRACTED / "liquidity" / "daily"
ALIGNED_DIR = EXTRACTED / "aligned_daily_prices"
INDICES_CSV = EXTRACTED / "indices" / "market_indices.csv"
STRATA_CSV = EXTRACTED / "liquidity" / "strata.csv"
SECURITY_MASTER = EXTRACTED / "reference" / "security_master.csv"
CALENDAR_CSV = EXTRACTED / "trading_days" / "trading_days_all.csv"

OUT = ROOT / "out"

# ------------------------------------------------------------------- window

#: DC-27: the analysis panel ends on 2026-06-30. The API tail is a cross-check only.
WINDOW_START = "2012-01-01"
WINDOW_END = "2026-06-30"

# ------------------------------------------------- frozen, with their sources

#: DC-41 (6 November 2026). Price-only is primary, benchmarked against the ASPI.
#: This supersedes the 1 November line in `11 Architecture and Indicative Solution`
#: that made tr_close primary against ASTRI.
RETURN_BASIS = "adj_close"
BENCHMARK = "aspi"

#: PoC Build Plan §3 and `11 Architecture` Part 5. Garman-Klass needs the open, and the
#: official opens are blank or degenerate across 2017, 2018, 2021 Q1 and 2025, so GK
#: would be unavailable over large stretches of the window.
VOL_ESTIMATOR = "parkinson"

#: 240 trading days, matching the profiling scripts in the dataset repo.
ANNUALISATION = 240

#: Pre-registration, fixed 1 November: counters with at least this many days use the
#: conformal method as written. Counters below it are evaluated WITHOUT the conformal
#: confidence input and fall back to the remaining mechanism. They are not excluded,
#: and the affected count is reported by liquidity stratum.
CONFORMAL_MIN_DAYS = 1250
CONFORMAL_ALPHA = 0.10

#: DC-32. At a raw close of Rs 1 or less, one Rs 0.10 tick is a move of 10% or more.
#: These rows are genuine but noisy; spread and volatility estimators stratify on them.
LOW_PRICE_FLAG = "low_price"

# --------------------------------------------------------- agent parameters

#: A_T: ridge on causal features, refit on a schedule, rolling fit window.
AT_FIT_WINDOW = 750
AT_REFIT_EVERY = 25
AT_RIDGE_ALPHA = 1.0
AT_U2_WINDOW = 125
#: §5.2: U2 >= 1 means the channel does not beat "tomorrow is like today".
#: It then abstains, which shrinks it toward the floor rather than zeroing it (§6.3).
AT_U2_ABSTAIN = 1.0
#: Signal scale: forecast return divided by this many rolling sigma saturates the signal.
AT_SIGNAL_SIGMA = 2.0

#: A_V: GJR-GARCH(1,1) refit on a schedule; EWMA fallback when the fit fails.
AV_FIT_WINDOW = 750
AV_REFIT_EVERY = 25
AV_EWMA_LAMBDA = 0.94
AV_STATE_WINDOW = 250
AV_SIGNAL_Z = 2.0

#: A_L: signal from the liquidity composite, confidence from a rolling loss ratio.
AL_STATE_WINDOW = 250
AL_SIGNAL_Z = 2.0
AL_LOSS_WINDOW = 125

# --------------------------------------------------------- state parameters

#: V_t: Parkinson over this many trading days.
VT_WINDOW = 20

#: P_t: GPH on absolute returns over a rolling window. Per counter above
#: CONFORMAL-independent minimum history, index fallback below it.
#: PoC Build Plan §3, corrected 18 October: per-counter history is median ~3,400 days,
#: so d is estimable per counter for well-covered securities.
PT_WINDOW = 750
PT_MIN_DAYS = 1250
PT_REFIT_EVERY = 25

#: L_t: the BIS market-condition-indicator recipe (§6.1). Sign so higher means worse,
#: z-score, first principal component over an expanding window from a three-year block,
#: re-normalise.
LT_MIN_BLOCK = 750          # three years before the first component is produced
LT_REFIT_EVERY = 25         # refit the loadings on a schedule; project daily
LT_ZSCORE_MIN = 250

#: Pre-registration, OPEN: "Amihud, turnover ratio, zero-return frequency and high-low
#: range are settled; tau_t is still a candidate rather than a member."
#: tau is therefore configurable and defaults to excluded.
#:
#: DEVIATION FROM THE PRE-REGISTRATION, recorded 24 November 2026 (FIXES.md, fix 1a).
#: The pre-registration lists "high-low range" as a settled input. As implemented it was
#: a 20-day Parkinson range on the adjusted bar, which is V_t divided by sqrt(240): the
#: two series correlated at 1.000000000000 with a constant ratio on every ticker. That
#: put the volatility regressor inside the liquidity composite, so x_t = [1, L, V, P]
#: could not separate liquidity from volatility, and it is the input that loaded against
#: "higher means worse". A raw range is a volatility measure; the thin-book reading needs
#: a spread estimator that nets volatility out (EDGE or CHL under DC-38), and those
#: series (A6) are not yet built. So the range is removed rather than replaced, and
#: `build_state` refuses any input that is collinear with V_t.
LT_INPUTS = ("amihud", "turnover_ratio", "zero_return_freq")
LT_COLLINEARITY_LIMIT = 0.95
LT_INPUTS_WITH_TAU = LT_INPUTS + ("tau_zero_freq",)

#: Calibration: rolling accuracy-at-threshold curve (§5.3).
CAL_WINDOW = 500
CAL_BINS = 5
CAL_MIN_PER_BIN = 20
CAL_PRIOR_STRENGTH = 10.0   # shrink a thin bin toward the window base rate

# --------------------------------------------------- orchestrator and arms

#: Low capacity by design (§6.3). The L2 value is a starting point and must be SWEPT,
#: not tuned once: the source portfolio work shows the Sharpe ratio reversing sign as L2
#: moves from 0.001 to 0.002, on a larger universe and a longer history than this one.
ORCH_L2 = 1e-3
ORCH_L2_SWEEP = (0.0, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 1e-1)
ORCH_MAXITER = 400

#: Abstention floor. OPEN in the pre-registration, so it is swept and the frontier is
#: reported rather than a value being asserted. phi is capped at 1/K inside
#: `softmax_floor`, since w = (1 - K phi) w~ + phi needs 1 - K phi >= 0.
ORCH_PHI_DEFAULT = 0.05
ORCH_PHI_SWEEP = (0.0, 0.01, 0.02, 0.05, 0.10, 0.15, 0.20, 1.0 / 3.0)

#: Liquidity-to-reliability coupling, g(L) = exp(-kappa * softplus(L)) (§6.4).
#: `COUPLED_AGENTS` indexes AGENT_ORDER = (A_T, A_V, A_L). The spec writes C'_{T,t}, so
#: A_T alone is the literal reading; (0, 1) also couples A_V, whose range estimator is
#: arguably just as price-derived.
COUPLING_KAPPA = 0.5
COUPLING_KAPPA_SWEEP = (0.0, 0.25, 0.5, 1.0, 2.0)
COUPLED_AGENTS = (0,)

#: B3, the arm that actually threatens the contribution: discounted inverse-MSE with no
#: market state. If reacting to recent agent performance does as well as conditioning on
#: measured state, the state conditioning is not earning its place.
B3_DISCOUNT = 0.97

#: Stock and Watson inverse-k sweep: one parameter mapping the whole continuum from
#: equal weights (k = 0) to winner-take-all (k large).
SW_K_SWEEP = (0.0, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0)

#: Walk-forward protocol, settled 1 November and recorded in `Dataset Reconciliation
#: 2026-11-01` §5: indexed on trading days rather than calendar dates, which is what
#: keeps the non-contiguous open-price periods from breaking it.
FOLD_TRAIN = 1250
FOLD_TEST = 125
FOLD_STEP = 125
FOLD_COUNT = 16
SEEDS = (0, 1, 2, 3, 4)          # five seeds across 16 folds

#: Cost sweep rather than a single assumption (Part 9), charged on turnover of the
#: position and applied in quiet periods too. Basis points per unit of position change.
COST_BPS_SWEEP = (0.0, 25.0, 50.0, 100.0)
COST_BPS_PRIMARY = 50.0

#: Scale that maps a forward return into the signal's own [-1, 1] range when computing
#: per-agent loss. 2% is roughly the median daily range on this panel.
LOSS_SCALE = 0.02

# ------------------------------------------------------------------- OPEN

#: PoC Specification Part 10 and Part 13. No value for either exists in the vault.
#: Rather than assert one, both are computed both ways and reported:
#: phi through ORCH_PHI_SWEEP, exposure through both policies in `evaluate.arm_returns`.
PHI_ABSTENTION_FLOOR = None      # OPEN: set at the knee of the frontier, and sweep
ABSTAINED_DAY_EXPOSURE = None    # OPEN: hold the existing position, or go to zero exposure

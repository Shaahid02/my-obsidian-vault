"""The common confidence scale (PoC Specification §5.3).

Each agent's native confidence means something different: A_T emits a Theil U2 ratio
where lower is better, A_V an interval width where narrower is better, A_L a loss ratio
where lower is better. A softmax output and a posterior variance are not comparable.
Two points on an empirical accuracy curve are.

So every raw score is mapped through *its own* accuracy-at-threshold curve, estimated on
a rolling validation window, landing every agent in one unit:

    c_i,t = Pr-hat(correct | confidence_raw_i,t)

the probability of being right at the score just emitted. The transform is indifferent to
whether the raw score runs up or down, because it only ever asks what accuracy followed
scores near this one.

**The limit, stated in the same breath, as it must be every time.** Whether several
backward-looking competence estimates can be made comparable across different
architectures is open. Having a mechanism is progress on the problem, not a solution to
it (Contribution to Knowledge C2 and K2).
"""
from __future__ import annotations

import numpy as np

from . import config


def accuracy_at_threshold(raw: np.ndarray, correct: np.ndarray,
                          window: int = config.CAL_WINDOW,
                          bins: int = config.CAL_BINS,
                          min_per_bin: int = config.CAL_MIN_PER_BIN,
                          prior_strength: float = config.CAL_PRIOR_STRENGTH,
                          lag: int = 1, group: np.ndarray | None = None) -> np.ndarray:
    """Map raw confidence to calibrated probability, causally.

    `correct[t]` is the outcome of the prediction made at t, which is not observable
    until t + 1. `lag` enforces that: the curve fitted for time t uses only pairs whose
    outcome had resolved by t. Getting this wrong is a quiet way to leak one day of
    future information into every confidence number in the study.

    A thin bin is shrunk toward the window's own base rate with a beta prior rather than
    reporting the raw share, so that a bin holding four observations does not emit 1.0.

    `group`, when given, restricts the window to rows of the same group as t. A_V emits
    an interval width on some rows and a QLIKE loss on others (the pre-registered depth
    rule), and the two are different quantities: binning them together would let the
    unit decide the bin. Each mechanism therefore gets its own curve, and a mechanism
    that has only just started has no calibration history until it earns one.

    Returns NaN wherever the window is too short or the raw score is missing.
    """
    raw = np.asarray(raw, dtype=float)
    correct = np.asarray(correct, dtype=float)
    n = len(raw)
    out = np.full(n, np.nan)
    if n == 0:
        return out

    for t in range(n):
        if not np.isfinite(raw[t]):
            continue
        hi = t - lag + 1                      # exclusive end of the resolved history
        lo = max(0, hi - window)
        if hi - lo < max(min_per_bin * 2, 50):
            continue
        r = raw[lo:hi]
        c = correct[lo:hi]
        ok = np.isfinite(r) & np.isfinite(c)
        if group is not None:
            ok &= (group[lo:hi] == group[t])
        if ok.sum() < max(min_per_bin * 2, 50):
            continue
        r, c = r[ok], c[ok]
        base = float(c.mean())

        edges = np.unique(np.quantile(r, np.linspace(0.0, 1.0, bins + 1)))
        if len(edges) < 2:
            out[t] = base
            continue
        # side="right" with clipping puts the current score in the bin whose observed
        # scores bracket it; scores outside the window's range fall in the end bins.
        k = int(np.clip(np.searchsorted(edges, raw[t], side="right") - 1, 0, len(edges) - 2))
        in_bin = (np.searchsorted(edges, r, side="right") - 1).clip(0, len(edges) - 2) == k
        n_bin = int(in_bin.sum())
        if n_bin < min_per_bin:
            # Review finding: CAL_MIN_PER_BIN was only ever used as a floor on the whole
            # window, so bins of ~10 were admitted. A bin below it reports the window's
            # base rate rather than a half-shrunk estimate of its own.
            out[t] = base
            continue
        hits = float(c[in_bin].sum())
        out[t] = (hits + prior_strength * base) / (n_bin + prior_strength)

    return np.clip(out, 0.0, 1.0)


def directional_correct(signal: np.ndarray, forward_return: np.ndarray) -> np.ndarray:
    """The shared definition of "correct" behind every agent's calibration curve.

    One definition across the pool, so that the calibrated numbers are measured against
    the same question even though the agents answer it from different evidence: did the
    sign of the emitted signal match the sign of the next period's adjusted return?

    Days with no signal, no return, or an exactly zero return are NaN rather than wrong.
    A zero return on this market usually means a single trade at the previous price
    rather than a genuine flat, and scoring it as a miss would penalise thin counters for
    their thinness (DC-37 records 6.42% of rows carrying a stale close).
    """
    s = np.asarray(signal, dtype=float)
    f = np.asarray(forward_return, dtype=float)
    out = np.full(len(s), np.nan)
    usable = np.isfinite(s) & np.isfinite(f) & (f != 0.0) & (s != 0.0)
    out[usable] = (np.sign(s[usable]) == np.sign(f[usable])).astype(float)
    return out


def forward_return(adj_close: np.ndarray) -> np.ndarray:
    """Next-period log return, aligned so that index t holds the return realised at t+1.

    This is the only place a forward-looking array is constructed. It is an *outcome*,
    used to score predictions after the fact, and it is never queryable through the data
    layer, so no agent can reach it.
    """
    c = np.asarray(adj_close, dtype=float)
    out = np.full(len(c), np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = c[1:] / c[:-1]
        ratio = np.where((c[1:] > 0) & (c[:-1] > 0), ratio, np.nan)
        out[:-1] = np.log(ratio)
    return out


def forward_return_traded(close: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return to the NEXT TRADED close, placed on the row it is decided at.

    `close` is on the calendar spine with NaN where the counter did not trade. For each
    traded row the outcome is the log return to the next row that has a close, however
    many calendar days later, and the second array gives that gap in spine rows.

    **This is the one definition of "the next return" in the project** (FIXES.md fix 6).
    A position taken at a traded close can only be changed at the next traded close, so
    that is the return it earns. The evaluation panel used to take the next CALENDAR row
    instead and discard any return that spanned a non-trading day, while the agents scored
    themselves on the traded-to-traded return. On HUNT that discarded 29.5% of return
    episodes, and the discarded ones were systematically quieter (mean |r| 0.0143 against
    0.0203 kept), so the evaluation sample for a thin counter was its more active days.
    """
    c = np.asarray(close, dtype=float)
    n = len(c)
    out = np.full(n, np.nan)
    gap = np.full(n, np.nan)
    pos = np.flatnonzero(np.isfinite(c) & (c > 0))
    if len(pos) > 1:
        a, b = pos[:-1], pos[1:]
        out[a] = np.log(c[b] / c[a])
        gap[a] = b - a
    return out, gap


__all__ = ["accuracy_at_threshold", "directional_correct", "forward_return",
           "forward_return_traded"]

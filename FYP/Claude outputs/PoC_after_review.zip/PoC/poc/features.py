"""Causal feature helpers.

Every function here produces a series whose value at t uses only data at or before t.
That is a claim, so `tests/test_causality.py` checks it by recomputing each function on
truncated prefixes and comparing, rather than trusting the implementation to be careful.

Computing the whole series once and slicing is only safe for functions with this
property. Anything fitted (the A_T predictor, the A_V variance model, the L_t loadings)
is refit on a schedule from a trailing window instead, which the agents handle.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import config


# ----------------------------------------------------------------- primitives

def log_return(price: np.ndarray) -> np.ndarray:
    """r[t] = log(p[t] / p[t-1]); r[0] is NaN. Non-positive prices give NaN."""
    p = np.asarray(price, dtype=float)
    out = np.full(p.shape, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = p[1:] / p[:-1]
        ratio = np.where((p[1:] > 0) & (p[:-1] > 0), ratio, np.nan)
        out[1:] = np.log(ratio)
    return out


def _s(x: np.ndarray) -> pd.Series:
    return pd.Series(np.asarray(x, dtype=float))


def rolling_mean(x, window: int, min_periods: int | None = None) -> np.ndarray:
    return _s(x).rolling(window, min_periods=min_periods or window).mean().to_numpy()


def rolling_std(x, window: int, min_periods: int | None = None) -> np.ndarray:
    return _s(x).rolling(window, min_periods=min_periods or window).std(ddof=1).to_numpy()


def rolling_sum(x, window: int, min_periods: int | None = None) -> np.ndarray:
    return _s(x).rolling(window, min_periods=min_periods or window).sum().to_numpy()


def rolling_frac(flag, window: int, min_periods: int | None = None) -> np.ndarray:
    """Share of the trailing window on which a 0/1 flag is set. NaNs are ignored."""
    return _s(flag).rolling(window, min_periods=min_periods or 1).mean().to_numpy()


def zscore_rolling(x, window: int, min_periods: int | None = None) -> np.ndarray:
    """(x - trailing mean) / trailing sd, both computed on the window ending at t."""
    s = _s(x)
    mp = min_periods or window
    mu = s.rolling(window, min_periods=mp).mean()
    sd = s.rolling(window, min_periods=mp).std(ddof=1)
    return ((s - mu) / sd.replace(0.0, np.nan)).to_numpy()


def zscore_expanding(x, min_periods: int) -> np.ndarray:
    s = _s(x)
    mu = s.expanding(min_periods=min_periods).mean()
    sd = s.expanding(min_periods=min_periods).std(ddof=1)
    return ((s - mu) / sd.replace(0.0, np.nan)).to_numpy()


def ewma_var(r: np.ndarray, lam: float = config.AV_EWMA_LAMBDA) -> np.ndarray:
    """RiskMetrics variance. v[t] uses returns up to and including t."""
    r = np.asarray(r, dtype=float)
    out = np.full(r.shape, np.nan)
    v = np.nan
    for i, x in enumerate(r):
        if np.isnan(x):
            out[i] = v
            continue
        v = x * x if np.isnan(v) else lam * v + (1.0 - lam) * x * x
        out[i] = v
    return out


def asinh_scaled(x, min_periods: int = 20) -> np.ndarray:
    """asinh(x / m_t), with m_t the expanding median of the positive values up to t.

    A log transform for strictly positive, heavily skewed liquidity measures that also
    handles exact zeros (a zero-return day gives an Amihud of exactly 0, so log is not
    available). Dividing by the series' own running median first is what makes it
    scale-free: asinh is roughly linear below 1 and logarithmic above it, so without the
    scaling a series whose values are all 1e-6 would pass through untouched, which is the
    defect this replaces. The median is expanding, so the transform is causal.
    """
    s = pd.Series(np.asarray(x, dtype=float))
    m = s.where(s > 0).expanding(min_periods=min_periods).median()
    return np.arcsinh((s / m).to_numpy())


# --------------------------------------------------------------- volatility

def parkinson(high: np.ndarray, low: np.ndarray) -> np.ndarray:
    """Single-bar Parkinson variance: (1 / 4 ln 2) * (ln(H/L))^2.

    Rows with a missing or non-positive high or low give NaN. DC-05 records 144 such
    rows in the panel (23 fully blank, 121 close-only), and a range estimator must skip
    them rather than be biased by them.
    """
    h = np.asarray(high, dtype=float)
    l = np.asarray(low, dtype=float)
    # FIXES.md fix 11: a bar with high == low carries no range information. On this
    # market it is usually a single trade, or a price that did not move by one tick, and
    # entering it as zero variance understated V_t by 5% to 16% on the thin counters,
    # manufacturing a relationship between thinness and low volatility.
    ok = (h > 0) & (l > 0) & np.isfinite(h) & np.isfinite(l) & (h > l)
    out = np.full(h.shape, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        out[ok] = (np.log(h[ok] / l[ok]) ** 2) / (4.0 * np.log(2.0))
    return out


def parkinson_vol(high, low, window: int = config.VT_WINDOW,
                  annualise: int | None = config.ANNUALISATION) -> np.ndarray:
    """Rolling Parkinson volatility. VOL_ESTIMATOR is frozen to this (config)."""
    var = parkinson(high, low)
    # At least a quarter of the window must carry range information (5 of 20). With
    # degenerate bars now missing rather than zero (fix 11), this is the comparable
    # evidence floor to the old "10 of 20 including zeros": it keeps V_t defined on
    # 40,699 traded rows of the dev universe against 40,956 before, where a floor of 10
    # informative bars would have dropped to 35,978 and silently shrunk the evaluation.
    mp = min(window, max(3, window // 4))
    mean_var = _s(var).rolling(window, min_periods=mp).mean().to_numpy()
    vol = np.sqrt(mean_var)
    return vol * np.sqrt(annualise) if annualise else vol


def garman_klass(open_, high, low, close) -> np.ndarray:
    """Present for completeness and NOT used: config.VOL_ESTIMATOR is frozen to Parkinson.

    GK needs the open, and the official opens are blank or degenerate across 2017, 2018,
    2021 Q1 and 2025, so it would be unavailable over large stretches of the window.
    """
    o, h, l, c = (np.asarray(x, dtype=float) for x in (open_, high, low, close))
    ok = (o > 0) & (h > 0) & (l > 0) & (c > 0)
    out = np.full(h.shape, np.nan)
    with np.errstate(divide="ignore", invalid="ignore"):
        out[ok] = (0.5 * np.log(h[ok] / l[ok]) ** 2
                   - (2.0 * np.log(2.0) - 1.0) * np.log(c[ok] / o[ok]) ** 2)
    return out


# -------------------------------------------------------------- long memory

def gph(x: np.ndarray, m: int | None = None) -> tuple[float, float]:
    """Geweke-Porter-Hudak estimate of the fractional differencing parameter d.

    Regresses the log periodogram on log(4 sin^2(w_j / 2)) over the first m Fourier
    frequencies. Returns (d_hat, standard_error). The asymptotic standard error is
    pi / sqrt(24 m), which is the correction the dataset repo's profiling scripts
    already carry (task T0.2).
    """
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 64:
        return np.nan, np.nan
    m = m or int(np.floor(n ** 0.5))
    m = max(4, min(m, n // 2 - 1))
    x = x - x.mean()
    power = np.abs(np.fft.rfft(x)) ** 2 / (2.0 * np.pi * n)
    j = np.arange(1, m + 1)
    omega = 2.0 * np.pi * j / n
    periodogram = power[j]
    good = periodogram > 0
    if good.sum() < 4:
        return np.nan, np.nan
    y = np.log(periodogram[good])
    xx = np.log(4.0 * np.sin(omega[good] / 2.0) ** 2)
    xc = xx - xx.mean()
    denom = float(xc @ xc)
    if denom <= 0:
        return np.nan, np.nan
    slope = float(xc @ (y - y.mean())) / denom
    # Standard error from the regression's own design: var(log I) = pi^2 / 6, so
    # se = sqrt((pi^2 / 6) / sum (x - xbar)^2). FIXES.md fix 11: the asymptotic
    # pi / sqrt(24 m) was 17% to 26% too narrow at m = 27, and used the nominal m even
    # when frequencies with a zero periodogram had been dropped.
    return -slope, float(np.sqrt((np.pi ** 2 / 6.0) / denom))


def gph_on_traded(close: np.ndarray, window: int = config.PT_WINDOW,
                  refit_every: int = config.PT_REFIT_EVERY) -> tuple[np.ndarray, np.ndarray]:
    """Rolling GPH d on |returns| of the traded-day series, carried onto a calendar spine.

    `close` is on the spine with NaN on non-traded days. The estimator runs on the
    contiguous traded-day series and each estimate is carried forward to the following
    non-traded rows as the latest value known there. Inserting non-trading days into
    `close` therefore cannot change any estimate, which is the property the calendar
    version lacked: there a return was missing on every non-traded day and the day after
    it, and gph() treated the survivors as one contiguous series.
    """
    c = np.asarray(close, dtype=float)
    n = len(c)
    d_out = np.full(n, np.nan)
    se_out = np.full(n, np.nan)
    tpos = np.flatnonzero(np.isfinite(c) & (c > 0))
    if len(tpos) > 1:
        rc = log_return(c[tpos])
        d, se = rolling_gph(np.abs(rc), window, refit_every)
        d_out[tpos], se_out[tpos] = d, se
        d_out = pd.Series(d_out).ffill().to_numpy()
        se_out = pd.Series(se_out).ffill().to_numpy()
    return d_out, se_out


def rolling_gph(x: np.ndarray, window: int = config.PT_WINDOW,
                refit_every: int = config.PT_REFIT_EVERY) -> tuple[np.ndarray, np.ndarray]:
    """GPH d over a trailing window, recomputed every `refit_every` days.

    Between recomputations the last estimate is carried forward, which keeps the series
    causal and the cost linear. d_hat[t] never uses data after t.
    """
    x = np.asarray(x, dtype=float)
    n = len(x)
    d_out = np.full(n, np.nan)
    se_out = np.full(n, np.nan)
    d_cur = se_cur = np.nan
    for t in range(n):
        if t + 1 >= window and (t - window + 1) % refit_every == 0:
            d_cur, se_cur = gph(x[t - window + 1: t + 1])
        d_out[t] = d_cur
        se_out[t] = se_cur
    return d_out, se_out


# ----------------------------------------------------------------- technical

def technical_features(adj_close: np.ndarray, adj_high: np.ndarray, adj_low: np.ndarray,
                       adj_volume: np.ndarray) -> tuple[np.ndarray, list[str]]:
    """A deliberately plain feature set over the adjusted bar (§5.2).

    Plainness is the point: the contribution is the orchestration, not the technical
    channel, and a strong A_T would make the weighting harder to attribute, not easier.
    Returns (X, names) with X[t] computed from data at or before t.
    """
    r = log_return(adj_close)
    cols = {
        "ret_1": r,
        "ret_5": rolling_sum(r, 5, min_periods=5),
        "ret_20": rolling_sum(r, 20, min_periods=20),
        "ret_60": rolling_sum(r, 60, min_periods=60),
        "vol_20": rolling_std(r, 20, min_periods=10),
        "vol_ratio": rolling_std(r, 5, min_periods=5) / rolling_std(r, 60, min_periods=30),
        "range_20": parkinson_vol(adj_high, adj_low, 20, annualise=None),
        "mom_z": zscore_rolling(rolling_sum(r, 20, min_periods=20), 120, min_periods=60),
        "vol_z": zscore_rolling(np.log1p(np.asarray(adj_volume, dtype=float)), 60, min_periods=30),
    }
    names = list(cols)
    X = np.column_stack([cols[n] for n in names])
    return X, names


__all__ = [
    "asinh_scaled", "log_return", "rolling_mean", "rolling_std", "rolling_sum", "rolling_frac",
    "zscore_rolling", "zscore_expanding", "ewma_var", "parkinson", "parkinson_vol",
    "garman_klass", "gph", "gph_on_traded", "rolling_gph", "technical_features",
]

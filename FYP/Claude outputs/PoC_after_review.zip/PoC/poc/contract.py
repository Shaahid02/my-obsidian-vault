"""The common agent output contract (PoC Specification §5.1).

Every agent returns this structure whatever it is internally. This is what makes a
heterogeneous pool weightable at all, so the invariants are enforced here rather than
trusted to each agent.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Mapping

import numpy as np


class AgentState(str, Enum):
    """`unparseable` is a distinct state from `abstain` and they route differently.

    §6.3: `unparseable` receives a hard zero and is removed from the simplex before
    anything else; `abstain` shrinks toward the floor phi. Collapsing the two loses
    Contribution to Knowledge C3 element 2.
    """

    OK = "ok"
    ABSTAIN = "abstain"
    UNPARSEABLE = "unparseable"
    NO_DATA = "no_data"


#: States in which the orchestrator still reads `signal`.
CONTRIBUTING = (AgentState.OK, AgentState.ABSTAIN)


class ContractViolation(ValueError):
    """An agent emitted something outside the contract."""


@dataclass(frozen=True)
class AgentOutput:
    """One agent's view of one ticker on one date.

    `confidence_calibrated` is None at emit time. The calibration transform
    (poc.calibration) fills it afterwards via `with_calibrated`, because the
    accuracy-at-threshold curve needs resolved outcomes the agent cannot see.
    """

    agent: str
    ticker: str
    as_of: dt.date
    signal: float
    confidence_raw: float | None
    state: AgentState
    confidence_calibrated: float | None = None
    diagnostics: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Review finding: any value outside CONTRIBUTING used to skip every check, so
        # state="OK" or "banana" with signal 99 was accepted.
        if not isinstance(self.state, AgentState):
            raise ContractViolation(f"{self.agent}: state must be an AgentState, "
                                    f"got {self.state!r}")
        if self.confidence_raw is not None and not np.isfinite(float(self.confidence_raw)):
            raise ContractViolation(f"{self.agent}: confidence_raw must be finite or None")
        if not isinstance(self.as_of, dt.date):
            raise ContractViolation(f"{self.agent}: as_of must be a date, got {type(self.as_of)!r}")
        if self.state in CONTRIBUTING:
            if self.signal is None:
                raise ContractViolation(f"{self.agent}: state={self.state.value} requires a signal")
            if not (-1.0 <= float(self.signal) <= 1.0):
                raise ContractViolation(
                    f"{self.agent}: signal {self.signal!r} outside [-1, 1] on {self.as_of}"
                )
        if self.confidence_calibrated is not None:
            if not (0.0 <= float(self.confidence_calibrated) <= 1.0):
                raise ContractViolation(
                    f"{self.agent}: confidence_calibrated {self.confidence_calibrated!r} "
                    "outside [0, 1]"
                )

    # ------------------------------------------------------------------ helpers

    @classmethod
    def no_data(cls, agent: str, ticker: str, as_of: dt.date, why: str) -> "AgentOutput":
        """The channel has nothing to say. Signal is zero and carries no vote."""
        return cls(
            agent=agent,
            ticker=ticker,
            as_of=as_of,
            signal=0.0,
            confidence_raw=None,
            state=AgentState.NO_DATA,
            diagnostics={"why": why},
        )

    def with_calibrated(self, c: float | None) -> "AgentOutput":
        return replace(self, confidence_calibrated=c)

    def as_row(self) -> dict[str, Any]:
        """Flat dict for the cached-output CSV the arms will consume."""
        return {
            "agent": self.agent,
            "ticker": self.ticker,
            "as_of": self.as_of.isoformat(),
            "signal": self.signal,
            "confidence_raw": self.confidence_raw,
            "confidence_calibrated": self.confidence_calibrated,
            "state": self.state.value,
            **{f"diag_{k}": v for k, v in self.diagnostics.items()},
        }


#: Column order for cached agent output. A5 requires these to be byte-identical
#: across all five arms, which is only achievable if agents run once and the arms
#: consume the cache.
ROW_FIELDS = (
    "agent",
    "ticker",
    "as_of",
    "signal",
    "confidence_raw",
    "confidence_calibrated",
    "state",
)

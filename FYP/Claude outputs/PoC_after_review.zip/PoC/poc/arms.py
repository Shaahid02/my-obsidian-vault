"""The five arms, plus the Stock and Watson sweep.

Three arms is not enough (Part 7). Each of these exists to rule out a specific
alternative explanation for any improvement the proposal shows.

| Arm | Weighting | What it rules out |
|-----|-----------|-------------------|
| B1 | equal weight | The field's hardest benchmark. Fifty years of forecast-combination evidence says this is hard to beat, and the usual reason sophisticated schemes lose is that weight-estimation error exceeds the gain |
| B2 | static learned weight | Beating equal weighting proves little if a fixed learned weight gets there too |
| B3 | discounted inverse-MSE, no market state | **The arm that actually threatens the contribution.** If reacting to recent agent performance does as well as conditioning on measured state, the state conditioning is not earning its place |
| P  | state-conditioned | The proposal |
| O  | oracle, fitted on the test window | Prices the estimation cost in this project's own data and units |

**The non-negotiable fairness rule.** Every arm consumes the same cached agent output
and differs only in the weighting function. The CSE Graph-RAG paper's fatal flaw is that
its proposed system got both the graph and the agent scaffolding while its baseline got
neither. A5 exists to enforce that this is not reproduced, and it is checked in
`tests/test_arms.py` by comparing the signals each arm consumed.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from . import config
from .orchestrator import Orchestrator, softmax_floor


@dataclass
class ArmResult:
    """One arm over one test window."""

    arm: str
    weights: np.ndarray          # (n, K)
    decision: np.ndarray         # (n,) in [-1, 1]
    fold: int
    seed: int
    n_params: int = 0
    converged: bool = True


# ------------------------------------------------------------------- arms

def equal_weight(live: np.ndarray, phi: float = 0.0) -> np.ndarray:
    """B1. Uniform over the agents that carry a vote on each row."""
    return softmax_floor(np.zeros_like(live, dtype=float), live, phi)


def _discounted_loss(loss: np.ndarray, live: np.ndarray, tickers: np.ndarray | None,
                     dates: np.ndarray | None, discount: float) -> tuple[np.ndarray, np.ndarray]:
    """D[t, i], the discounted loss of agent i on row t's ticker, from rows strictly before t.

    One accumulator per ticker, run in date order. FIXES.md fix 5: there used to be one
    accumulator for the whole panel, which is date-major, so the weight for a ticker on
    date d absorbed the d -> d+1 outcomes of every ticker sorted before it on the same
    date (92% of rows in the last fold), and the 0.97 discount meant 33 ROWS of memory,
    about 2.4 trading days, rather than 33 days. Losses of agents outside the simplex are
    not absorbed either: a silent agent's loss is the loss of a zero forecast, and an
    agent should not be credited with performance it never delivered.
    """
    n, K = loss.shape
    D = np.full((n, K), np.nan)
    N = np.zeros((n, K))
    if tickers is None:
        order, keys = np.arange(n), np.zeros(n)
    else:
        keys = np.asarray(tickers)
        order = np.lexsort((np.asarray(dates), keys)) if dates is not None else np.argsort(keys, kind="stable")
    acc = np.full(K, np.nan)
    cnt = np.zeros(K)
    prev = object()
    for i in order:
        if keys[i] != prev:
            acc, cnt, prev = np.full(K, np.nan), np.zeros(K), keys[i]
        D[i], N[i] = acc, cnt                       # what is known before this row resolves
        for j in range(K):
            x = loss[i, j]
            if live[i, j] and np.isfinite(x):
                acc[j] = x if not np.isfinite(acc[j]) else discount * acc[j] + (1 - discount) * x
                cnt[j] += 1
    return D, N


def discounted_inverse_mse(loss: np.ndarray, live: np.ndarray,
                           discount: float = config.B3_DISCOUNT,
                           phi: float = config.ORCH_PHI_DEFAULT,
                           warm: int = 20, abstain: np.ndarray | None = None,
                           tickers: np.ndarray | None = None,
                           dates: np.ndarray | None = None) -> np.ndarray:
    """B3. w_i,t proportional to 1 / D_i,t, with D an exponentially discounted loss.

    Reacts to recent agent performance and to nothing else, which is precisely why it is
    the arm that threatens the contribution: it is adaptive without being conditional on
    measured market state. A row is equal-weighted until every live agent has `warm`
    resolved losses on that ticker.
    """
    loss = np.asarray(loss, dtype=float)
    live = np.asarray(live, dtype=bool)
    D, N = _discounted_loss(loss, live, tickers, dates, discount)
    ready = (np.where(live, N, np.inf) >= warm).all(axis=1) & \
        np.isfinite(np.where(live, D, 1.0)).all(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        s = -np.log(np.maximum(D, 1e-12))
    s = np.where(ready[:, None], np.nan_to_num(s, nan=0.0), 0.0)
    return softmax_floor(s, live, phi, abstain)


def stock_watson(loss: np.ndarray, live: np.ndarray, k: float,
                 discount: float = config.B3_DISCOUNT,
                 phi: float = 0.0, warm: int = 20,
                 abstain: np.ndarray | None = None,
                 tickers: np.ndarray | None = None,
                 dates: np.ndarray | None = None) -> np.ndarray:
    """w_i proportional to (1 / D_i)^k. One parameter, the whole continuum.

    k = 0 is equal weighting and large k is winner-take-all, so the sweep says where on
    that continuum any gain actually sits rather than asserting a scheme.
    """
    loss = np.asarray(loss, dtype=float)
    live = np.asarray(live, dtype=bool)
    D, N = _discounted_loss(loss, live, tickers, dates, discount)
    ready = (np.where(live, N, np.inf) >= warm).all(axis=1) & \
        np.isfinite(np.where(live, D, 1.0)).all(axis=1)
    with np.errstate(divide="ignore", invalid="ignore"):
        s = -k * np.log(np.maximum(D, 1e-12))
    s = np.where(ready[:, None], np.nan_to_num(s, nan=0.0), 0.0)
    return softmax_floor(s, live, phi, abstain)


def with_history(panel_train: dict, panel_test: dict, fn, **kw) -> np.ndarray:
    """Run a loss-tracking arm over train then test, and return the test rows.

    B3 and the Stock and Watson sweep have no fitted parameters, but they do have state,
    and starting that state cold at every test window would leave them equal-weighted for
    the first stretch of each. Warming on the training window uses only losses resolved
    before the test window opens, so it is causal.
    """
    keys = ("loss", "live", "tickers", "dates")
    cat = {k: np.concatenate([np.asarray(panel_train[k]), np.asarray(panel_test[k])])
           if panel_train.get(k) is not None and panel_test.get(k) is not None else None
           for k in keys}
    ab = None
    if panel_train.get("abstain") is not None and panel_test.get("abstain") is not None:
        ab = np.concatenate([panel_train["abstain"], panel_test["abstain"]])
    w = fn(cat["loss"], cat["live"], abstain=ab, tickers=cat["tickers"],
           dates=cat["dates"], **kw)
    return w[len(panel_train["loss"]):]


# ------------------------------------------------------------------ harness

ARMS = ("B1", "B2", "B3", "P", "O")


def run_arms(panel_train, panel_test, *, phi: float = config.ORCH_PHI_DEFAULT,
             lam: float = config.ORCH_L2, seed: int = 0,
             state_names: tuple[str, ...] = ("L", "V", "P"),
             use_confidence: bool = True, coupling: bool = True,
             arms: tuple[str, ...] = ARMS, fold: int = 0) -> dict[str, ArmResult]:
    """Fit and apply every arm to one fold.

    `panel_train` and `panel_test` are dicts produced by `folds.slice_fold`, carrying X,
    c, live, loss, L and signals. Every arm reads the same `signals` array, which is what
    makes A5 checkable.
    """
    out: dict[str, ArmResult] = {}
    Xtr, Xte = panel_train["X"], panel_test["X"]
    # Abstention routing applies to every arm that has a weighting function to route it
    # through. B1 is equal weighting by definition and ignores agent-reported state, which
    # is what makes it the field's benchmark rather than a variant of the proposal.
    ab_tr, ab_te = panel_train.get("abstain"), panel_test.get("abstain")
    n_agents = panel_test["signals"].shape[1]

    votes = panel_test.get("vote", panel_test["signals"])

    def decide(w):
        return np.clip(np.nansum(w * np.nan_to_num(votes, nan=0.0), axis=1), -1.0, 1.0)

    if "B1" in arms:
        w = equal_weight(panel_test["live"], phi=0.0)
        out["B1"] = ArmResult("B1", w, decide(w), fold, seed, 0)

    if "B2" in arms:
        # Static learned weight: the intercept only, so the weights are constant across
        # the test window. If a fixed learned weight gets there too, beating B1 proves
        # little.
        orch = Orchestrator(n_agents, state_names=(), lam=lam, phi=phi,
                            use_confidence=False, coupling=False)
        f = orch.fit(Xtr[:, :1], panel_train["c"], panel_train["live"],
                     panel_train["loss"], panel_train["L"], seed=seed, abstain=ab_tr)
        w = orch.weights(Xte[:, :1], panel_test["c"], panel_test["live"], panel_test["L"],
                         ab_te)
        out["B2"] = ArmResult("B2", w, decide(w), fold, seed, f.n_params, f.converged)

    if "B3" in arms:
        w = with_history(panel_train, panel_test, discounted_inverse_mse, phi=phi)
        out["B3"] = ArmResult("B3", w, decide(w), fold, seed, 0)

    if "P" in arms:
        orch = Orchestrator(n_agents, state_names=state_names, lam=lam, phi=phi,
                            use_confidence=use_confidence, coupling=coupling)
        f = orch.fit(Xtr, panel_train["c"], panel_train["live"], panel_train["loss"],
                     panel_train["L"], seed=seed, abstain=ab_tr)
        w = orch.weights(Xte, panel_test["c"], panel_test["live"], panel_test["L"], ab_te)
        out["P"] = ArmResult("P", w, decide(w), fold, seed, f.n_params, f.converged)

    if "O" in arms:
        # Oracle: the same form as P, fitted on the test window itself. The gap between
        # O and P is the estimation cost, in this project's own data and units.
        orch = Orchestrator(n_agents, state_names=state_names, lam=lam, phi=phi,
                            use_confidence=use_confidence, coupling=coupling)
        f = orch.fit(Xte, panel_test["c"], panel_test["live"], panel_test["loss"],
                     panel_test["L"], seed=seed, abstain=ab_te)
        w = orch.weights(Xte, panel_test["c"], panel_test["live"], panel_test["L"], ab_te)
        out["O"] = ArmResult("O", w, decide(w), fold, seed, f.n_params, f.converged)

    return out


#: Ablations. Each is the proposal with exactly one input removed, run through the same
#: object, which is what makes the delta attributable to that input.
ABLATIONS = {
    "P-L":        dict(state_names=("V", "P"), use_confidence=True, coupling=False),
    "P-V":        dict(state_names=("L", "P"), use_confidence=True, coupling=True),
    "P-P":        dict(state_names=("L", "V"), use_confidence=True, coupling=True),
    "P-C":        dict(state_names=("L", "V", "P"), use_confidence=False, coupling=False),
    "P-Coupling": dict(state_names=("L", "V", "P"), use_confidence=True, coupling=False),
}
#: Note on P-L: removing L_t also removes the liquidity-to-reliability coupling, because
#: g(L_t) has no argument without it. So the P-L delta is the joint effect, and P-Coupling
#: is what separates the two uses of the one measurement.


__all__ = ["ArmResult", "run_arms", "equal_weight", "discounted_inverse_mse",
           "stock_watson", "with_history", "ARMS", "ABLATIONS"]

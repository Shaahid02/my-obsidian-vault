"""Metrics, the pre-registered decision rule, and the diagnostics set.

Part 9's commitments are implemented rather than paraphrased. In particular every
directional result carries class balance, Matthews correlation and cost-adjusted return
**on the same row**, because the local example of why is on the record: accuracy 0.5837
at MCC 0.1493.
"""
from __future__ import annotations

import numpy as np

from . import config


# ------------------------------------------------------------------ returns

def system_abstains(live: np.ndarray, abstain: np.ndarray) -> np.ndarray:
    """A row on which no agent is in state `ok`.

    Abstention in this architecture is per agent. The *system* abstains when every live
    agent is abstaining, or when none is live at all. Making that explicit is necessary
    because the primary metric is defined over abstained days.
    """
    return ~(np.asarray(live, bool) & ~np.asarray(abstain, bool)).any(axis=1)


def arm_returns(decision: np.ndarray, fwd: np.ndarray, tickers: np.ndarray,
                dates: np.ndarray, abstained: np.ndarray,
                cost_bps: float = config.COST_BPS_PRIMARY,
                exposure: str = "hold") -> dict[str, np.ndarray]:
    """Per-row realised return, net of turnover cost, per ticker.

    `exposure` resolves the OPEN pre-registration item. The notes say abstained days are
    "held flat", which does not distinguish holding the existing position from going to
    zero exposure, and going flat carries a round-trip cost each time. Both are computed
    and reported rather than one being inherited from a metric description.
    """
    decision = np.asarray(decision, dtype=float)
    fwd = np.asarray(fwd, dtype=float)
    pos = np.zeros(len(decision))
    turnover = np.zeros(len(decision))

    order = np.lexsort((dates, tickers))
    prev_t, prev_pos = None, 0.0
    for i in order:
        t = tickers[i]
        if t != prev_t:
            prev_pos, prev_t = 0.0, t
        if abstained[i]:
            p = prev_pos if exposure == "hold" else 0.0
        else:
            p = decision[i]
        pos[i] = p
        turnover[i] = abs(p - prev_pos)
        prev_pos = p

    gross = pos * np.nan_to_num(fwd, nan=0.0)
    cost = turnover * (cost_bps / 10_000.0)
    return {"position": pos, "turnover": turnover, "gross": gross,
            "cost": cost, "net": gross - cost}


# ------------------------------------------------------------------ metrics

def matthews(pred_sign: np.ndarray, true_sign: np.ndarray) -> float:
    tp = float(((pred_sign > 0) & (true_sign > 0)).sum())
    tn = float(((pred_sign < 0) & (true_sign < 0)).sum())
    fp = float(((pred_sign > 0) & (true_sign < 0)).sum())
    fn = float(((pred_sign < 0) & (true_sign > 0)).sum())
    denom = np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return float((tp * tn - fp * fn) / denom) if denom > 0 else np.nan


def summarise(decision: np.ndarray, fwd: np.ndarray, ret: dict,
              abstained: np.ndarray, weights: np.ndarray) -> dict[str, float]:
    """One row of results. Directional and economic figures together, by construction."""
    from .orchestrator import weight_entropy

    d, f = np.asarray(decision, float), np.asarray(fwd, float)
    scored = np.isfinite(d) & np.isfinite(f) & (f != 0.0) & (d != 0.0) & ~abstained
    ps, ts = np.sign(d[scored]), np.sign(f[scored])
    H = weight_entropy(weights)
    n = len(d)
    return {
        "n": n,
        "coverage": float((~abstained).mean()) if n else np.nan,
        "scored": int(scored.sum()),
        "hit_rate": float((ps == ts).mean()) if scored.any() else np.nan,
        "class_balance_up": float((ts > 0).mean()) if scored.any() else np.nan,
        "mcc": matthews(ps, ts),
        "net_return": float(np.nansum(ret["net"])),
        "gross_return": float(np.nansum(ret["gross"])),
        "cost_paid": float(np.nansum(ret["cost"])),
        "turnover": float(np.nansum(ret["turnover"])),
        "exposure_time": float((np.abs(ret["position"]) > 1e-9).mean()) if n else np.nan,
        "mean_abs_position": float(np.nanmean(np.abs(ret["position"]))) if n else np.nan,
        "entropy_mean": float(np.nanmean(H)),
        "entropy_sd": float(np.nanstd(H)),
    }


# ------------------------------------------- the pre-registered decision rule

def margin_rule(per_fold_P: np.ndarray, per_fold_B1: np.ndarray) -> dict:
    """Fixed 24 October, defined 1 November.

    The median per-fold difference must exceed the interquartile range of the baseline's
    own per-fold returns, **and** the paired test must clear alpha. Both halves required.
    The IQR half is what stops a win that is smaller than the baseline's own fold-to-fold
    noise from being called a win.
    """
    d = np.asarray(per_fold_P, float) - np.asarray(per_fold_B1, float)
    q75, q25 = np.nanpercentile(per_fold_B1, [75, 25])
    iqr = float(q75 - q25)
    med = float(np.nanmedian(d))
    return {"median_delta": med, "baseline_iqr": iqr, "iqr_passed": bool(med > iqr),
            "n_folds": int(np.isfinite(d).sum())}


def hac_paired_test(diff: np.ndarray, lag: int | None = None) -> dict:
    """Newey-West HAC paired t-test on a difference series.

    The standing caution applies and is reported with the number: standard errors for a
    combined forecast are nontrivial because the weights are random and correlated with
    the forecasts, so this is an approximation whose conservatism is not guaranteed.
    """
    x = np.asarray(diff, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 20:
        return {"mean": np.nan, "t": np.nan, "p": np.nan, "n": n, "lag": 0}
    if lag is None:
        lag = int(np.floor(4 * (n / 100.0) ** (2.0 / 9.0)))
    xc = x - x.mean()
    gamma0 = float(xc @ xc) / n
    var = gamma0
    for k in range(1, lag + 1):
        g = float(xc[k:] @ xc[:-k]) / n
        var += 2.0 * (1.0 - k / (lag + 1.0)) * g
    var = max(var, 1e-18)
    t = float(x.mean() / np.sqrt(var / n))
    from scipy import stats
    return {"mean": float(x.mean()), "t": t,
            "p": float(2 * stats.t.sf(abs(t), df=n - 1)), "n": n, "lag": lag}


def daily_difference(net_a: np.ndarray, net_b: np.ndarray, dates: np.ndarray) -> np.ndarray:
    """Per-date portfolio P&L difference, in date order. The series the tests run on.

    FIXES.md fix 10. The paired tests used to run on panel rows. The panel is date-major,
    so the HAC lag and the bootstrap blocks ran across tickers on the same day rather than
    along time, and 16 folds of about 1,500 rows were treated as 23,600 observations. The
    economic quantity is the portfolio's daily P&L, so the difference is summed across
    tickers within each date and the dependence correction then runs along time.
    """
    d = np.asarray(net_a, float) - np.asarray(net_b, float)
    dates = np.asarray(dates)
    order = np.argsort(dates, kind="stable")
    u, start = np.unique(dates[order], return_index=True)
    return np.add.reduceat(np.nan_to_num(d[order], nan=0.0), start)


def stationary_bootstrap(diff: np.ndarray, n_boot: int = 2000,
                         mean_block: float = 20.0, seed: int = 0) -> dict:
    """Politis and Romano stationary bootstrap on the difference series."""
    x = np.asarray(diff, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 20:
        return {"p": np.nan, "ci_low": np.nan, "ci_high": np.nan, "n": n}
    rng = np.random.default_rng(seed)
    p_geom = 1.0 / mean_block
    means = np.empty(n_boot)
    for b in range(n_boot):
        idx = np.empty(n, dtype=int)
        i = rng.integers(n)
        for j in range(n):
            idx[j] = i
            if rng.random() < p_geom:
                i = rng.integers(n)
            else:
                i = (i + 1) % n
        means[b] = x[idx].mean()
    centred = means - means.mean()
    return {"p": float((np.abs(centred) >= abs(x.mean())).mean()),
            "ci_low": float(np.quantile(means, 0.025)),
            "ci_high": float(np.quantile(means, 0.975)), "n": n}


# --------------------------------------------------------------- diagnostics

def quiet_vs_stressed(dates: np.ndarray, net: np.ndarray, V: np.ndarray,
                      quantile: float = 0.8) -> dict:
    """Split by volatility state (§8.2).

    The trap this tests for is an orchestrator whose weights move impressively in the two
    or three most volatile months and are inert otherwise.
    """
    V = np.asarray(V, float)
    ok = np.isfinite(V)
    if ok.sum() < 50:
        return {}
    thr = float(np.nanquantile(V[ok], quantile))
    stressed = ok & (V >= thr)
    quiet = ok & (V < thr)
    return {"threshold_V": thr,
            "net_quiet": float(np.nansum(net[quiet])), "n_quiet": int(quiet.sum()),
            "net_stressed": float(np.nansum(net[stressed])), "n_stressed": int(stressed.sum())}


def collinearity(a: np.ndarray, b: np.ndarray) -> float:
    """A_V against A_L collinearity (§8.2): if they move together the two agents are
    partly measuring the same thing and the state vector has a collinearity problem."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    ok = np.isfinite(a) & np.isfinite(b)
    return float(np.corrcoef(a[ok], b[ok])[0, 1]) if ok.sum() > 30 else np.nan


def knee(xs, ys) -> int:
    """Index, IN THE CALLER'S LIST, of the knee of a swept curve.

    The point furthest from the chord joining the first and last points, on axes
    normalised to [0, 1] (the Kneedle construction). §6.3 says to set phi at the knee
    of the frontier, not at its end.

    Review findings: the previous version returned an index into its own NaN-filtered
    array, which the caller then used on the unfiltered list, and took second
    differences on an unevenly spaced eight-point grid, which on a flat or monotone
    curve returns an endpoint: exactly the failure the docstring warns against.
    Returns -1 if there are fewer than three usable points.
    """
    x = np.asarray(xs, float)
    y = np.asarray(ys, float)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3:
        return -1
    xo, yo = x[ok], y[ok]
    xn = (xo - xo.min()) / (np.ptp(xo) or 1.0)
    yn = (yo - yo.min()) / (np.ptp(yo) or 1.0)
    a = np.array([xn[0], yn[0]])
    b = np.array([xn[-1], yn[-1]])
    ab = b - a
    norm = np.hypot(*ab) or 1.0
    dist = np.abs(ab[0] * (yn - a[1]) - ab[1] * (xn - a[0])) / norm
    return int(np.flatnonzero(ok)[int(np.argmax(dist))])


__all__ = ["system_abstains", "arm_returns", "summarise", "matthews", "margin_rule",
           "daily_difference", "hac_paired_test", "stationary_bootstrap", "quiet_vs_stressed",
           "collinearity", "knee"]

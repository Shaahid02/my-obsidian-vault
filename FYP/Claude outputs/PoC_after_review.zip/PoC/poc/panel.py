"""Assemble the cached agent output and state series into one fitting panel.

The arms consume this and nothing else. That is what acceptance check A5 requires:
agent outputs must be byte-identical across all five arms, which is only achievable if
the agents ran once and every arm reads the same cache rather than recomputing.

`forward_return` is the only forward-looking column. It is an outcome used to score and
to fit, it never passes through the data layer, and no agent can reach it.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from . import config
from .calibration import forward_return_traded
from .datalayer import DataLayer

#: Agent order is fixed here and used everywhere downstream, so that a weight vector's
#: columns always mean the same thing.
AGENT_ORDER = ("A_T", "A_V", "A_L")

#: Contract states that leave the simplex entirely rather than shrinking to the floor.
#: `unparseable` is the spec's hard zero (§6.3); `no_data` carries no vote by contract,
#: so it is removed for the same reason rather than diluting the simplex with a zero.
OUT_OF_SIMPLEX = ("unparseable", "no_data")
CONTRIBUTING_STATES = ("ok", "abstain")


@dataclass
class Panel:
    """Long panel over (ticker, date), with agent signals, confidences and state."""

    frame: pd.DataFrame
    agents: tuple[str, ...] = AGENT_ORDER

    # ------------------------------------------------------------- accessors

    @property
    def dates(self) -> np.ndarray:
        return self.frame["date"].to_numpy()

    def matrix(self, prefix: str) -> np.ndarray:
        """Stack one per-agent column into an (n, K) array in AGENT_ORDER."""
        return np.column_stack([self.frame[f"{prefix}_{a}"].to_numpy(dtype=float)
                                for a in self.agents])

    def in_simplex(self) -> np.ndarray:
        """(n, K) boolean: which agents carry a vote on each row.

        Defined positively against the contributing states. Review finding: it used to be
        "not unparseable and not no_data", so any unrecognised state value counted as a
        vote.
        """
        return np.column_stack([
            self.frame[f"state_{a}"].isin(CONTRIBUTING_STATES).to_numpy()
            for a in self.agents])

    def abstaining(self) -> np.ndarray:
        return np.column_stack([
            (self.frame[f"state_{a}"] == "abstain").to_numpy() for a in self.agents])

    def state_vector(self, include: tuple[str, ...] = ("L", "V", "P")) -> np.ndarray:
        """x_t = [1, L_t, V_t, P_t]'. Dropping a member is how the ablations are run."""
        cols = [np.ones(len(self.frame))]
        for name in include:
            cols.append(self.frame[name].to_numpy(dtype=float))
        return np.column_stack(cols)

    def usable(self) -> np.ndarray:
        """Rows where at least one agent votes, the state vector is complete and the
        outcome resolved. Everything is fitted and scored on these rows only."""
        finite_state = np.isfinite(self.frame[["L", "V", "P"]].to_numpy(dtype=float)).all(axis=1)
        any_vote = self.in_simplex().any(axis=1)
        resolved = np.isfinite(self.frame["fwd_ret"].to_numpy(dtype=float))
        return finite_state & any_vote & resolved

    def __len__(self) -> int:
        return len(self.frame)


def load_panel(out_dir: Path | str | None = None,
               dataset_root: Path | str | None = None,
               symbols: list[str] | None = None,
               l_column: str = "L") -> Panel:
    """Read `out/agents/` and `out/state/` into one panel.

    `l_column` picks which cached L_t series becomes the panel's `L`, so the L_pca
    robustness run uses the same agent cache and the same rows as the primary run.
    """
    out = Path(out_dir) if out_dir else config.OUT
    dl = DataLayer(dataset_root)

    agent_files = sorted((out / "agents").glob("*.csv"))
    if symbols:
        want = set(symbols)
        agent_files = [p for p in agent_files if p.stem in want]
    if not agent_files:
        raise FileNotFoundError(f"no cached agent output under {out / 'agents'}; "
                                "run scripts/run_agents.py first")

    pieces = []
    for p in agent_files:
        sym = p.stem
        a = pd.read_csv(p, parse_dates=["as_of"])
        wide = a.pivot(index="as_of", columns="agent",
                       values=["signal", "confidence_calibrated", "state"])
        wide.columns = [f"{'c' if k == 'confidence_calibrated' else k}_{ag}"
                        for k, ag in wide.columns]

        st = pd.read_csv(out / "state" / f"{sym}.csv", parse_dates=["date"]).set_index("date")
        # Review findings: a duplicated date multiplied rows through the join, a date gap
        # in the agent file made the forward return silently span it, and a missing agent
        # raised a bare KeyError. All three now fail loudly with the reason.
        if st.index.duplicated().any() or wide.index.duplicated().any():
            raise ValueError(f"{sym}: duplicated dates in the cached state or agent output")
        if not wide.index.equals(st.index):
            raise ValueError(f"{sym}: agent output and state series cover different dates; "
                             "re-run scripts/run_agents.py")
        absent = [a for a in AGENT_ORDER if f"state_{a}" not in wide.columns]
        if absent:
            raise ValueError(f"{sym}: no cached output for {absent}")
        if l_column not in st.columns:
            raise ValueError(f"{sym}: state cache has no {l_column!r} column")
        stv = st[[l_column, "V", "P", "traded"]].rename(columns={l_column: "L"})
        df = wide.join(stv, how="left")

        # Outcome: the return from this traded close to the next traded close, the one
        # definition used everywhere (calibration.forward_return_traded, fix 6).
        adj = dl.query(sym, ["adj_close"], dl.window_end, source="adjusted")
        pos = {d: i for i, d in enumerate(adj.dates)}
        close = np.array([adj["adj_close"][pos[d.date()]] if d.date() in pos else np.nan
                          for d in df.index], dtype=float)
        df["fwd_ret"], df["fwd_gap"] = forward_return_traded(close)

        df = df.reset_index().rename(columns={"as_of": "date", "index": "date"})
        df.insert(0, "ticker", sym)
        pieces.append(df)

    frame = pd.concat(pieces, ignore_index=True)
    frame["date"] = pd.to_datetime(frame["date"]).dt.date
    for a in AGENT_ORDER:
        frame[f"state_{a}"] = frame[f"state_{a}"].fillna("no_data")
        frame[f"signal_{a}"] = frame[f"signal_{a}"].fillna(0.0)
    frame = frame.sort_values(["date", "ticker"], kind="stable").reset_index(drop=True)
    return Panel(frame)


def conviction_scales(signal: np.ndarray, fwd: np.ndarray,
                      scale: float = config.LOSS_SCALE,
                      live: np.ndarray | None = None) -> np.ndarray:
    """Per-agent multipliers that put every agent's conviction on one scale.

    **Why this is necessary, found on the first full run.** A squared-error loss against
    a usually-small target rewards a timid agent regardless of direction. On this panel
    mean |signal| is 0.09 for A_T against 0.41 and 0.45 for A_V and A_L, with a target
    averaging 0.59, and A_T's apparent dominance in the weighted loss was substantially
    that artefact rather than skill. The orchestrator was learning to trust the quietest
    channel, not the most accurate one.

    So each agent's signal is rescaled so that its mean absolute conviction matches the
    target's, which leaves direction and relative timing as the only things the loss can
    see. Fitted on the training window and applied unchanged to test, like any other
    fitted quantity.
    """
    s = np.asarray(signal, dtype=float)
    target = np.clip(np.asarray(fwd, dtype=float) / scale, -1.0, 1.0)
    want = float(np.nanmean(np.abs(target)))
    # Measured on the rows where each agent actually voted. FIXES.md fix 7a: averaging in
    # the hard zeros of no_data rows made a frequently silent agent look quieter than it
    # is, and over-amplified it in proportion to how often it declined to vote.
    a = np.abs(s) if live is None else np.where(np.asarray(live, dtype=bool), np.abs(s), np.nan)
    have = np.nanmean(a, axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        k = np.where(have > 1e-9, want / have, 1.0)
    return np.nan_to_num(k, nan=1.0, posinf=1.0)


def agent_loss(signal: np.ndarray, fwd: np.ndarray, scale: float = config.LOSS_SCALE,
               scales: np.ndarray | None = None) -> np.ndarray:
    """Per-agent loss, the quantity the orchestrator learns to avoid.

    Squared error of the agent's rescaled signal against the forward return mapped into
    [-1, 1]. Smooth, bounded, and the same quantity for every agent, which is what lets
    one weighted objective compare them. `scales` must come from the training window.
    """
    s = np.asarray(signal, dtype=float)
    if scales is not None:
        s = np.clip(s * np.asarray(scales, dtype=float)[None, :], -1.0, 1.0)
    target = np.clip(np.asarray(fwd, dtype=float) / scale, -1.0, 1.0)
    return (s - target[:, None]) ** 2


__all__ = ["Panel", "load_panel", "agent_loss", "AGENT_ORDER", "OUT_OF_SIMPLEX"]
